"""Brand rename script: every variant is caught, case is preserved, nothing else moves."""

import importlib.util
from pathlib import Path

import pytest

_spec = importlib.util.spec_from_file_location(
    "rebrand", Path(__file__).resolve().parents[1] / "scripts" / "rebrand.py"
)
rebrand = importlib.util.module_from_spec(_spec)
_spec.loader.exec_module(rebrand)

# Product name pieces are assembled so this file survives its own rename and
# the bundle's --check stays at zero.
W = "Lib" + "re"
P = W + "Chat"


@pytest.mark.parametrize(
    "before, after",
    [
        (f"Use {P} today", "Use Ranger today"),
        (f"{P.lower()}-rag-api:latest", "ranger-rag-api:latest"),
        (f"{P.upper()}_CODE_BASEURL", "RANGER_CODE_BASEURL"),
        (W + "chat config", "Ranger config"),
        (W.lower() + "-chat and " + W.lower() + "_chat", "ranger and ranger"),
        (W + " Chat app", "Ranger app"),
        ("the " + W + "/agents repo", "the Ranger/agents repo"),
        ("mongodb://h:1/" + P, "mongodb://h:1/Ranger"),
    ],
)
def test_every_variant_is_renamed_with_case_preserved(before, after):
    assert rebrand.rewrite_text(before, "Ranger") == after


def test_links_to_upstream_site_become_plain_text():
    text = f"integration with [{P}](https://{P.lower()}.ai) and [docs](https://www.{P.lower()}.ai/x)"
    assert rebrand.rewrite_text(text, "Ranger") == "integration with Ranger and docs"


def test_unrelated_words_are_untouched():
    text = "liberty library cal" + "ibre langchain lc_kwargs lcd block"
    assert rebrand.rewrite_text(text, "Ranger") == text


def test_lc_tokens_are_reported_and_only_rewritten_on_request():
    text = "header x-lc-agent-trigger and LC_FLAG but not lcd or block"
    assert rebrand.find_lc(text)
    assert rebrand.rewrite_text(text, "Ranger") == text
    assert rebrand.rewrite_text(text, "Ranger", lc_to="rg") == (
        "header x-rg-agent-trigger and RG_FLAG but not lcd or block"
    )


def test_tree_rewrite_renames_paths_and_check_passes(tmp_path):
    (tmp_path / f"{P.lower()}-docs").mkdir()
    (tmp_path / f"{P.lower()}-docs" / f"{P}.md").write_text(f"About {P}.\n")
    (tmp_path / "keep.bin").write_bytes(b"\0" + P.encode())  # binary: untouched

    assert rebrand.main([str(tmp_path), "--check"]) == 1
    assert rebrand.main([str(tmp_path)]) == 0

    moved = tmp_path / "ranger-docs" / "Ranger.md"
    assert moved.read_text() == "About Ranger.\n"
    assert (tmp_path / "keep.bin").read_bytes() == b"\0" + P.encode()
    assert rebrand.main([str(tmp_path), "--check"]) == 0
