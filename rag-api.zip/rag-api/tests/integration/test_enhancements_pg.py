"""Integration tests: hybrid full-text leg and raw-upload store on real Postgres.

Proves the SQL that ships: the lexical leg finds exact tokens the vector leg
would miss, uses the expression index, and never crosses the owner, file, or
collection scope; the landing store survives a full land/fail/replay lifecycle.

Run with:  pytest tests/integration/test_enhancements_pg.py -m integration -v
"""

import json
import uuid

import asyncpg
import pytest
from sqlalchemy import text

from app.enhancements.raw_uploads import FilesystemBackend, RawUploadStore, UploadStatus
from app.enhancements.retrieval import fts

pytestmark = pytest.mark.integration

OWNER = "owner-user"
OTHER = "other-user"


def _dsn(pg_container) -> str:
    host = pg_container.get_container_host_ip()
    port = pg_container.get_exposed_port(5432)
    return (
        f"postgresql://{pg_container.username}:{pg_container.password}"
        f"@{host}:{port}/{pg_container.dbname}"
    )


@pytest.fixture()
async def pool(pg_container, engine, _create_tables):
    p = await asyncpg.create_pool(_dsn(pg_container), min_size=1, max_size=2)
    yield p
    await p.close()


def _insert(conn, collection_id, *, file_id, owner, document, index):
    conn.execute(
        text(
            "INSERT INTO langchain_pg_embedding "
            "(collection_id, embedding, document, cmetadata, custom_id) "
            "VALUES (:cid, '[0.1,0.2,0.3]', :doc, :meta, :cust)"
        ),
        {
            "cid": collection_id,
            "doc": document,
            "meta": json.dumps(
                {
                    "file_id": file_id,
                    "user_id": owner,
                    "_rag_chunk_index": index,
                    "_rag_ingestion_attempt_id": "attempt-1",
                }
            ),
            "cust": file_id,
        },
    )


@pytest.fixture()
def corpus(engine, collection_id):
    file_a = f"file-a-{uuid.uuid4().hex[:8]}"
    file_b = f"file-b-{uuid.uuid4().hex[:8]}"
    foreign = f"file-x-{uuid.uuid4().hex[:8]}"
    other_collection_file = f"file-c-{uuid.uuid4().hex[:8]}"
    with engine.begin() as conn:
        _insert(
            conn,
            collection_id,
            file_id=file_a,
            owner=OWNER,
            index=0,
            document="The replacement part number is ZX-4410 for the pump housing.",
        )
        _insert(
            conn,
            collection_id,
            file_id=file_a,
            owner=OWNER,
            index=1,
            document="Quarterly revenue grew because of strong services demand.",
        )
        _insert(
            conn,
            collection_id,
            file_id=file_b,
            owner=OWNER,
            index=0,
            document="Warranty claims for pump housings are handled by the regional office.",
        )
        _insert(
            conn,
            collection_id,
            file_id=foreign,
            owner=OTHER,
            index=0,
            document="Secret: part number ZX-4410 pricing for a different customer.",
        )
        other_cid = conn.execute(
            text(
                "INSERT INTO langchain_pg_collection (name, cmetadata) VALUES (:n, '{}') "
                "ON CONFLICT (name) DO UPDATE SET name = EXCLUDED.name RETURNING uuid"
            ),
            {"n": "other_collection"},
        ).scalar()
        _insert(
            conn,
            other_cid,
            file_id=other_collection_file,
            owner=OWNER,
            index=0,
            document="ZX-4410 appears in another collection too.",
        )
    yield file_a, file_b, foreign, other_collection_file
    with engine.begin() as conn:
        conn.execute(
            text("DELETE FROM langchain_pg_embedding WHERE custom_id = ANY(:ids)"),
            {"ids": [file_a, file_b, foreign, other_collection_file]},
        )


async def test_index_builds_concurrently_and_is_used(pool, corpus):
    await fts.ensure_fts_index(pool, "english")

    async def check():
        async with pool.acquire() as conn:
            valid = await conn.fetchval(
                "SELECT i.indisvalid FROM pg_index i JOIN pg_class c ON c.oid = i.indexrelid "
                "WHERE c.relname = $1",
                fts.index_name("english"),
            )
            # The search SQL must use the exact index expression, otherwise the
            # planner can never use the index. On a 5-row table it may prefer
            # the file_id index for the full query, so probe the expression
            # alone with sequential scans disabled.
            await conn.execute("SET enable_seqscan = off")
            assert fts._tsvector_expr("english") in fts.build_search_sql("english")
            plan = await conn.fetch(
                f"EXPLAIN SELECT 1 FROM {fts.EMBEDDING_TABLE} "
                f"WHERE {fts._tsvector_expr('english')} @@ plainto_tsquery('english', $1)",
                "pump",
            )
            return valid, "\n".join(r[0] for r in plan)

    valid, plan = await check()
    assert valid is True
    assert fts.index_name("english") in plan
    # Re-running is a no-op (every replica calls it at startup).
    await fts.ensure_fts_index(pool, "english")


async def test_exact_token_found_and_scope_enforced(pool, corpus):
    file_a, file_b, foreign, other_collection_file = corpus
    results = await fts.fts_search(
        pool,
        query="what is part ZX-4410?",
        collection_name="test_collection",
        file_ids=[file_a, file_b, foreign, other_collection_file],
        owners=[OWNER],
        limit=10,
    )
    docs = [d.page_content for d, _ in results]
    assert any("ZX-4410" in d and "pump housing" in d for d in docs)
    assert not any("Secret" in d for d in docs)  # other owner's file
    assert not any("another collection" in d for d in docs)  # other collection
    assert all(d.metadata["user_id"] == OWNER for d, _ in results)
    assert results[0][0].metadata["_rag_chunk_index"] == 0  # metadata decoded


async def test_or_semantics_rank_more_matches_higher(pool, corpus):
    file_a, file_b, *_ = corpus
    results = await fts.fts_search(
        pool,
        query="pump housing warranty claims",
        collection_name="test_collection",
        file_ids=[file_a, file_b],
        owners=[OWNER],
        limit=10,
    )
    assert len(results) == 2  # both pump chunks match although neither has every term
    assert "Warranty claims" in results[0][0].page_content


async def test_stopword_only_query_returns_nothing(pool, corpus):
    file_a, *_ = corpus
    assert (
        await fts.fts_search(
            pool,
            query="the of and",
            collection_name="test_collection",
            file_ids=[file_a],
            owners=[OWNER],
            limit=5,
        )
        == []
    )


async def test_raw_upload_lifecycle(pool, tmp_path):
    source = tmp_path / "report.pdf"
    source.write_bytes(b"%PDF-1.4 fake bytes")
    backend = FilesystemBackend(str(tmp_path / "landing"))
    store = RawUploadStore(pool, backend, keep_on_success=False)
    await store.ensure_schema()
    await store.ensure_schema()  # idempotent

    file_id = f"file-{uuid.uuid4().hex[:8]}"
    failed_id = await store.land(
        path=str(source),
        file_id=file_id,
        user_id=OWNER,
        filename="report.pdf",
        content_type="application/pdf",
    )
    await store.mark_failed(failed_id, "extraction blew up")

    failed = await store.list_failed([OWNER])
    assert [r.id for r in failed] == [failed_id]
    assert failed[0].last_error == "extraction blew up"
    assert await store.list_failed([OTHER]) == []
    assert await store.get_owned(failed_id, [OTHER]) is None

    record = await store.get_owned(failed_id, [OWNER])
    restored = tmp_path / "restored.pdf"
    store.fetch_bytes(record, str(restored))
    assert restored.read_bytes() == source.read_bytes()

    await store.begin_retry(failed_id)
    await store.mark_succeeded(failed_id)
    record = await store.get_owned(failed_id, [OWNER])
    assert record.status == UploadStatus.SUCCEEDED
    assert record.attempts == 2
    assert record.storage_key is None  # bytes dropped on success by default
    assert not any((tmp_path / "landing").rglob("*.pdf"))

    kept_id = await store.land(
        path=str(source),
        file_id=file_id,
        user_id=OWNER,
        filename="report.pdf",
        content_type="application/pdf",
    )
    assert await store.delete_for_files([file_id], [OTHER]) == 0  # owner-scoped
    assert await store.delete_for_files([file_id], [OWNER]) == 2
    assert await store.get_owned(kept_id, [OWNER]) is None
    assert not any((tmp_path / "landing").rglob("*.pdf"))
