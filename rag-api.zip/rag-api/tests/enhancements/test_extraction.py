"""Tests for the layout-aware extraction layer. No AWS calls: OCR/caption are fakes."""

import dataclasses

import pytest

from app.enhancements.config import (
    ExtractionMode,
    OcrProvider,
    settings as default_settings,
)
from app.enhancements.extraction import loaders
from app.enhancements.extraction.pdf_layout import extract_pdf_pages, table_to_markdown

fpdf = pytest.importorskip("fpdf")
PIL_Image = pytest.importorskip("PIL.Image")


def _patch_settings(monkeypatch, **overrides):
    new = dataclasses.replace(default_settings, **overrides)
    monkeypatch.setattr(loaders, "settings", new)
    # pdf_layout reads thresholds (dpi, min chars) from its own import
    import app.enhancements.extraction.pdf_layout as layout

    monkeypatch.setattr(layout, "settings", new)
    return new


def _new_pdf():
    pdf = fpdf.FPDF()
    pdf.set_auto_page_break(False)
    pdf.set_font("Helvetica", size=12)
    return pdf


def _text_page(pdf, lines):
    pdf.add_page()
    pdf.set_xy(20, 20)
    for line in lines:
        pdf.cell(0, 8, line, new_x="LMARGIN", new_y="NEXT")


def _long(prefix):
    return f"{prefix} " + "sentence filler words " * 4


def test_text_only_page(tmp_path):
    pdf = _new_pdf()
    _text_page(
        pdf, [_long("Alpha paragraph line one."), _long("Alpha paragraph line two.")]
    )
    path = tmp_path / "text.pdf"
    pdf.output(str(path))

    pages = extract_pdf_pages(str(path))
    assert len(pages) == 1
    assert pages[0].page == 0
    assert "Alpha paragraph line one." in pages[0].markdown
    assert pages[0].table_count == 0
    assert pages[0].ocr_used is False


def test_table_becomes_markdown(tmp_path):
    pdf = _new_pdf()
    pdf.add_page()
    pdf.set_xy(20, 20)
    pdf.cell(0, 8, "Intro line before the table", new_x="LMARGIN", new_y="NEXT")
    pdf.ln(4)
    with pdf.table() as table:
        for r in range(3):
            row = table.row()
            for c in range(3):
                row.cell("Head%d" % c if r == 0 else "r%dc%d" % (r, c))
    path = tmp_path / "table.pdf"
    pdf.output(str(path))

    pages = extract_pdf_pages(str(path))
    md = pages[0].markdown
    assert pages[0].table_count == 1
    assert "| Head0 | Head1 | Head2 |" in md
    assert "| --- |" in md.replace("|---|", "| --- |") or "---" in md
    assert "| r1c0 | r1c1 | r1c2 |" in md
    # table cell text must not also appear as loose text lines
    assert md.count("r1c0") == 1
    assert "Intro line before the table" in md


def test_two_column_reading_order(tmp_path):
    pdf = _new_pdf()
    pdf.add_page()
    for i in range(6):
        pdf.set_xy(15, 30 + i * 10)
        pdf.cell(80, 8, f"LEFTCOL line {i}")
        pdf.set_xy(110, 30 + i * 10)
        pdf.cell(80, 8, f"RIGHTCOL line {i}")
    path = tmp_path / "cols.pdf"
    pdf.output(str(path))

    md = extract_pdf_pages(str(path))[0].markdown
    assert md.index("LEFTCOL line 5") < md.index("RIGHTCOL line 0")


def _png_file(tmp_path):
    img = PIL_Image.new("RGB", (400, 300), "white")
    px = img.load()
    for x in range(400):
        for y in range(300):
            if (x // 20 + y // 20) % 2:
                px[x, y] = (30, 60, 200)
    p = tmp_path / "pic.png"
    img.save(p)
    return p


def _has_ink(png_bytes):
    import io

    return PIL_Image.open(io.BytesIO(png_bytes)).convert("L").getextrema()[0] < 200


def _two_figure_pages(tmp_path):
    """Two text pages, each with a DIFFERENT figure (no dedupe)."""
    first = _png_file(tmp_path)
    second_img = PIL_Image.new("RGB", (400, 300), (200, 40, 40))
    second = tmp_path / "pic2.png"
    second_img.save(second)
    pdf = _new_pdf()
    for png in (first, second):
        _text_page(
            pdf, [_long("Report body text here."), _long("More report body text.")]
        )
        pdf.image(str(png), x=20, y=60, w=150)
    path = tmp_path / "two_figs.pdf"
    pdf.output(str(path))
    return path


def test_model_calls_run_concurrently(tmp_path, monkeypatch):
    """PERF regression: captions/OCR used to run one after another. A barrier
    of 2 only releases if both caption calls are in flight at once."""
    import threading

    _patch_settings(monkeypatch, extraction_concurrency=2)
    barrier = threading.Barrier(2, timeout=10)

    def caption(_png):
        barrier.wait()  # raises BrokenBarrierError if calls are sequential
        return "chart"

    pages = extract_pdf_pages(
        str(_two_figure_pages(tmp_path)), figure_captioner=caption
    )
    assert [p.figure_count for p in pages] == [1, 1]


def test_ocr_page_is_not_captioned_unless_ocr_is_empty(tmp_path):
    png = _png_file(tmp_path)
    pdf = _new_pdf()
    pdf.add_page()
    pdf.image(str(png), x=10, y=10, w=190)  # scanned-style page, no text layer
    path = tmp_path / "scan.pdf"
    pdf.output(str(path))

    captions = []

    def caption(_png):
        captions.append(1)
        return "a checkerboard"

    with_ocr = extract_pdf_pages(
        str(path), page_ocr=lambda b: "TRANSCRIBED", figure_captioner=caption
    )
    assert with_ocr[0].ocr_used and "TRANSCRIBED" in with_ocr[0].markdown
    assert captions == []  # represented by its transcription; no wasted VLM call

    empty_ocr = extract_pdf_pages(
        str(path), page_ocr=lambda b: "", figure_captioner=caption
    )
    assert not empty_ocr[0].ocr_used
    assert "**Figure:** a checkerboard" in empty_ocr[0].markdown


def test_failing_model_call_does_not_fail_document(tmp_path):
    def boom(_png):
        raise RuntimeError("throttled")

    pages = extract_pdf_pages(str(_two_figure_pages(tmp_path)), figure_captioner=boom)
    assert [p.figure_count for p in pages] == [0, 0]
    assert all("Report body text here." in p.markdown for p in pages)


def test_ocr_only_for_low_text_pages(tmp_path):
    png = _png_file(tmp_path)
    pdf = _new_pdf()
    _text_page(pdf, [_long("Native text page one."), _long("Native text page two.")])
    pdf.add_page()
    pdf.image(str(png), x=10, y=10, w=190)
    path = tmp_path / "mixed.pdf"
    pdf.output(str(path))

    calls = []

    def fake_ocr(image_bytes):
        calls.append(image_bytes)
        return "SCANNED TEXT FROM OCR"

    pages = extract_pdf_pages(str(path), page_ocr=fake_ocr)
    assert len(calls) == 1
    assert calls[0][:8] == b"\x89PNG\r\n\x1a\n"
    assert pages[0].ocr_used is False
    assert pages[1].ocr_used is True
    assert "SCANNED TEXT FROM OCR" in pages[1].markdown


def test_loader_marks_ocr_metadata_and_skips_empty(tmp_path, monkeypatch):
    png = _png_file(tmp_path)
    pdf = _new_pdf()
    _text_page(pdf, [_long("Native text page one."), _long("Native text page two.")])
    pdf.add_page()
    pdf.image(str(png), x=10, y=10, w=190)
    pdf.add_page()  # blank page, OCR returns "" -> skipped
    path = tmp_path / "doc.pdf"
    pdf.output(str(path))

    _patch_settings(monkeypatch, ocr_provider=OcrProvider.TEXTRACT)
    # OCR calls run concurrently, so answer from the image itself (a blank
    # page has no ink) rather than from call order.
    monkeypatch.setattr(
        loaders, "_build_ocr", lambda: (lambda b: "OCR PAGE TWO" if _has_ink(b) else "")
    )

    result = loaders.get_enhanced_loader("doc.pdf", "application/pdf", str(path))
    assert result is not None
    loader, known, ext = result
    assert known is True and ext == "pdf"
    assert loader._temp_filepath is None
    docs = loader.load()
    assert [d.metadata["page"] for d in docs] == [0, 1]
    assert docs[0].metadata["total_pages"] == 3
    assert "ocr" not in docs[0].metadata
    assert docs[1].metadata["ocr"] is True
    assert docs[1].page_content.startswith("OCR PAGE TWO")
    assert docs[1].metadata["source"] == str(path)


def test_figure_captions_dedupe_identical_images(tmp_path):
    png = _png_file(tmp_path)
    pdf = _new_pdf()
    for _ in range(2):
        _text_page(
            pdf, [_long("Report body text here."), _long("More report body text.")]
        )
        pdf.image(str(png), x=20, y=60, w=150)
    path = tmp_path / "fig.pdf"
    pdf.output(str(path))

    calls = []

    def fake_caption(image_bytes):
        calls.append(1)
        return "A checkerboard chart"

    pages = extract_pdf_pages(str(path), figure_captioner=fake_caption)
    assert len(calls) == 1
    assert "**Figure:** A checkerboard chart" in pages[0].markdown
    assert pages[0].figure_count == 1
    assert pages[1].figure_count == 0


def test_defaults_fall_through_to_stock(monkeypatch):
    _patch_settings(monkeypatch)
    for name, ctype in [
        ("a.pdf", "application/pdf"),
        ("a.png", "image/png"),
        (
            "a.docx",
            "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        ),
        ("a.pptx", ""),
        ("a.xlsx", ""),
        ("a.md", "text/markdown"),
        ("a.txt", "text/plain"),
        ("a.doc", "application/msword"),
    ]:
        assert loaders.get_enhanced_loader(name, ctype, "/tmp/x") is None


def test_structured_mode_routing(monkeypatch):
    _patch_settings(monkeypatch, extraction=ExtractionMode.STRUCTURED)
    assert isinstance(
        loaders.get_enhanced_loader("a.pdf", "", "/x")[0], loaders.StructuredPdfLoader
    )
    assert isinstance(
        loaders.get_enhanced_loader("a.docx", "", "/x")[0], loaders.MarkdownOfficeLoader
    )
    assert isinstance(
        loaders.get_enhanced_loader("a.md", "", "/x")[0], loaders.RawMarkdownLoader
    )
    assert loaders.get_enhanced_loader("a.md", "", "/x", raw_text=True) is None
    # legacy office and plain text and images (no OCR) use the stock path
    for name in ("a.doc", "a.ppt", "a.xls", "a.txt", "a.png"):
        assert loaders.get_enhanced_loader(name, "", "/x") is None


def test_image_loader_with_fake_ocr(tmp_path, monkeypatch):
    png = _png_file(tmp_path)
    _patch_settings(monkeypatch, ocr_provider=OcrProvider.TEXTRACT)
    monkeypatch.setattr(loaders, "_build_ocr", lambda: (lambda b: "TEXT IN IMAGE"))

    loader, known, ext = loaders.get_enhanced_loader("pic.png", "image/png", str(png))
    assert known is True and ext == "png"
    docs = loader.load()
    assert len(docs) == 1
    assert docs[0].page_content == "TEXT IN IMAGE"
    assert docs[0].metadata == {"source": str(png), "page": 0}

    monkeypatch.setattr(loaders, "_build_ocr", lambda: (lambda b: ""))
    loader, _, _ = loaders.get_enhanced_loader("pic.png", "image/png", str(png))
    assert loader.load() == []


def test_image_loader_with_caption(tmp_path, monkeypatch):
    png = _png_file(tmp_path)
    _patch_settings(monkeypatch, figure_captions=True)
    monkeypatch.setattr(loaders, "_build_captioner", lambda: (lambda b: "a blue chart"))
    loader, _, _ = loaders.get_enhanced_loader("pic.png", "image/png", str(png))
    docs = loader.load()
    assert docs[0].page_content == "**Figure:** a blue chart"


def test_docx_to_markdown(tmp_path, monkeypatch):
    docx = pytest.importorskip("docx")
    d = docx.Document()
    d.add_heading("Quarterly Results", level=1)
    d.add_paragraph("Summary paragraph.")
    table = d.add_table(rows=2, cols=2)
    table.cell(0, 0).text = "Region"
    table.cell(0, 1).text = "Revenue"
    table.cell(1, 0).text = "North"
    table.cell(1, 1).text = "42"
    path = tmp_path / "report.docx"
    d.save(str(path))

    _patch_settings(monkeypatch, extraction=ExtractionMode.STRUCTURED)
    loader, known, ext = loaders.get_enhanced_loader("report.docx", "", str(path))
    docs = loader.load()
    assert len(docs) == 1
    text = docs[0].page_content
    assert "# Quarterly Results" in text
    assert "| Region | Revenue |" in text
    assert "| North | 42 |" in text


def test_markdown_loader_is_verbatim(tmp_path, monkeypatch):
    p = tmp_path / "n.md"
    p.write_text("# Title\n\n## Sub\n\ntext\n", encoding="utf-8")
    _patch_settings(monkeypatch, extraction=ExtractionMode.STRUCTURED)
    loader, _, ext = loaders.get_enhanced_loader("n.md", "text/markdown", str(p))
    assert ext == "md"
    assert loader.load()[0].page_content == "# Title\n\n## Sub\n\ntext\n"


def test_table_to_markdown_escapes():
    md = table_to_markdown([["a|b", None], ["x\ny", "z"], [None, None]])
    lines = md.splitlines()
    assert lines[0] == "| a\\|b |  |"
    assert lines[2] == "| x y | z |"
    assert len(lines) == 3
    assert table_to_markdown([[None]]) == ""
