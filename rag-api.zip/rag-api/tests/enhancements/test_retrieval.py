"""Unit tests for the enhanced retrieval pipeline (no database, no network)."""

import dataclasses
from concurrent.futures import ThreadPoolExecutor

import pytest
from langchain_core.documents import Document

from app.enhancements.config import RetrievalStrategy, load_settings
from app.enhancements.retrieval import expansion, fts, pipeline, rerank
from app.enhancements.retrieval.fusion import (
    ATTEMPT_ID_KEY,
    CHUNK_INDEX_KEY,
    doc_key,
    merge_adjacent_chunks,
    reciprocal_rank_fusion,
)


def chunk(index, text=None, file_id="f1", attempt="a1", page=0):
    return Document(
        page_content=text or f"chunk {index}",
        metadata={
            "file_id": file_id,
            "user_id": "u1",
            "page": page,
            CHUNK_INDEX_KEY: index,
            ATTEMPT_ID_KEY: attempt,
        },
    )


BASE = load_settings()


def cfg(**overrides):
    return dataclasses.replace(BASE, **overrides)


@pytest.fixture
def executor():
    pool = ThreadPoolExecutor(max_workers=2)
    yield pool
    pool.shutdown(wait=True)


# --- fusion -----------------------------------------------------------------


def test_doc_key_matches_same_row_from_different_legs():
    a = chunk(3)
    b = Document(page_content="different object, same row", metadata=dict(a.metadata))
    assert doc_key(a) == doc_key(b)
    assert doc_key(chunk(3)) != doc_key(chunk(4))


def test_doc_key_falls_back_to_digest_for_legacy_rows():
    legacy = Document(page_content="x", metadata={"file_id": "f1", "digest": "abc"})
    assert doc_key(legacy) == ("digest", "f1", "abc")


def test_rrf_single_list_is_passthrough():
    ranked = [(chunk(1), 0.2), (chunk(2), 0.3)]
    assert reciprocal_rank_fusion([ranked]) == ranked


def test_rrf_promotes_items_found_by_both_legs_and_scores_are_monotonic():
    vector = [(chunk(1), 0.1), (chunk(2), 0.2), (chunk(3), 0.3)]
    lexical = [(chunk(3), 9.0), (chunk(4), 5.0)]
    fused = reciprocal_rank_fusion([vector, lexical], k=60)

    keys = [d.metadata[CHUNK_INDEX_KEY] for d, _ in fused]
    assert keys[0] == 3  # in both lists
    assert set(keys) == {1, 2, 3, 4}
    distances = [s for _, s in fused]
    assert distances == sorted(distances)
    assert all(0.0 <= s < 1.0 for s in distances)


def test_rrf_top_of_every_list_gets_zero_distance():
    fused = reciprocal_rank_fusion([[(chunk(1), 0.4)], [(chunk(1), 3.0)]])
    assert fused[0][1] == pytest.approx(0.0)


# --- merge ------------------------------------------------------------------


def test_merge_joins_consecutive_chunks_and_keeps_first_metadata():
    results = [(chunk(5, page=1), 0.3), (chunk(4, page=1), 0.1), (chunk(9), 0.2)]
    merged = merge_adjacent_chunks(results)

    assert len(merged) == 2
    top_doc, top_score = merged[0]
    assert top_doc.page_content == "chunk 4\n\nchunk 5"
    assert top_doc.metadata["page"] == 1
    assert top_doc.metadata["merged_chunk_count"] == 2
    assert top_score == 0.1
    assert merged[1][0].page_content == "chunk 9"


def test_merge_never_crosses_a_page_boundary():
    """Regression: a passage spanning pages was cited as its first page only,
    pointing readers at the wrong page for the answer."""
    results = [
        (chunk(1, page=0), 0.5),
        (chunk(2, page=1), 0.1),
        (chunk(3, page=1), 0.2),
    ]
    merged = merge_adjacent_chunks(results)
    assert [(d.metadata["page"], d.page_content) for d, _ in merged] == [
        (1, "chunk 2\n\nchunk 3"),
        (0, "chunk 1"),
    ]


def test_merge_does_not_cross_files_or_attempts():
    results = [
        (chunk(1, file_id="f1"), 0.1),
        (chunk(2, file_id="f2"), 0.2),
        (chunk(3, file_id="f1", attempt="other"), 0.3),
    ]
    assert len(merge_adjacent_chunks(results)) == 3


def test_merge_passes_through_chunks_without_index():
    plain = Document(page_content="p", metadata={"file_id": "f1"})
    out = merge_adjacent_chunks([(plain, 0.5), (chunk(1), 0.1)])
    assert [d.page_content for d, _ in out] == ["chunk 1", "p"]


# --- rerank -----------------------------------------------------------------


class FakeCrossEncoder:
    """Scores a pair by how many query words appear in the chunk."""

    def predict(self, pairs):
        return [
            float(sum(w in text for w in query.split())) * 4 - 2
            for query, text in pairs
        ]


def test_rerank_reorders_and_returns_distances(monkeypatch):
    monkeypatch.setitem(rerank._MODELS, "fake", FakeCrossEncoder())
    candidates = [
        (chunk(1, "nothing relevant"), 0.1),
        (chunk(2, "quarterly revenue grew"), 0.4),
        (chunk(3, "revenue"), 0.3),
    ]
    out = rerank.rerank("fake", "quarterly revenue", candidates, top_k=2)
    assert [d.metadata[CHUNK_INDEX_KEY] for d, _ in out] == [2, 3]
    assert out[0][1] < out[1][1]
    assert all(0.0 < s < 1.0 for _, s in out)


def test_rerank_failure_keeps_first_stage_order(monkeypatch):
    class Broken:
        def predict(self, pairs):
            raise RuntimeError("boom")

    monkeypatch.setitem(rerank._MODELS, "broken", Broken())
    candidates = [(chunk(1), 0.1), (chunk(2), 0.2), (chunk(3), 0.3)]
    assert rerank.rerank("broken", "q", candidates, top_k=2) == candidates[:2]


# --- expansion --------------------------------------------------------------


def test_parse_variants_drops_numbering_duplicates_and_original():
    raw = "1. Net sales growth\n- revenue growth\nnet sales growth\nRevenue Growth?\n\n"
    variants = expansion.parse_variants("Revenue growth?", raw, count=3)
    assert variants == ["Net sales growth", "revenue growth"]


# --- full-text SQL ----------------------------------------------------------


def test_fts_sql_uses_index_expression_and_scope():
    sql = fts.build_search_sql("english")
    index_sql = fts.build_index_sql("english")
    expr = "to_tsvector('english'::regconfig, document)"
    assert expr in sql and expr in index_sql
    assert "CONCURRENTLY" in index_sql
    for clause in ("c.name = $2", "'file_id' = ANY($3", "'user_id' = ANY($4"):
        assert clause in sql


def test_unsafe_fts_language_is_rejected(monkeypatch):
    monkeypatch.setenv("RAG_FTS_LANGUAGE", "english'; drop table x; --")
    with pytest.raises(ValueError):
        load_settings()


@pytest.mark.asyncio
async def test_fts_search_degrades_to_empty_on_db_error():
    class BrokenPool:
        def acquire(self):
            raise RuntimeError("db down")

    out = await fts.fts_search(
        BrokenPool(),
        query="q",
        collection_name="c",
        file_ids=["f"],
        owners=["u"],
        limit=5,
    )
    assert out == []


# --- pipeline ---------------------------------------------------------------


def make_vector_search(results, calls):
    async def vector_search(embedding, k, filter_):
        calls.append({"embedding": embedding, "k": k, "filter": filter_})
        return list(results)[:k]

    return vector_search


def no_threshold(docs):
    return docs


@pytest.mark.asyncio
async def test_pipeline_vector_only_with_merge_keeps_k_and_contract(executor):
    calls = []
    results = [(chunk(1), 0.1), (chunk(2), 0.2), (chunk(7), 0.3)]
    out = await pipeline.enhanced_search(
        query="q",
        k=3,
        file_ids=["f1"],
        owners=["u1"],
        query_filter={"scoped": True},
        vector_search=make_vector_search(results, calls),
        embed_query=lambda text: [0.0, 1.0],
        executor=executor,
        distance_threshold=no_threshold,
        cfg=cfg(merge_adjacent_chunks=True),
    )
    assert calls[0]["k"] == 3  # merge-only does not oversample
    assert calls[0]["filter"] == {"scoped": True}  # stock scope is passed through
    assert [d.page_content for d, _ in out] == ["chunk 1\n\nchunk 2", "chunk 7"]


@pytest.mark.asyncio
async def test_pipeline_hybrid_fuses_lexical_leg_with_same_scope(executor, monkeypatch):
    seen = {}

    async def fake_fts(pool, **kwargs):
        seen.update(kwargs)
        return [(chunk(9, "exact SKU-123 match"), 4.2)]

    monkeypatch.setattr(fts, "fts_search", fake_fts)

    async def pool_getter():
        return object()

    calls = []
    out = await pipeline.enhanced_search(
        query="SKU-123",
        k=2,
        file_ids=["f1"],
        owners=["u1", "entity"],
        query_filter={},
        vector_search=make_vector_search([(chunk(1), 0.1), (chunk(2), 0.2)], calls),
        embed_query=lambda text: [1.0],
        executor=executor,
        distance_threshold=no_threshold,
        pg_pool_getter=pool_getter,
        collection_name="testcollection",
        cfg=cfg(retrieval=RetrievalStrategy.HYBRID, candidate_pool=10),
    )
    assert calls[0]["k"] == 10  # oversampled for fusion
    assert seen["file_ids"] == ["f1"] and seen["owners"] == ["u1", "entity"]
    assert seen["collection_name"] == "testcollection"
    assert len(out) == 2
    assert 9 in [d.metadata[CHUNK_INDEX_KEY] for d, _ in out]
    assert [s for _, s in out] == sorted(s for _, s in out)


@pytest.mark.asyncio
async def test_pipeline_hybrid_without_pool_falls_back_to_vector(executor):
    calls = []
    out = await pipeline.enhanced_search(
        query="q",
        k=1,
        file_ids=["f1"],
        owners=["u1"],
        query_filter={},
        vector_search=make_vector_search([(chunk(1), 0.1), (chunk(2), 0.2)], calls),
        embed_query=lambda text: [1.0],
        executor=executor,
        distance_threshold=no_threshold,
        pg_pool_getter=None,
        cfg=cfg(retrieval=RetrievalStrategy.HYBRID),
    )
    assert out == [(out[0][0], 0.1)]


@pytest.mark.asyncio
async def test_pipeline_rerank_uses_original_query_and_returns_k(executor, monkeypatch):
    monkeypatch.setitem(rerank._MODELS, "fake", FakeCrossEncoder())
    results = [(chunk(i, "filler"), 0.1 * i) for i in range(1, 6)]
    results.append((chunk(6, "the warranty period is two years"), 0.9))
    out = await pipeline.enhanced_search(
        query="warranty period",
        k=2,
        file_ids=["f1"],
        owners=["u1"],
        query_filter={},
        vector_search=make_vector_search(results, []),
        embed_query=lambda text: [1.0],
        executor=executor,
        distance_threshold=no_threshold,
        cfg=cfg(rerank=True, rerank_model="fake", candidate_pool=10),
    )
    assert len(out) == 2
    assert out[0][0].metadata[CHUNK_INDEX_KEY] == 6


@pytest.mark.asyncio
async def test_pipeline_expansion_searches_each_phrasing(executor, monkeypatch):
    monkeypatch.setattr(
        expansion, "get_expander", lambda model, count: lambda q: ["alt one", "alt two"]
    )
    embedded = []

    def embed(text):
        embedded.append(text)
        return [1.0]

    await pipeline.enhanced_search(
        query="original",
        k=2,
        file_ids=["f1"],
        owners=["u1"],
        query_filter={},
        vector_search=make_vector_search([(chunk(1), 0.1)], []),
        embed_query=embed,
        executor=executor,
        distance_threshold=no_threshold,
        cfg=cfg(query_expansion=True),
    )
    assert sorted(embedded) == ["alt one", "alt two", "original"]


@pytest.mark.asyncio
async def test_pipeline_applies_stock_distance_threshold_to_vector_leg(executor):
    def threshold(docs):
        return [(d, s) for d, s in docs if s <= 0.25]

    out = await pipeline.enhanced_search(
        query="q",
        k=5,
        file_ids=["f1"],
        owners=["u1"],
        query_filter={},
        vector_search=make_vector_search([(chunk(1), 0.1), (chunk(5), 0.6)], []),
        embed_query=lambda text: [1.0],
        executor=executor,
        distance_threshold=threshold,
        cfg=cfg(merge_adjacent_chunks=True),
    )
    assert [d.metadata[CHUNK_INDEX_KEY] for d, _ in out] == [1]


def test_defaults_leave_stock_pipeline_untouched():
    defaults = load_settings()
    assert not defaults.retrieval_pipeline_enabled
    assert not defaults.enhanced_extraction_enabled
    assert not defaults.raw_upload_landing
    assert pipeline.candidate_pool_size(4, defaults) == 4
