"""Startup and dispatch hooks: every enabled feature must start cleanly."""

import asyncio
import dataclasses
from concurrent.futures import ThreadPoolExecutor
from types import SimpleNamespace

import pytest

from app.enhancements import hooks, raw_uploads
from app.enhancements.config import RetrievalStrategy, load_settings
from app.enhancements.retrieval import fts, rerank


@pytest.fixture
def app():
    pool = ThreadPoolExecutor(max_workers=2)
    yield SimpleNamespace(state=SimpleNamespace(thread_pool=pool))
    pool.shutdown(wait=True)


async def test_startup_with_every_feature_enabled_schedules_background_work(
    app, monkeypatch
):
    """Regression: reranker warm-up runs in an executor, which yields a Future;
    scheduling it with create_task crashed application startup."""
    cfg = dataclasses.replace(
        load_settings(),
        rerank=True,
        rerank_model="fake-model",
        retrieval=RetrievalStrategy.HYBRID,
        raw_upload_landing=True,
    )
    monkeypatch.setattr(hooks, "settings", cfg)

    warmed, indexed, stores = [], [], []
    monkeypatch.setattr(rerank, "warm_up", lambda model: warmed.append(model))

    async def fake_index(pool, language):
        indexed.append(language)

    async def fake_init_store(pool):
        stores.append(pool)

    monkeypatch.setattr(fts, "ensure_fts_index", fake_index)
    monkeypatch.setattr(raw_uploads, "init_store", fake_init_store)

    async def pool_getter():
        return "pool"

    await hooks.on_startup(app, is_pgvector=True, pg_pool_getter=pool_getter)
    await asyncio.gather(*list(hooks._background_tasks))

    assert warmed == ["fake-model"]
    assert indexed == ["english"]
    assert stores == ["pool"]


async def test_startup_skips_postgres_features_on_other_stores(app, monkeypatch):
    cfg = dataclasses.replace(
        load_settings(), retrieval=RetrievalStrategy.HYBRID, raw_upload_landing=True
    )
    monkeypatch.setattr(hooks, "settings", cfg)
    called = []

    async def fail(*args, **kwargs):
        called.append(args)

    monkeypatch.setattr(fts, "ensure_fts_index", fail)
    monkeypatch.setattr(raw_uploads, "init_store", fail)

    await hooks.on_startup(app, is_pgvector=False, pg_pool_getter=None)
    assert called == []


async def test_defaults_are_inert(app, monkeypatch):
    monkeypatch.setattr(hooks, "settings", load_settings())
    await hooks.on_startup(app, is_pgvector=True, pg_pool_getter=None)
    assert hooks.get_loader_override("a.pdf", "application/pdf", "/tmp/a.pdf") is None
    assert (
        await hooks.search(
            None,
            query="q",
            k=1,
            file_ids=[],
            scope=None,
            query_filter={},
            vector_store=None,
            embed_query=None,
            distance_threshold=None,
        )
        is None
    )
