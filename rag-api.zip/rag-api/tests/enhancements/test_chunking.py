"""Tests for the opt-in chunking strategies (app.enhancements.chunking)."""

import dataclasses
import re

import pytest
from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter

from app.enhancements import chunking
from app.enhancements.chunking import (
    StructureSplitter,
    TableAwareSplitter,
    build_text_splitter,
)
from app.enhancements.config import ChunkingStrategy, settings

META = {"page": 3, "source": "x.pdf"}


def _table(n_rows: int) -> str:
    lines = ["| Region | Revenue |", "| --- | --- |"]
    lines += [f"| R{i} | {i * 10} |" for i in range(n_rows)]
    return "\n".join(lines)


def _report_doc(n_rows: int = 6) -> Document:
    md = (
        "# Report\n\nIntro paragraph about the company.\n\n"
        "## Revenue\n\nRevenue grew across regions.\n\n" + _table(n_rows) + "\n"
    )
    return Document(page_content=md, metadata=dict(META))


def test_recursive_returns_stock_splitter():
    s = build_text_splitter(500, 50, ChunkingStrategy.RECURSIVE)
    assert isinstance(s, RecursiveCharacterTextSplitter)
    assert s._chunk_size == 500
    assert s._chunk_overlap == 50


def test_default_strategy_comes_from_settings(monkeypatch):
    monkeypatch.setattr(
        chunking,
        "settings",
        dataclasses.replace(settings, chunking=ChunkingStrategy.TABLE_AWARE),
    )
    assert isinstance(build_text_splitter(500, 50), TableAwareSplitter)


def test_table_aware_never_splits_mid_row_and_repeats_header():
    s = TableAwareSplitter(2000, 0, rows_per_chunk=20)
    chunks = s.split_documents([Document(page_content=_table(50), metadata=dict(META))])
    assert len(chunks) == 3  # 20 + 20 + 10 rows
    seen_rows = []
    for c in chunks:
        lines = c.page_content.split("\n")
        assert lines[0] == "| Region | Revenue |"
        assert lines[1] == "| --- | --- |"
        for row in lines[2:]:
            assert re.fullmatch(r"\| R\d+ \| \d+ \|", row)
            seen_rows.append(row)
    assert len(seen_rows) == 50 and len(set(seen_rows)) == 50


def test_table_aware_keeps_small_table_whole():
    s = TableAwareSplitter(2000, 0, rows_per_chunk=20)
    text = "Before the table.\n\n" + _table(5) + "\n\nAfter the table."
    chunks = [c.page_content for c in s.split_documents([Document(page_content=text)])]
    assert _table(5) in chunks
    assert any("Before" in c for c in chunks) and any("After" in c for c in chunks)


@pytest.mark.parametrize("strategy", list(ChunkingStrategy))
def test_metadata_preserved_on_every_chunk(strategy):
    docs = [
        _report_doc(50),
        Document(page_content="Plain text. " * 200, metadata=dict(META)),
    ]
    chunks = build_text_splitter(300, 30, strategy).split_documents(docs)
    assert len(chunks) > 2
    for c in chunks:
        assert c.metadata["page"] == 3
        assert c.metadata["source"] == "x.pdf"


def test_structure_includes_heading_path():
    pytest.importorskip("docling_core")
    pytest.importorskip("marko")
    chunks = StructureSplitter(500, 50).split_documents([_report_doc()])
    assert chunks
    revenue = [
        c.page_content
        for c in chunks
        if "R3" in c.page_content or "Revenue grew" in c.page_content
    ]
    assert revenue
    for text in revenue:
        assert "Report" in text and "Revenue" in text


def test_structure_respects_max_tokens():
    pytest.importorskip("docling_core")
    pytest.importorskip("marko")
    import tiktoken

    enc = tiktoken.get_encoding(settings.structure_chunk_tokenizer)
    max_tokens = 60
    long_para = " ".join(f"word{i}" for i in range(400))
    doc = Document(
        page_content=f"# Report\n\n## Revenue\n\n{long_para}\n\n{_table(40)}\n",
        metadata=dict(META),
    )
    chunks = StructureSplitter(500, 50, max_tokens=max_tokens).split_documents([doc])
    assert len(chunks) > 3
    prefix_allowance = len(enc.encode("Report\nRevenue\n")) + 10
    for c in chunks:
        assert len(enc.encode(c.page_content)) <= max_tokens + prefix_allowance


def test_structure_falls_back_when_docling_import_fails(monkeypatch):
    pytest.importorskip("docling_core")
    s = StructureSplitter(500, 50)

    def boom(*_a, **_k):
        raise ImportError("docling_core unavailable")

    monkeypatch.setattr(chunking, "markdown_to_structured_document", boom)
    chunks = s.split_documents([_report_doc(50)])
    assert chunks
    assert all(c.metadata == META for c in chunks)
    table_chunks = [
        c.page_content for c in chunks if c.page_content.startswith("| Region")
    ]
    assert table_chunks  # table-aware fallback ran (header repeated per fragment)


def test_build_degrades_to_table_aware_without_deps(monkeypatch):
    monkeypatch.setattr(chunking, "_structure_deps_available", lambda: False)
    s = build_text_splitter(500, 50, ChunkingStrategy.STRUCTURE)
    assert isinstance(s, TableAwareSplitter)
