"""Self-hosted embedding server client (no network: httpx MockTransport)."""

import json
import threading

import httpx
import pytest

from app.enhancements.tei import TeiEmbeddings


def server(record, fail_first=0, status=429):
    """Fake /embed: vector = [first char code, batch length]."""
    lock = threading.Lock()
    state = {"failures": fail_first}

    def handler(request: httpx.Request) -> httpx.Response:
        body = json.loads(request.content)
        with lock:
            record.append(body)
            if state["failures"] > 0:
                state["failures"] -= 1
                return httpx.Response(status)
        return httpx.Response(
            200,
            json=[
                [float(ord(t[0])), float(len(body["inputs"]))] for t in body["inputs"]
            ],
        )

    return httpx.MockTransport(handler)


def test_documents_are_split_into_server_sized_batches_in_order():
    record = []
    client = TeiEmbeddings(
        "http://tei/", batch_size=3, concurrency=3, transport=server(record)
    )
    texts = [chr(ord("a") + i) for i in range(8)]
    vectors = client.embed_documents(texts)

    assert [v[0] for v in vectors] == [float(ord(t)) for t in texts]  # order preserved
    assert sorted(len(b["inputs"]) for b in record) == [2, 3, 3]
    assert all(b["truncate"] is True and b["normalize"] is True for b in record)


def test_busy_server_is_retried_then_succeeds():
    record = []
    client = TeiEmbeddings(
        "http://tei", transport=server(record, fail_first=2), retry_delay=0.0
    )
    assert client.embed_query("q") == [float(ord("q")), 1.0]
    assert len(record) == 3


def test_persistent_failure_raises_with_reason():
    client = TeiEmbeddings(
        "http://tei",
        transport=server([], fail_first=99, status=503),
        max_retries=3,
        retry_delay=0.0,
    )
    with pytest.raises(RuntimeError, match="HTTP 503"):
        client.embed_documents(["x"])


def test_client_errors_are_not_retried():
    record = []
    client = TeiEmbeddings(
        "http://tei",
        transport=server(record, fail_first=1, status=413),
        retry_delay=0.0,
    )
    with pytest.raises(httpx.HTTPStatusError):
        client.embed_documents(["x"])
    assert len(record) == 1


def test_query_prefix_applies_to_queries_only():
    record = []
    client = TeiEmbeddings("http://tei", query_prefix="Q: ", transport=server(record))
    client.embed_query("hello")
    client.embed_documents(["doc"])
    assert record[0]["inputs"] == ["Q: hello"]
    assert record[1]["inputs"] == ["doc"]


def test_provider_routes_urls_to_self_hosted_client(monkeypatch):
    """Regression: a server URL crashed startup ("model must be a HuggingFace
    repo ID, not a URL")."""
    from app.config import EmbeddingsProvider, init_embeddings

    monkeypatch.setenv("RAG_TEI_BATCH_SIZE", "16")
    emb = init_embeddings(EmbeddingsProvider.HUGGINGFACETEI, "http://tei.rag.svc:80")
    assert isinstance(emb, TeiEmbeddings)
    assert emb.base_url == "http://tei.rag.svc:80" and emb.batch_size == 16
