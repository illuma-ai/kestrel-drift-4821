"""Split a model's ``model.safetensors`` into shards below a size limit.

Why: Git hosts reject single files over 100 MB, while the embedding model's
weights are ~438 MB. The Hugging Face sharded layout
(``model-0000N-of-0000M.safetensors`` + ``model.safetensors.index.json``) is
loaded natively by the embedding server, so the model can live in a git
repository and be served with no network access. Tensors are copied
unchanged (no quantisation), so embeddings are bit-identical.

Usage:
    python scripts/shard_model.py <model_dir> [--max-mb 90]
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from safetensors.numpy import load_file, save_file


def shard(model_dir: Path, max_bytes: int) -> list[Path]:
    """Shard ``model_dir/model.safetensors`` in place; returns the shard paths."""
    source = model_dir / "model.safetensors"
    tensors = load_file(str(source))

    groups: list[dict] = [{}]
    size = 0
    for name in sorted(tensors):
        nbytes = tensors[name].nbytes
        if groups[-1] and size + nbytes > max_bytes:
            groups.append({})
            size = 0
        groups[-1][name] = tensors[name]
        size += nbytes

    total = len(groups)
    weight_map: dict[str, str] = {}
    paths: list[Path] = []
    for i, group in enumerate(groups, start=1):
        shard_name = f"model-{i:05d}-of-{total:05d}.safetensors"
        save_file(group, str(model_dir / shard_name), metadata={"format": "pt"})
        weight_map.update({name: shard_name for name in group})
        paths.append(model_dir / shard_name)

    index = {
        "metadata": {"total_size": sum(t.nbytes for t in tensors.values())},
        "weight_map": weight_map,
    }
    (model_dir / "model.safetensors.index.json").write_text(json.dumps(index, indent=2))
    source.unlink()
    return paths


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("model_dir", type=Path)
    parser.add_argument("--max-mb", type=int, default=90)
    args = parser.parse_args()
    for path in shard(args.model_dir, args.max_mb * 1024 * 1024):
        print(f"{path.stat().st_size / 1_048_576:7.1f} MB  {path.name}")


if __name__ == "__main__":
    main()
