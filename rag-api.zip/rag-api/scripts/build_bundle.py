"""Build the release bundle: branded source zip + sharded model files.

Steps:
1. Export the working tree (tracked + untracked, honouring .gitignore).
2. Apply the brand (scripts/rebrand.py) to the export and verify none remains.
3. Zip it as ``rag-api.zip`` (top-level folder ``rag-api/``).
4. Copy the sharded embedding model to ``rag-api-models/<model>/`` next to the
   zip, refusing any file at or above the git host's 100 MB limit.

Usage:
    python scripts/build_bundle.py --model-dir <sharded-model-dir> --out <bundle-dir> [--brand Ranger]
"""

from __future__ import annotations

import argparse
import importlib.util
import shutil
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

REPO = Path(__file__).resolve().parents[1]
MAX_FILE_BYTES = 100 * 1024 * 1024


def _rebrand_module():
    spec = importlib.util.spec_from_file_location(
        "rebrand", REPO / "scripts" / "rebrand.py"
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def export_tree(dest: Path) -> int:
    files = (
        subprocess.run(
            ["git", "ls-files", "-co", "--exclude-standard", "-z"],
            cwd=REPO,
            check=True,
            capture_output=True,
        )
        .stdout.decode()
        .split("\0")
    )
    count = 0
    for rel in filter(None, files):
        src = REPO / rel
        if not src.is_file():
            continue  # deleted but still tracked
        target = dest / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, target)
        count += 1
    return count


def zip_dir(src: Path, zip_path: Path, arc_root: str) -> None:
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED, compresslevel=9) as zf:
        for path in sorted(src.rglob("*")):
            if path.is_file():
                zf.write(path, f"{arc_root}/{path.relative_to(src).as_posix()}")


def copy_model(model_dir: Path, dest: Path) -> list[tuple[str, int]]:
    if (model_dir / "model.safetensors").exists():
        raise SystemExit("model is not sharded: run scripts/shard_model.py first")
    if dest.exists():
        shutil.rmtree(dest)
    shutil.copytree(model_dir, dest, ignore=shutil.ignore_patterns(".cache"))
    sizes = [
        (p.relative_to(dest).as_posix(), p.stat().st_size)
        for p in dest.rglob("*")
        if p.is_file()
    ]
    too_big = [name for name, size in sizes if size >= MAX_FILE_BYTES]
    if too_big:
        raise SystemExit(f"files at or above 100 MB cannot be pushed: {too_big}")
    return sizes


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--model-dir", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--brand", default="Ranger")
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=True)
    rebrand = _rebrand_module()

    with tempfile.TemporaryDirectory() as tmp:
        staging = Path(tmp) / "rag-api"
        count = export_tree(staging)
        rebrand.main([str(staging), "--brand", args.brand])
        if rebrand.main([str(staging), "--check"]) != 0:
            print("brand check failed; bundle not written", file=sys.stderr)
            return 1
        zip_path = args.out / "rag-api.zip"
        zip_dir(staging, zip_path, "rag-api")

    sizes = copy_model(
        args.model_dir, args.out / "rag-api-models" / args.model_dir.name
    )
    print(f"rag-api.zip: {count} files, {zip_path.stat().st_size / 1_048_576:.1f} MB")
    print(
        f"rag-api-models/{args.model_dir.name}: {len(sizes)} files, "
        f"largest {max(s for _, s in sizes) / 1_048_576:.1f} MB"
    )
    return 0


if __name__ == "__main__":
    sys.exit(main())
