"""Rename every upstream product reference to a target brand across a tree.

Rewrites file contents AND file/folder names, preserving case style. The
upstream product name is matched in every spelling (mixed case, lower, upper,
and with a space, hyphen or underscore between its two words), as is its first
word on its own. Mixed case becomes ``Ranger``, lower case ``ranger`` and upper
case ``RANGER``. The patterns are assembled in code so this file never contains
the name it removes.

Markdown links that point at the upstream product's site are reduced to their
(renamed) link text, so they do not become dead links to a guessed domain.

"lc" / "LC" abbreviations are REPORTED, and only rewritten when an explicit
replacement is given (``--lc-to``): blind replacement would corrupt library
identifiers such as the ``lc_`` attributes of the LLM framework.

Run it on an exported copy (the release bundle), not on the source checkout:
keeping the checkout untouched keeps future upstream pulls conflict-free.

Usage:
    python scripts/rebrand.py <dir> [--brand Ranger] [--lc-to rg] [--dry-run]
    python scripts/rebrand.py <dir> --check     # exit 1 if any reference remains
"""

from __future__ import annotations

import argparse
import os
import re
import sys
from pathlib import Path

SKIP_DIRS = {
    ".git",
    ".venv",
    "venv",
    "node_modules",
    "__pycache__",
    ".pytest_cache",
    ".mypy_cache",
}
# Upstream product name as a regex (assembled so this file never matches itself).
_FIRST = "lib" + "re"
_PRODUCT = _FIRST + r"[\s_\-]?" + "chat"
_PRODUCT_RE = re.compile(_PRODUCT, re.IGNORECASE)
_STANDALONE_RE = re.compile(r"(?<![A-Za-z])" + _FIRST + r"(?![A-Za-z])", re.IGNORECASE)
_LINK_RE = re.compile(
    r"\[([^\]]*)\]\((https?://[^)\s]*" + _PRODUCT + r"[^)\s]*)\)", re.IGNORECASE
)
_LC_RE = re.compile(r"(?<![A-Za-z0-9])(lc|LC)(?=[_\-.]|(?![A-Za-z0-9]))")


def _cased(match_text: str, brand: str) -> str:
    """Match the case style of the original token."""
    letters = [c for c in match_text if c.isalpha()]
    if letters and all(c.isupper() for c in letters):
        return brand.upper()
    if letters and all(c.islower() for c in letters):
        return brand.lower()
    return brand[0].upper() + brand[1:]


def rewrite_text(text: str, brand: str, lc_to: str | None = None) -> str:
    """Return ``text`` with every product reference renamed."""
    text = _LINK_RE.sub(lambda m: m.group(1), text)
    text = _PRODUCT_RE.sub(lambda m: _cased(m.group(0), brand), text)
    text = _STANDALONE_RE.sub(lambda m: _cased(m.group(0), brand), text)
    if lc_to:
        text = _LC_RE.sub(
            lambda m: lc_to.upper() if m.group(1).isupper() else lc_to.lower(), text
        )
    return text


def find_references(text: str) -> list[str]:
    """Every remaining product reference (used by --check and the report)."""
    return [m.group(0) for m in _PRODUCT_RE.finditer(text)] + [
        m.group(0) for m in _STANDALONE_RE.finditer(text)
    ]


def find_lc(text: str) -> list[tuple[int, str]]:
    return [
        (i, line.strip())
        for i, line in enumerate(text.splitlines(), 1)
        if _LC_RE.search(line)
    ]


def _is_text(path: Path) -> bool:
    try:
        with open(path, "rb") as fh:
            return b"\0" not in fh.read(8192)
    except OSError:
        return False


def _walk(root: Path, self_path: Path):
    for dirpath, dirnames, filenames in os.walk(root, topdown=True):
        dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
        for name in filenames:
            path = Path(dirpath) / name
            if path.resolve() != self_path:
                yield path


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("root", type=Path)
    parser.add_argument("--brand", default="Ranger")
    parser.add_argument(
        "--lc-to",
        default=None,
        help="replacement for lc/LC tokens (reported only if unset)",
    )
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument(
        "--check", action="store_true", help="exit 1 if any reference remains"
    )
    args = parser.parse_args(argv)

    root = args.root.resolve()
    self_path = Path(__file__).resolve()
    changed_files, renamed, remaining, lc_hits = 0, [], [], []

    for path in list(_walk(root, self_path)):
        rel = path.relative_to(root)
        if _PRODUCT_RE.search(str(rel)) or _STANDALONE_RE.search(str(rel)):
            remaining.append(f"{rel} (path)")
        if not _is_text(path):
            continue
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            continue
        lc_hits += [(rel, i, line) for i, line in find_lc(text)]
        if args.check:
            remaining += [f"{rel}: {ref}" for ref in find_references(text)]
            continue
        new = rewrite_text(text, args.brand, args.lc_to)
        if new != text:
            changed_files += 1
            if not args.dry_run:
                path.write_text(new, encoding="utf-8", newline="")

    if not args.check:
        # Rename deepest paths first so parent renames don't invalidate children.
        paths = sorted(
            (
                p
                for p in root.rglob("*")
                if not (set(p.relative_to(root).parts) & SKIP_DIRS)
            ),
            key=lambda p: len(p.parts),
            reverse=True,
        )
        for path in paths:
            new_name = rewrite_text(path.name, args.brand, args.lc_to)
            if new_name != path.name:
                renamed.append(f"{path.relative_to(root)} -> {new_name}")
                if not args.dry_run:
                    path.rename(path.with_name(new_name))

    mode = "check" if args.check else ("dry-run" if args.dry_run else "applied")
    print(f"[{mode}] files rewritten: {changed_files}, paths renamed: {len(renamed)}")
    for item in renamed:
        print(f"  rename {item}")
    if lc_hits:
        action = (
            f"rewritten to '{args.lc_to}'"
            if args.lc_to and not args.check
            else "REVIEW (not rewritten)"
        )
        print(f"lc/LC tokens ({len(lc_hits)}) - {action}:")
        for rel, i, line in lc_hits:
            print(f"  {rel}:{i}: {line[:120]}")
    if args.check:
        for item in remaining:
            print(f"  remaining {item}")
        print(f"remaining references: {len(remaining)}")
        return 1 if remaining else 0
    return 0


if __name__ == "__main__":
    sys.exit(main())
