# Production deployment on EKS

This guide deploys two services into one namespace (`ranger`):

| Service | Image | What it does |
|---|---|---|
| `rag-api` | `ranger-rag-api` (built from `Dockerfile`) | Upload, extraction, OCR, chunking, search API called by the chat app |
| `embeddings-server` | `ranger-rag-embeddings` (built from `deploy/embeddings/Dockerfile`) | Turns text into vectors with `BAAI/bge-base-en-v1.5` on CPU, model baked in |

Plus two things outside the cluster: **Postgres with pgvector** (RDS) and
**AWS Textract** (OCR only, reached through the pod's IAM role).

Nothing is downloaded at runtime: the embedding model is inside its image, the
tokenizer data is inside the rag-api image, and model-hub access is switched
off (`HF_HUB_OFFLINE=1`). No API keys are used anywhere.

```
chat app ──HTTP + JWT──▶ rag-api ──▶ embeddings-server (in cluster)
                           │  ├────▶ Postgres + pgvector (RDS)
                           │  └────▶ AWS Textract (IRSA role, OCR only)
```

## 1. Prerequisites

- An EKS cluster with the OIDC provider enabled (needed for IRSA) and nodes
  with at least 4 vCPU / 8 GiB free across the namespace.
- The metrics server installed (for the autoscalers).
- An ECR registry the nodes can pull from.
- RDS for PostgreSQL 15+ reachable from the cluster's subnets.
- On your build machine: Docker, AWS CLI v2, kubectl.

## 2. Unpack the bundle

The source bundle repository contains `rag-api.zip` (source) and
`rag-api-models/` (model files, already split into files under 100 MB):

```bash
unzip rag-api.zip                     # -> rag-api/
mkdir -p rag-api/models
cp -r rag-api-models/bge-base-en-v1.5 rag-api/models/
cd rag-api
ls models/bge-base-en-v1.5            # config.json, tokenizer files, model-0000N-of-00006.safetensors, index
ls models/tiktoken                    # tokenizer data used by the chunker
```

## 3. Build and push the two images

```bash
export AWS_REGION=us-east-1
export ECR_REGISTRY=<account-id>.dkr.ecr.$AWS_REGION.amazonaws.com
export TAG=$(date +%Y%m%d)-1

aws ecr create-repository --repository-name ranger-rag-api        --region $AWS_REGION || true
aws ecr create-repository --repository-name ranger-rag-embeddings --region $AWS_REGION || true
aws ecr get-login-password --region $AWS_REGION | docker login --username AWS --password-stdin $ECR_REGISTRY

# rag-api (the model weights are excluded by .dockerignore; tokenizer data is included)
docker build -t $ECR_REGISTRY/ranger-rag-api:$TAG .
docker push $ECR_REGISTRY/ranger-rag-api:$TAG

# embedding server: the build context is the model folder itself
docker build -f deploy/embeddings/Dockerfile \
  -t $ECR_REGISTRY/ranger-rag-embeddings:bge-base-en-v1.5 models/bge-base-en-v1.5
docker push $ECR_REGISTRY/ranger-rag-embeddings:bge-base-en-v1.5
```

Both base images come from public registries (Docker Hub `python:3.12` and
`ghcr.io/huggingface/text-embeddings-inference:cpu-1.8`). If build hosts have no
internet access, mirror those two images into ECR first and change the `FROM`
lines.

Optional local check that the embedding image needs no network:

```bash
docker run --rm --network none $ECR_REGISTRY/ranger-rag-embeddings:bge-base-en-v1.5
# logs end with "Ready"
```

## 4. Database

Create the database and the vector extension once, as an admin user:

```sql
CREATE DATABASE rag;
\c rag
CREATE EXTENSION IF NOT EXISTS vector;
CREATE USER rag WITH PASSWORD '<strong-password>';
GRANT ALL PRIVILEGES ON DATABASE rag TO rag;
GRANT ALL ON SCHEMA public TO rag;
```

rag-api creates its tables and indexes on first start. The full-text index used
by hybrid search is built `CONCURRENTLY` in the background, without locking
writes.

## 5. IAM role for Textract (IRSA)

```bash
export CLUSTER=<cluster-name>
aws iam create-policy --policy-name ranger-rag-textract \
  --policy-document file://deploy/iam/textract-policy.json

eksctl create iamserviceaccount --cluster $CLUSTER --namespace ranger --name rag-api \
  --attach-policy-arn arn:aws:iam::<account-id>:policy/ranger-rag-textract \
  --role-name ranger-rag-api --role-only --approve
```

Put the resulting role ARN into `deploy/k8s/rag-api.yaml`
(`eks.amazonaws.com/role-arn`). The policy grants only
`textract:DetectDocumentText`.

## 6. Configuration and secrets

```bash
kubectl apply -f deploy/k8s/namespace.yaml

cp .env.prod.example rag-api.env
# edit rag-api.env: DB_HOST (RDS endpoint), AWS_DEFAULT_REGION, anything else you change
kubectl -n ranger create configmap rag-api-config --from-env-file=rag-api.env

kubectl -n ranger create secret generic rag-api-secrets \
  --from-literal=JWT_SECRET='<the chat app JWT_SECRET, identical value>' \
  --from-literal=POSTGRES_PASSWORD='<db password>'
```

The two `<from-secret>` placeholders left in `rag-api.env` are overridden by the
Secret (the Deployment lists the Secret after the ConfigMap). If you keep secrets
in AWS Secrets Manager, create `rag-api-secrets` from it with the External
Secrets Operator instead of `kubectl create secret`.

**`JWT_SECRET` must be exactly the chat app's `JWT_SECRET`.** The chat app signs a
short-lived token with it on every call; a mismatch makes every upload and
query fail with 401.

## 7. Deploy

```bash
sed -i "s#<ECR_REGISTRY>#$ECR_REGISTRY#g; s#<TAG>#$TAG#g" deploy/k8s/*.yaml
sed -i "s#<TEXTRACT_ROLE_ARN>#arn:aws:iam::<account-id>:role/ranger-rag-api#" deploy/k8s/rag-api.yaml

kubectl apply -f deploy/k8s/embeddings-server.yaml
kubectl -n ranger rollout status deploy/embeddings-server
kubectl apply -f deploy/k8s/rag-api.yaml
kubectl -n ranger rollout status deploy/rag-api
```

## 8. Verify

```bash
kubectl -n ranger port-forward svc/rag-api 8000:8000 &
curl -s localhost:8000/health                       # {"status":"UP"}

kubectl -n ranger logs deploy/rag-api | grep "Retrieval enhancements"
# extraction=structured ocr=textract captions=False chunking=structure retrieval=hybrid ...
kubectl -n ranger logs deploy/rag-api | grep "Full-text index"
# Full-text index ix_langchain_pg_embedding_fts_english is ready
```

End to end through the chat app: upload a PDF to a chat or an agent's file
search, then ask a question about it. A scanned PDF exercises Textract; its text
should appear in the answer.

## 9. Sizing and scaling

Measured on a laptop CPU (scale with your node type):

| Operation | Time |
|---|---|
| 110-page mixed PDF upload (tables, 5 scanned pages) | ~21-25 s |
| Query | ~0.1 s |

- Both Deployments autoscale on CPU (70 %). The embedding server is the shared
  bottleneck for uploads: add replicas or CPU to it first.
- `RAG_EXTRACTION_CONCURRENCY` (default 8) caps parallel Textract calls per
  upload. Lower it if Textract returns throttling errors under many simultaneous
  uploads; `AWS_RETRY_MODE=adaptive` already retries them.
- `RAG_TEI_CONCURRENCY` x rag-api replicas is the maximum number of in-flight
  embedding requests the embedding servers will see.

## 10. Operations

- **Upgrading rag-api:** build a new tag, `kubectl -n ranger set image
  deploy/rag-api rag-api=$ECR_REGISTRY/ranger-rag-api:<new-tag>`.
- **Changing the embedding model** changes the vector space. Use a new
  `COLLECTION_NAME`, re-ingest documents, then switch. Never point an existing
  collection at a different model.
- **Changing extraction or chunking settings** affects new uploads only;
  re-upload files to re-process them.
- **Logs** are JSON (`CONSOLE_JSON=true`) for CloudWatch or your log stack.

## 11. Troubleshooting

| Symptom | Cause / fix |
|---|---|
| Every upload/query returns 401 | `JWT_SECRET` differs from the chat app's |
| rag-api not ready, `/health` DOWN | Database unreachable: security group, `DB_HOST`, password, or the vector extension is missing |
| Upload fails with "Embedding server ... failed after N attempts" | `embeddings-server` not running or `EMBEDDINGS_MODEL` URL wrong |
| Scanned PDFs come back empty | IRSA role missing `textract:DetectDocumentText`, or wrong `AWS_DEFAULT_REGION`; check logs for "OCR failed" |
| Pod logs mention downloading a model | `HF_HUB_OFFLINE` not set; or the reranker was enabled without a baked model |
