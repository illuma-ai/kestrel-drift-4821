# Bundled models

Everything the service needs to understand text is shipped with it, so a
deployment never downloads a model.

| Item | Location in the bundle | Size | Used by |
|---|---|---|---|
| `BAAI/bge-base-en-v1.5` embedding model | `rag-api-models/bge-base-en-v1.5/` -> copy to `models/bge-base-en-v1.5/` | ~440 MB in 6 shards | the embedding server image |
| `cl100k_base` tokenizer data | `models/tiktoken/` (inside the source) | 1.7 MB | structure-aware chunking (token budgets) |

## Why the model is split into shards

Git hosts reject single files over 100 MB, and the model's weights are one
438 MB file. `scripts/shard_model.py` splits them into
`model-0000N-of-00006.safetensors` files (each under 90 MB) plus
`model.safetensors.index.json`, the standard sharded layout the embedding
server loads natively. Tensors are copied unchanged: all 200 weight tensors
were verified identical to the original, and retrieval results matched the
original model on the benchmark (75/76 and 76/76).

## Offline guarantees (verified)

- The embedding image starts and reports Ready with `docker run --network none`.
- rag-api completed uploads and queries with all outbound HTTP forced to fail
  and the tokenizer's download cache removed (no network errors, no download).
- `HF_HUB_OFFLINE=1` is baked into the embedding image and set for rag-api in
  `.env.prod.example`, so an accidental model reference fails fast instead of
  downloading.

## Rebuilding the model files (only when upgrading the model)

```bash
pip install huggingface_hub safetensors numpy
python -c "from huggingface_hub import snapshot_download; snapshot_download('BAAI/bge-base-en-v1.5', local_dir='models/bge-base-en-v1.5', allow_patterns=['*.json','vocab.txt','model.safetensors','1_Pooling/*'])"
rm -rf models/bge-base-en-v1.5/.cache
python scripts/shard_model.py models/bge-base-en-v1.5
```

A different model changes the vector space: use a new `COLLECTION_NAME` and
re-ingest (see `eks-production.md`, Operations).
