# Deployment

| Guide | For |
|---|---|
| [eks-production.md](eks-production.md) | Build the two images, deploy on EKS, verify, size and operate |
| [chat-v2-integration.md](chat-v2-integration.md) | The chat-app variables (`RAG_API_URL`, shared `JWT_SECRET`) and how to switch over |
| [branding.md](branding.md) | How the release bundle is renamed and what the deployment names are |
| [models.md](models.md) | The bundled embedding model: why it is sharded, how it is loaded offline, how to rebuild it |

Configuration reference: `.env.prod.example` (production values, no keys) and
`docs/retrieval-enhancements.md` (every setting and the measurements behind it).
