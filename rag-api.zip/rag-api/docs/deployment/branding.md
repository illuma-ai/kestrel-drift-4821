# Branding the release bundle

The source tree stays identical to the fork source so upstream fixes can still
be pulled cleanly. Branding is applied to an **exported copy** when the release
bundle is built, by `scripts/rebrand.py`.

## What the script changes

- File contents **and** file/folder names.
- The upstream product name in every spelling: mixed case, lower case, upper
  case, and with a space, hyphen or underscore between its two words; also its
  first word on its own. Case style is kept: mixed case becomes `Ranger`, lower
  case `ranger`, upper case `RANGER`. Examples of what changes: image names in
  the build scripts and CI workflows, the README, and the default Atlas database
  name in `app/config.py`.
- Markdown links that pointed at the upstream product's website become plain
  text, so the bundle does not contain links to a guessed domain.

What it does **not** change:

- Binary files (images, model weights).
- `lc` / `LC` abbreviations. They are **reported** for review and only rewritten
  with `--lc-to <abbreviation>`, because blind replacement corrupts library
  identifiers such as the LLM framework's `lc_` attributes. The current source
  has none.

## Usage

```bash
# preview: what would change, plus every lc/LC token for review
python scripts/rebrand.py <exported-dir> --dry-run

# apply
python scripts/rebrand.py <exported-dir> --brand Ranger

# verify: exits 1 and lists anything left
python scripts/rebrand.py <exported-dir> --check
```

`scripts/build_bundle.py` runs the full release: export, rebrand, check, zip,
and copy the sharded model files next to the zip.

## Names used by the deployment

| Thing | Name |
|---|---|
| Kubernetes namespace | `ranger` |
| rag-api image | `ranger-rag-api` |
| Embedding server image | `ranger-rag-embeddings` |
| Services | `rag-api`, `embeddings-server` |
| IAM role / policy | `ranger-rag-api` / `ranger-rag-textract` |

To use a different brand, run the script with `--brand <Name>` and replace
`ranger` in `deploy/k8s/*.yaml` and in `EMBEDDINGS_MODEL` in your env file.
