# Connecting the chat app (chat-v2)

The chat app talks to rag-api through **one URL and one shared secret**. No
chat-app code changes are needed: rag-api keeps the exact API the chat app
already calls.

## Variables to set in the chat app

| Variable | Value | Why |
|---|---|---|
| `RAG_API_URL` | `http://rag-api.ranger.svc.cluster.local:8000` (same cluster) or the internal load-balancer URL (see below) | Every file upload, file search, delete and "upload as text" call goes here |
| `JWT_SECRET` | unchanged, but **rag-api's `JWT_SECRET` must be the same value** | The chat app signs each call with it (`packages/api/src/crypto/jwt.ts`); rag-api verifies it and scopes data to that user |
| `RAG_USE_FULL_CONTEXT` | leave unset (recommended) | When `true`, the legacy context path sends whole documents instead of searched passages |

Nothing else changes. The embedding, OCR and retrieval settings (`EMBEDDINGS_*`,
`RAG_OCR_*`, ...) belong to rag-api only; the chat app does not read them.

### What the chat app calls

| Chat-app feature | rag-api endpoint |
|---|---|
| File upload to a chat or an agent's file search | `POST /embed` |
| File search / answering from files | `POST /query` |
| Full-document context | `GET /documents/{id}/context` |
| "Upload as text" | `POST /text` |
| Deleting files | `DELETE /documents` |
| Startup health check | `GET /health` |

## Where the chat app runs

**Same EKS cluster:** use the service DNS name above. Optionally add a
NetworkPolicy so that only the chat app's namespace can reach `rag-api`.

**Elsewhere (for example on ECS):** expose rag-api through an internal load
balancer and use its DNS name:

```yaml
apiVersion: v1
kind: Service
metadata:
  name: rag-api-internal
  namespace: ranger
  annotations:
    service.beta.kubernetes.io/aws-load-balancer-type: external
    service.beta.kubernetes.io/aws-load-balancer-scheme: internal
    service.beta.kubernetes.io/aws-load-balancer-nlb-target-type: ip
spec:
  type: LoadBalancer
  selector: {app: rag-api}
  ports:
    - {port: 8000, targetPort: 8000}
```

Then `RAG_API_URL=http://<internal-nlb-dns>:8000`, and allow the chat app's
security group to reach it on 8000. Keep it internal: rag-api trusts any request
carrying a valid token, so it must not be on the public internet.

## Switching an existing deployment

If `RAG_API_URL` currently points at another document service, files embedded
there are not visible to rag-api: they live in a different store.

1. Deploy rag-api (`eks-production.md`) and confirm `/health`.
2. Update `RAG_API_URL` in the chat app's secret store (for the deployed chat
   app this is the environment injected from Secrets Manager) and roll the chat
   app.
3. Re-upload the files users still need.
4. Check the chat app's startup log: `RAG API is running and reachable at ...`.

## Verify end to end

1. Upload a PDF in a chat and ask about its content: the answer cites it.
2. Upload a scanned PDF: the answer uses its text (Textract OCR).
3. Ask with an exact code or name from the document: hybrid search finds it.
4. Delete the file in the chat app: a follow-up question no longer finds it.
