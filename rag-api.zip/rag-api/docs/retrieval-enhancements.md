# Retrieval enhancements

Optional, environment-switched improvements to how documents are extracted,
chunked and searched. **Every flag defaults to off**, and with all of them off
the service behaves exactly like the stock pipeline. The API contract is
unchanged in every mode:

- `/query` and `/query_multiple` still return `[[Document, score], ...]`, where
  `score` is a **distance**: lower is better, roughly `0..1`, sorted ascending.
  Clients display `1 - score` as relevance.
- Chunk metadata (`file_id`, `user_id`, `page` as a 0-based integer, ...) is kept.
- Authorization is unchanged. Every retrieval leg applies the same owner, file
  and collection scope in the database query.

Everything runs on CPU. OCR and figure captions call AWS (Textract / Bedrock);
nothing needs a GPU.

All code lives in `app/enhancements/`. The stock modules only contain short hook
calls into `app/enhancements/hooks.py`.

## Recommended profile

`.env.prod.example` is the production profile: self-hosted `bge-base-en-v1.5`
embeddings, structured extraction, Textract OCR, structure chunking, hybrid
search and chunk merging, with no API keys (Textract through the pod's IAM
role). Deployment: `docs/deployment/`.

Optional extras, each measured below:

- `RAG_FIGURE_CAPTIONS=true`: charts and diagrams become searchable; needs
  Bedrock access.
- `RAG_RERANK_ENABLED=true`: small gain with bge embeddings, ~3 s per query on
  CPU; the model must be baked into the image for offline deployments.
- `RAG_RAW_UPLOAD_LANDING=true`: failed uploads are kept for replay; needs an
  S3 bucket.
- `RAG_QUERY_EXPANSION`: no measured benefit once hybrid search is on.

### Measured effect

Measured on a 31-page product manual with 30 near-identical model sections
(confusable codes such as `PX-4410` vs `PX-4401`) and 76 questions with known
answers and pages. Embeddings: Bedrock Titan v2, `k=4`, laptop CPU.

| Configuration | Answer in top 1 | Answer in top 4 | Top hit cites right page | Query p50 |
|---|---|---|---|---|
| Stock | 58/76 | 69/76 | 58/76 | 0.20 s |
| Structured extraction + structure chunking | 59/76 | 71/76 | 59/76 | 0.20 s |
| + hybrid search | 71/76 | 75/76 | 71/76 | 0.21 s |
| + hybrid + rerank (`bge-reranker-base`, pool 20) | 76/76 | 76/76 | 76/76 | 3.1 s |

**Figures (charts and diagrams).** 12 pages whose facts exist only inside
images, 27 questions:

| Configuration | Answer in top 1 | Ingest time |
|---|---|---|
| Stock | 0/27 | 2.9 s |
| Structured extraction + hybrid, no captions | 0/27 | 3.9 s |
| + `RAG_FIGURE_CAPTIONS=true` | **27/27** | 17.8 s (~1.2 s per figure) |

Without captions, chart content simply does not exist as text, so no retrieval
setting can find it.

**Reworded questions (query expansion).** The same 76 manual questions,
rephrased with vocabulary the manual never uses ("guarantee period" for
warranty, "throughput" for rated flow):

| Configuration | Top 1 | Top 4 | Query p50 |
|---|---|---|---|
| Stock | 53/76 | 67/76 | 0.19 s |
| Hybrid | 72/76 | 73/76 | 0.21 s |
| Hybrid + expansion | 73/76 | 76/76 | 0.61 s |
| Hybrid + rerank | 76/76 | 76/76 | 3.2 s |
| Hybrid + rerank + expansion | 76/76 | 76/76 | 4.3 s |

Expansion helps a little without the reranker and adds nothing once the
reranker is on, so it stays off by default.

Hybrid search delivers most of the gain at no measurable latency cost and
should be the default. Reranking closes the rest but costs about 3 s per query on CPU
with the default model and a 20-candidate pool. Enable it where answer quality
matters more than latency, or shrink `RAG_CANDIDATE_POOL` or use a smaller
`RAG_RERANK_MODEL` and re-measure. Scanned PDFs are a separate,
binary win: the stock loader embeds nothing from them, so every question about
one goes unanswered, while `RAG_OCR_PROVIDER=textract` makes them fully searchable.

Re-ingest existing files after changing extraction or chunking settings; stored
chunks are not rewritten.

## Ingestion

### Structured extraction (`RAG_EXTRACTION=structured`)

| File type | Stock loader | Structured loader |
|---|---|---|
| PDF | pypdf plain text per page | Per-page markdown: text in reading order (multi-column aware), tables as markdown tables, optional figure captions, OCR for pages without a text layer |
| DOCX / PPTX / XLSX | docx2txt / unstructured | Markdown with headings and tables |
| Markdown | formatting stripped | Raw markdown, so headings drive chunking (`/text` is unchanged) |
| Images | not supported | OCR text and/or caption (when OCR or captions are on) |

PDFs still produce one document per page with a 0-based `page`, so citations
keep working. Legacy `.doc/.ppt/.xls` and all other types use the stock loaders.

### OCR (`RAG_OCR_PROVIDER=textract`)

Only pages with fewer than `RAG_OCR_MIN_CHARS_PER_PAGE` extractable characters
are rendered (at `RAG_OCR_RENDER_DPI`) and sent to Textract, so digital PDFs
cost nothing extra. Image uploads are OCR'd too. A failed page is logged and
skipped; it never fails the document. Enabling OCR also enables structured PDF
extraction for PDFs.

### Figure captions (`RAG_FIGURE_CAPTIONS=true`)

Embedded figures covering at least `RAG_FIGURE_MIN_AREA_RATIO` of the page are
described by a Bedrock vision model (`RAG_VLM_MODEL`) and the description is
inlined where the figure sits. Identical images are captioned once.

### Chunking (`RAG_CHUNKING_STRATEGY`)

| Value | Behaviour |
|---|---|
| `recursive` (default) | Stock character splitter (`CHUNK_SIZE` / `CHUNK_OVERLAP`) |
| `table_aware` | Same, but markdown tables are never split mid-row; large tables are split into batches of `RAG_TABLE_ROWS_PER_CHUNK` rows, each repeating the header |
| `structure` | Splits on headings, paragraphs, lists and tables up to `RAG_STRUCTURE_CHUNK_MAX_TOKENS` tokens, and prefixes each chunk with its heading path (e.g. `Annual Report › Revenue`). Token counts use the `RAG_STRUCTURE_CHUNK_TOKENIZER` tiktoken encoding, so no model download is needed |

## Retrieval

### Hybrid search (`RAG_RETRIEVAL_STRATEGY=hybrid`, Postgres only)

Adds a Postgres full-text leg next to vector search and fuses the two ranked
lists with Reciprocal Rank Fusion (`RAG_RRF_K`). It catches exact tokens such
as part numbers, names and codes that embeddings miss. Terms are OR-ed, and
chunks matching more of them rank higher.

At startup each replica runs, in the background,
`CREATE INDEX CONCURRENTLY IF NOT EXISTS` for a GIN expression index on
`to_tsvector('<RAG_FTS_LANGUAGE>', document)`. There is no table rewrite and no
write lock, and queries work (more slowly) until the index is ready. Set
`RAG_FTS_CREATE_INDEX=false` to manage the index yourself. If a build is
interrupted, the index is left INVALID and logged at startup. Drop it and it is
rebuilt on the next start.

With the fused score, `score` is `1 - fused / best_possible`, so a chunk ranked
first by both legs scores 0. `RAG_DISTANCE_THRESHOLD` still filters the vector leg.

### Reranking (`RAG_RERANK_ENABLED=true`)

The top `RAG_CANDIDATE_POOL` candidates are re-scored by a local cross-encoder
(`RAG_RERANK_MODEL`, default `BAAI/bge-reranker-base`) on CPU and the best `k`
are returned with `score = 1 - sigmoid(logit)`. The model is downloaded once,
loaded in the background at startup, and cached per process. If reranking
fails, the first-stage order is returned.

### Merging neighbouring chunks (`RAG_MERGE_ADJACENT_CHUNKS=true`)

Consecutive chunks of the same file **and page** in the result set are joined
into one passage that keeps the first chunk's metadata (`merged_chunk_count`
records how many were joined). Merges never cross a page boundary, so the
cited `page` is always where the passage's text actually is. The response can therefore contain fewer than `k` entries,
covering the same text.

### Query expansion (`RAG_QUERY_EXPANSION=true`)

A Bedrock model (`RAG_QUERY_EXPANSION_MODEL`) writes `RAG_QUERY_EXPANSION_COUNT`
alternative phrasings, every phrasing is searched, and all lists are fused.
Reranking still scores against the original question.

## Durable uploads (`RAG_RAW_UPLOAD_LANDING=true`, Postgres only)

`/embed` and `/embed-upload` copy the upload to durable storage and record a
row in `rag_raw_uploads` **before** extraction starts. The row then becomes
`succeeded` or `failed`. On success the bytes are deleted unless
`RAG_RAW_UPLOAD_KEEP_ON_SUCCESS=true`. Failed uploads keep their bytes.

- Storage: S3 when `RAG_RAW_UPLOAD_S3_BUCKET` is set (prefix
  `RAG_RAW_UPLOAD_S3_PREFIX`), otherwise `RAG_RAW_UPLOAD_DIR` on local disk.
  Local disk is for development only, because replicas do not share it.
- `GET /uploads/failed`: the caller's failed uploads.
- `POST /uploads/{id}/replay`: re-run ingestion from the stored bytes, under
  the upload's original owner.
- `DELETE /documents` also removes the landed bytes and rows of those files.
- Landing is best-effort. A storage outage is logged and does not block
  ingestion.

Both endpoints are owner-scoped like the document routes, and another owner's
upload returns 404. They return 404 when landing is disabled.

### Upload latency (every enhancement on, including captions and reranker)

A 110-page PDF (93 digital pages with tables, 12 chart pages, 5 scanned pages)
uploaded with every enhancement on, laptop CPU:

| | Extract + OCR + captions + chunk | Embed + store | Total |
|---|---|---|---|
| Stock, Titan (charts and scans produce no text) | 0.2-0.5 s | ~14 s | ~15 s |
| Full profile, Titan v2 | 11-13 s | 14-15 s | 25-28 s |
| Full profile, Cohere v4 (`us.`) | 11-12 s | 3-4 s | 14-16 s |

OCR and caption calls run concurrently (`RAG_EXTRACTION_CONCURRENCY`, default
8). Before that change, the same upload spent 26 s in extraction. Titan's embed
time grows linearly with chunk count because it is one request per chunk.
Cohere batches 96 chunks per request. Query latency with the reranker was
2.8 s p50 on this machine; size production CPUs accordingly.

## Self-hosted embeddings (recommended)

`EMBEDDINGS_PROVIDER=huggingfacetei` with `EMBEDDINGS_MODEL` set to the URL of
a Text Embeddings Inference server (CPU image) removes per-token cost and
managed-API throttling. The production setup bakes `bge-base-en-v1.5` into the
server image so nothing is downloaded (`docs/deployment/`). The stock client for this provider rejects server URLs and sends a
whole batch in one request, so URLs are routed to `app/enhancements/tei.py`,
which batches (`RAG_TEI_BATCH_SIZE`), sends several requests at once
(`RAG_TEI_CONCURRENCY`), retries a busy server, and truncates over-long inputs.

Measured on the same benchmarks (hybrid search, no reranker):

| Embedding model | Manual: right answer first | Reworded: right answer first | Query p50 | 110-page upload |
|---|---|---|---|---|
| Bedrock Titan v2 | 71/76 | 72/76 | 0.21 s | 25-28 s |
| **bge-base-en-v1.5 (CPU, self-hosted)** | **75/76** | **76/76** | **0.08-0.11 s** | 21-25 s |
| gte-base-en-v1.5 (CPU, self-hosted) | 75/76 | 73/76 | 0.08 s | n/a |

With bge-base, adding the reranker moves the manual result from 75/76 to 76/76
and costs ~3 s per query, so it is optional rather than default. Upload time on
the embedding server was measured on a laptop running it in Docker; on EKS it
scales with CPU per pod and replica count.

## Embedding throughput and throttling (Bedrock)

| | Titan Text v2 | Cohere Embed v4 (`us.` cross-region) |
|---|---|---|
| Price (us-east-1) | $0.02 / 1M tokens | $0.12 / 1M tokens |
| Default token quota | 300k tokens/min | 300k tokens/min (+ separate cross-region pool) |
| Chunks per request | 1 (sequential within a batch) | up to 96 |

The token-per-minute quota (~750 chunks/min at ~400 tokens each) is what
throttles first for either model. In order of preference:

1. Set `AWS_RETRY_MODE=adaptive` and `AWS_MAX_ATTEMPTS=10`; boto3 then slows down
   and retries throttled calls instead of failing the upload.
2. Request a quota increase for the model's tokens-per-minute.
3. Use `us.cohere.embed-v4:0` for fewer, larger requests and the extra
   cross-region pool (no code change; the client batches Cohere automatically).
4. At high volume, self-host an embedding server
   (`EMBEDDINGS_PROVIDER=huggingfacetei`): no per-token quota, fixed cost.

Changing the embedding model changes the vector space: use a new
`COLLECTION_NAME` and re-ingest.

## AWS credentials

OCR, captions, query expansion and S3 use `AWS_DEFAULT_REGION` (or
`AWS_REGION`). Explicit `AWS_ACCESS_KEY_ID` / `AWS_SECRET_ACCESS_KEY` are used
when both are set; otherwise the default credential chain (instance or task
role) is used.

## All settings

| Variable | Default |
|---|---|
| `RAG_EXTRACTION` | `default` (`structured`) |
| `RAG_OCR_PROVIDER` | `none` (`textract`) |
| `RAG_OCR_RENDER_DPI` | `200` |
| `RAG_OCR_MIN_CHARS_PER_PAGE` | `50` |
| `RAG_FIGURE_CAPTIONS` | `false` |
| `RAG_VLM_MODEL` | `us.amazon.nova-lite-v1:0` |
| `RAG_FIGURE_MIN_AREA_RATIO` | `0.05` |
| `RAG_EXTRACTION_CONCURRENCY` | `8` (parallel OCR/caption calls per upload) |
| `RAG_CHUNKING_STRATEGY` | `recursive` (`table_aware`, `structure`) |
| `RAG_TABLE_ROWS_PER_CHUNK` | `20` |
| `RAG_STRUCTURE_CHUNK_MAX_TOKENS` | `400` |
| `RAG_STRUCTURE_CHUNK_TOKENIZER` | `cl100k_base` |
| `RAG_RETRIEVAL_STRATEGY` | `vector` (`hybrid`) |
| `RAG_FTS_LANGUAGE` | `english` |
| `RAG_FTS_CREATE_INDEX` | `true` |
| `RAG_RRF_K` | `60` |
| `RAG_CANDIDATE_POOL` | `20` |
| `RAG_RERANK_ENABLED` | `false` |
| `RAG_RERANK_MODEL` | `BAAI/bge-reranker-base` |
| `RAG_MERGE_ADJACENT_CHUNKS` | `false` |
| `RAG_QUERY_EXPANSION` | `false` |
| `RAG_QUERY_EXPANSION_MODEL` | `us.amazon.nova-micro-v1:0` |
| `RAG_QUERY_EXPANSION_COUNT` | `2` |
| `RAG_RAW_UPLOAD_LANDING` | `false` |
| `RAG_RAW_UPLOAD_S3_BUCKET` | (empty: local disk) |
| `RAG_RAW_UPLOAD_S3_PREFIX` | `raw-uploads/` |
| `RAG_RAW_UPLOAD_DIR` | `./data/raw_uploads` |
| `RAG_RAW_UPLOAD_KEEP_ON_SUCCESS` | `false` |
| `RAG_TEI_BATCH_SIZE` | `32` (self-hosted embeddings: texts per request) |
| `RAG_TEI_CONCURRENCY` | `4` (self-hosted embeddings: requests in flight) |
| `RAG_TEI_QUERY_PREFIX` | (empty; instruction prepended to queries only) |
