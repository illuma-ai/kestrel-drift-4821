# models/

- `tiktoken/` — tokenizer data for structure-aware chunking (committed; read via
  `TIKTOKEN_CACHE_DIR`).
- `bge-base-en-v1.5/` — embedding model weights. Not in git (too large); shipped
  in the release bundle as `rag-api-models/`. See `docs/deployment/models.md`.
