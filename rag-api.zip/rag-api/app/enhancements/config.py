"""Settings for the optional retrieval-quality enhancements.

Single source of truth for every enhancement flag. Values are read once at
import time from the environment, mirroring how ``app.config`` works. All
defaults reproduce the stock pipeline exactly.

Why a separate module instead of extending ``app.config``: ``app.config`` is an
upstream file that builds the embeddings client and vector store at import time.
Keeping enhancement settings here means pulling upstream changes never conflicts
with them, and this module can be imported without constructing a vector store.
"""

from __future__ import annotations

import os
import re
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class ExtractionMode(str, Enum):
    """How uploaded files are turned into text."""

    DEFAULT = "default"  # stock loaders (pypdf, docx2txt, unstructured, ...)
    STRUCTURED = "structured"  # layout-aware PDF + markdown office conversion


class OcrProvider(str, Enum):
    """Engine used to transcribe scanned PDF pages and image uploads."""

    NONE = "none"
    TEXTRACT = "textract"


class ChunkingStrategy(str, Enum):
    """How extracted text is split into retrieval chunks."""

    RECURSIVE = "recursive"  # stock RecursiveCharacterTextSplitter
    TABLE_AWARE = "table_aware"  # never splits a markdown table mid-row
    STRUCTURE = "structure"  # heading/table-aware, token-budgeted chunks


class RetrievalStrategy(str, Enum):
    """First-stage candidate generation for /query and /query_multiple."""

    VECTOR = "vector"  # stock dense similarity only
    HYBRID = "hybrid"  # dense + Postgres full-text, fused with RRF


_TRUE_VALUES = ("true", "1", "yes", "y", "on")

# Postgres text-search configuration names are interpolated into DDL/SQL (they
# cannot be bound as parameters inside an index expression), so restrict them
# to plain identifiers.
_REGCONFIG_RE = re.compile(r"^[a-z_][a-z0-9_]*$")


def _env(name: str, default: str = "") -> str:
    value = os.getenv(name)
    return default if value is None else value


def _env_bool(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None or value.strip() == "":
        return default
    return value.strip().lower() in _TRUE_VALUES


def _env_int(name: str, default: int) -> int:
    value = os.getenv(name)
    if value is None or value.strip() == "":
        return default
    return int(value)


def _env_float(name: str, default: float) -> float:
    value = os.getenv(name)
    if value is None or value.strip() == "":
        return default
    return float(value)


def _env_enum(name: str, enum_cls, default):
    raw = os.getenv(name)
    if raw is None or raw.strip() == "":
        return default
    try:
        return enum_cls(raw.strip().lower())
    except ValueError as exc:
        allowed = ", ".join(e.value for e in enum_cls)
        raise ValueError(f"{name}={raw!r} is invalid. Allowed: {allowed}") from exc


@dataclass(frozen=True)
class AwsSettings:
    """AWS access shared by OCR, captioning, query expansion and S3 landing.

    Empty keys mean "use the default boto3 credential chain" (instance/task
    role), which is what production deployments should rely on.
    """

    region: str
    access_key_id: str = ""
    secret_access_key: str = ""
    session_token: str = ""


@dataclass(frozen=True)
class EnhancementSettings:
    """Every enhancement flag, resolved from the environment."""

    # Ingestion
    extraction: ExtractionMode = ExtractionMode.DEFAULT
    ocr_provider: OcrProvider = OcrProvider.NONE
    ocr_render_dpi: int = 200
    ocr_min_chars_per_page: int = 50
    figure_captions: bool = False
    vlm_model: str = "us.amazon.nova-lite-v1:0"
    figure_min_area_ratio: float = 0.05
    extraction_concurrency: int = 8
    chunking: ChunkingStrategy = ChunkingStrategy.RECURSIVE
    table_rows_per_chunk: int = 20
    structure_chunk_max_tokens: int = 400
    structure_chunk_tokenizer: str = "cl100k_base"

    # Retrieval
    retrieval: RetrievalStrategy = RetrievalStrategy.VECTOR
    fts_language: str = "english"
    fts_create_index: bool = True
    rrf_k: int = 60
    candidate_pool: int = 20
    rerank: bool = False
    rerank_model: str = "BAAI/bge-reranker-base"
    merge_adjacent_chunks: bool = False
    query_expansion: bool = False
    query_expansion_model: str = "us.amazon.nova-micro-v1:0"
    query_expansion_count: int = 2

    # Durable raw-upload landing
    raw_upload_landing: bool = False
    raw_upload_s3_bucket: str = ""
    raw_upload_s3_prefix: str = "raw-uploads/"
    raw_upload_dir: str = "./data/raw_uploads"
    raw_upload_keep_on_success: bool = False

    aws: AwsSettings = field(default_factory=lambda: AwsSettings(region="us-east-1"))

    @property
    def retrieval_pipeline_enabled(self) -> bool:
        """True when /query must go through the enhanced retrieval pipeline."""
        return (
            self.retrieval == RetrievalStrategy.HYBRID
            or self.rerank
            or self.merge_adjacent_chunks
            or self.query_expansion
        )

    @property
    def ocr_enabled(self) -> bool:
        return self.ocr_provider != OcrProvider.NONE

    @property
    def enhanced_extraction_enabled(self) -> bool:
        """True when PDFs/images bypass the stock loaders.

        OCR and figure captioning both need page rasterisation, which only the
        structured PDF extractor does, so either flag switches it on for PDFs.
        """
        return (
            self.extraction == ExtractionMode.STRUCTURED
            or self.ocr_enabled
            or self.figure_captions
        )


def load_settings() -> EnhancementSettings:
    """Resolve settings from the current environment.

    Raises:
        ValueError: On an invalid enum value or an unsafe FTS language name.
    """
    fts_language = _env("RAG_FTS_LANGUAGE", "english").strip().lower()
    if not _REGCONFIG_RE.match(fts_language):
        raise ValueError(
            f"RAG_FTS_LANGUAGE={fts_language!r} is not a valid text-search configuration name"
        )

    return EnhancementSettings(
        extraction=_env_enum("RAG_EXTRACTION", ExtractionMode, ExtractionMode.DEFAULT),
        ocr_provider=_env_enum("RAG_OCR_PROVIDER", OcrProvider, OcrProvider.NONE),
        ocr_render_dpi=_env_int("RAG_OCR_RENDER_DPI", 200),
        ocr_min_chars_per_page=_env_int("RAG_OCR_MIN_CHARS_PER_PAGE", 50),
        figure_captions=_env_bool("RAG_FIGURE_CAPTIONS", False),
        vlm_model=_env("RAG_VLM_MODEL", "us.amazon.nova-lite-v1:0"),
        figure_min_area_ratio=_env_float("RAG_FIGURE_MIN_AREA_RATIO", 0.05),
        extraction_concurrency=max(1, _env_int("RAG_EXTRACTION_CONCURRENCY", 8)),
        chunking=_env_enum(
            "RAG_CHUNKING_STRATEGY", ChunkingStrategy, ChunkingStrategy.RECURSIVE
        ),
        table_rows_per_chunk=_env_int("RAG_TABLE_ROWS_PER_CHUNK", 20),
        structure_chunk_max_tokens=_env_int("RAG_STRUCTURE_CHUNK_MAX_TOKENS", 400),
        structure_chunk_tokenizer=_env("RAG_STRUCTURE_CHUNK_TOKENIZER", "cl100k_base"),
        retrieval=_env_enum(
            "RAG_RETRIEVAL_STRATEGY", RetrievalStrategy, RetrievalStrategy.VECTOR
        ),
        fts_language=fts_language,
        fts_create_index=_env_bool("RAG_FTS_CREATE_INDEX", True),
        rrf_k=_env_int("RAG_RRF_K", 60),
        candidate_pool=_env_int("RAG_CANDIDATE_POOL", 20),
        rerank=_env_bool("RAG_RERANK_ENABLED", False),
        rerank_model=_env("RAG_RERANK_MODEL", "BAAI/bge-reranker-base"),
        merge_adjacent_chunks=_env_bool("RAG_MERGE_ADJACENT_CHUNKS", False),
        query_expansion=_env_bool("RAG_QUERY_EXPANSION", False),
        query_expansion_model=_env(
            "RAG_QUERY_EXPANSION_MODEL", "us.amazon.nova-micro-v1:0"
        ),
        query_expansion_count=_env_int("RAG_QUERY_EXPANSION_COUNT", 2),
        raw_upload_landing=_env_bool("RAG_RAW_UPLOAD_LANDING", False),
        raw_upload_s3_bucket=_env("RAG_RAW_UPLOAD_S3_BUCKET", ""),
        raw_upload_s3_prefix=_env("RAG_RAW_UPLOAD_S3_PREFIX", "raw-uploads/"),
        raw_upload_dir=_env("RAG_RAW_UPLOAD_DIR", "./data/raw_uploads"),
        raw_upload_keep_on_success=_env_bool("RAG_RAW_UPLOAD_KEEP_ON_SUCCESS", False),
        aws=AwsSettings(
            region=_env("AWS_DEFAULT_REGION", "")
            or _env("AWS_REGION", "")
            or "us-east-1",
            access_key_id=_env("AWS_ACCESS_KEY_ID", ""),
            secret_access_key=_env("AWS_SECRET_ACCESS_KEY", ""),
            session_token=_env("AWS_SESSION_TOKEN", ""),
        ),
    )


settings: EnhancementSettings = load_settings()


def make_aws_client(service: str, aws: Optional[AwsSettings] = None):
    """Build a boto3 client that honours explicit keys or the default chain.

    Passing empty-string keys to boto3 does NOT fall back to the role chain, so
    keys are only forwarded when actually set.
    """
    import boto3

    aws = aws or settings.aws
    kwargs = {"region_name": aws.region}
    if aws.access_key_id and aws.secret_access_key:
        kwargs["aws_access_key_id"] = aws.access_key_id
        kwargs["aws_secret_access_key"] = aws.secret_access_key
        if aws.session_token:
            kwargs["aws_session_token"] = aws.session_token
    return boto3.client(service, **kwargs)
