"""Durable raw-upload landing store.

Problem: the embed routes write the upload to a temp file, extract, embed and
then delete the temp file. If extraction or embedding fails — or the process
dies mid-way — the original bytes are gone and the failure leaves no record.

This store copies the bytes to durable storage (S3 in production; a local
directory for development) and records a row **before** extraction starts.
The row then flips to ``succeeded`` or ``failed``. Failed uploads keep their
bytes, can be listed by their owner, and can be replayed through the same
ingestion path without the client re-sending the file.

SCALE: the filesystem backend is not shared between replicas — set
``RAG_RAW_UPLOAD_S3_BUCKET`` for any multi-replica deployment.
"""

from __future__ import annotations

import hashlib
import logging
import os
import shutil
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import List, Optional, Sequence

from app.enhancements.config import EnhancementSettings, make_aws_client, settings

logger = logging.getLogger(__name__)

TABLE = "rag_raw_uploads"


class UploadStatus:
    """Row lifecycle values (single source of truth for the CHECK constraint)."""

    LANDED = "landed"
    SUCCEEDED = "succeeded"
    FAILED = "failed"


CREATE_TABLE_SQL = f"""
CREATE TABLE IF NOT EXISTS {TABLE} (
    id            BIGSERIAL PRIMARY KEY,
    file_id       TEXT NOT NULL,
    user_id       TEXT NOT NULL,
    filename      TEXT NOT NULL,
    content_type  TEXT,
    size_bytes    BIGINT NOT NULL,
    sha256        TEXT NOT NULL,
    storage       TEXT NOT NULL,
    storage_key   TEXT,
    status        TEXT NOT NULL
                  CHECK (status IN ('{UploadStatus.LANDED}', '{UploadStatus.SUCCEEDED}', '{UploadStatus.FAILED}')),
    last_error    TEXT,
    attempts      INTEGER NOT NULL DEFAULT 1,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ix_{TABLE}_owner_file ON {TABLE} (user_id, file_id);
CREATE INDEX IF NOT EXISTS ix_{TABLE}_failed ON {TABLE} (user_id, created_at) WHERE status = '{UploadStatus.FAILED}';
"""


class BlobBackend(ABC):
    """Where landed bytes live."""

    tag: str

    @abstractmethod
    def put_file(
        self, key: str, source_path: str, content_type: Optional[str]
    ) -> None: ...

    @abstractmethod
    def get_file(self, key: str, dest_path: str) -> None: ...

    @abstractmethod
    def delete(self, key: str) -> None:
        """Idempotent: a missing key is not an error."""


class FilesystemBackend(BlobBackend):
    """Local directory. DEV ONLY — not shared across replicas."""

    tag = "fs"

    def __init__(self, base_dir: str) -> None:
        self._base = os.path.abspath(base_dir)

    def _path(self, key: str) -> str:
        path = os.path.abspath(os.path.join(self._base, key))
        if not path.startswith(self._base + os.sep):
            raise ValueError("storage key escapes the landing directory")
        return path

    def put_file(self, key, source_path, content_type):
        path = self._path(key)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        shutil.copyfile(source_path, path)

    def get_file(self, key, dest_path):
        shutil.copyfile(self._path(key), dest_path)

    def delete(self, key):
        try:
            os.remove(self._path(key))
        except FileNotFoundError:
            pass


class S3Backend(BlobBackend):
    """S3 bucket (role-aware credentials). Required for multi-replica deploys."""

    tag = "s3"

    def __init__(self, bucket: str, prefix: str, client=None) -> None:
        self._bucket = bucket
        self._prefix = prefix
        self._client = client or make_aws_client("s3")

    def put_file(self, key, source_path, content_type):
        extra = {"ContentType": content_type} if content_type else None
        self._client.upload_file(
            source_path, self._bucket, self._prefix + key, ExtraArgs=extra
        )

    def get_file(self, key, dest_path):
        self._client.download_file(self._bucket, self._prefix + key, dest_path)

    def delete(self, key):
        self._client.delete_object(Bucket=self._bucket, Key=self._prefix + key)


def build_backend(cfg: EnhancementSettings) -> BlobBackend:
    if cfg.raw_upload_s3_bucket:
        return S3Backend(cfg.raw_upload_s3_bucket, cfg.raw_upload_s3_prefix)
    logger.warning(
        "Raw uploads land on the local filesystem (%s); set RAG_RAW_UPLOAD_S3_BUCKET "
        "for any multi-replica deployment",
        cfg.raw_upload_dir,
    )
    return FilesystemBackend(cfg.raw_upload_dir)


def _sha256_file(path: str) -> str:
    digest = hashlib.sha256()
    with open(path, "rb") as fh:
        for block in iter(lambda: fh.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def _storage_key(user_id: str, file_id: str, sha256: str, filename: str) -> str:
    # Hash the ids: they are caller-supplied and must not shape a path/key.
    owner = hashlib.sha256(user_id.encode()).hexdigest()[:16]
    file_part = hashlib.sha256(file_id.encode()).hexdigest()[:16]
    ext = os.path.splitext(filename or "")[1].lower()[:16]
    return f"{owner}/{file_part}/{sha256}{ext}"


@dataclass
class UploadRecord:
    id: int
    file_id: str
    user_id: str
    filename: str
    content_type: Optional[str]
    status: str
    last_error: Optional[str]
    attempts: int
    storage: str
    storage_key: Optional[str]

    @classmethod
    def from_row(cls, row) -> "UploadRecord":
        return cls(**{name: row[name] for name in cls.__dataclass_fields__})

    def public(self) -> dict:
        """Owner-facing view (no storage internals)."""
        return {
            "id": self.id,
            "file_id": self.file_id,
            "filename": self.filename,
            "content_type": self.content_type,
            "status": self.status,
            "last_error": self.last_error,
            "attempts": self.attempts,
        }


class RawUploadStore:
    """Landing rows (Postgres) + bytes (blob backend)."""

    def __init__(
        self, pool, backend: BlobBackend, keep_on_success: bool = False
    ) -> None:
        self._pool = pool
        self._backend = backend
        self._keep_on_success = keep_on_success

    async def ensure_schema(self) -> None:
        async with self._pool.acquire() as conn:
            await conn.execute(CREATE_TABLE_SQL)

    async def land(
        self,
        *,
        path: str,
        file_id: str,
        user_id: str,
        filename: str,
        content_type: Optional[str],
        executor=None,
    ) -> int:
        """Copy the upload to durable storage, then record it. Returns the row id.

        Bytes are written before the row so a row never points at missing data.
        """
        import asyncio

        loop = asyncio.get_running_loop()
        sha256 = await loop.run_in_executor(executor, _sha256_file, path)
        size = os.path.getsize(path)
        key = _storage_key(user_id, file_id, sha256, filename)
        await loop.run_in_executor(
            executor, self._backend.put_file, key, path, content_type
        )
        async with self._pool.acquire() as conn:
            row_id = await conn.fetchval(
                f"""
                INSERT INTO {TABLE}
                    (file_id, user_id, filename, content_type, size_bytes, sha256,
                     storage, storage_key, status)
                VALUES ($1, $2, $3, $4, $5, $6, $7, $8, '{UploadStatus.LANDED}')
                RETURNING id
                """,
                file_id,
                user_id,
                filename,
                content_type,
                size,
                sha256,
                self._backend.tag,
                key,
            )
        return int(row_id)

    async def mark_succeeded(self, row_id: int) -> None:
        """Flip to succeeded; drop the bytes unless configured to keep them."""
        async with self._pool.acquire() as conn:
            key = await conn.fetchval(
                f"UPDATE {TABLE} SET status = '{UploadStatus.SUCCEEDED}', last_error = NULL, "
                f"updated_at = now() WHERE id = $1 RETURNING storage_key",
                row_id,
            )
            if key and not self._keep_on_success:
                try:
                    self._backend.delete(key)
                    await conn.execute(
                        f"UPDATE {TABLE} SET storage_key = NULL WHERE id = $1", row_id
                    )
                except (
                    Exception
                ) as exc:  # an orphaned blob is harmless; a lost row is not
                    logger.warning(
                        "Could not delete landed bytes for upload %s: %s", row_id, exc
                    )

    async def mark_failed(self, row_id: int, error: str) -> None:
        """Flip to failed; the bytes are retained for replay."""
        async with self._pool.acquire() as conn:
            await conn.execute(
                f"UPDATE {TABLE} SET status = '{UploadStatus.FAILED}', last_error = $2, "
                f"updated_at = now() WHERE id = $1",
                row_id,
                (error or "")[:2000],
            )

    async def list_failed(
        self, owners: Sequence[str], limit: int = 100
    ) -> List[UploadRecord]:
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(
                f"SELECT * FROM {TABLE} WHERE status = '{UploadStatus.FAILED}' "
                f"AND user_id = ANY($1::text[]) ORDER BY created_at DESC LIMIT $2",
                list(owners),
                limit,
            )
        return [UploadRecord.from_row(row) for row in rows]

    async def get_owned(
        self, row_id: int, owners: Sequence[str]
    ) -> Optional[UploadRecord]:
        """A row only if one of ``owners`` owns it (others read as absent)."""
        async with self._pool.acquire() as conn:
            row = await conn.fetchrow(
                f"SELECT * FROM {TABLE} WHERE id = $1 AND user_id = ANY($2::text[])",
                row_id,
                list(owners),
            )
        return UploadRecord.from_row(row) if row else None

    async def begin_retry(self, row_id: int) -> None:
        async with self._pool.acquire() as conn:
            await conn.execute(
                f"UPDATE {TABLE} SET status = '{UploadStatus.LANDED}', attempts = attempts + 1, "
                f"updated_at = now() WHERE id = $1",
                row_id,
            )

    def fetch_bytes(self, record: UploadRecord, dest_path: str) -> None:
        if not record.storage_key:
            raise FileNotFoundError(
                "the landed bytes for this upload were already removed"
            )
        self._backend.get_file(record.storage_key, dest_path)

    async def delete_for_files(
        self, file_ids: Sequence[str], owners: Sequence[str]
    ) -> int:
        """Remove landed bytes + rows for deleted documents (owner-scoped)."""
        async with self._pool.acquire() as conn:
            rows = await conn.fetch(
                f"DELETE FROM {TABLE} WHERE file_id = ANY($1::text[]) AND user_id = ANY($2::text[]) "
                f"RETURNING storage_key",
                list(file_ids),
                list(owners),
            )
        for row in rows:
            if row["storage_key"]:
                try:
                    self._backend.delete(row["storage_key"])
                except Exception as exc:
                    logger.warning(
                        "Orphaned landed blob %s: %s", row["storage_key"], exc
                    )
        return len(rows)


_store: Optional[RawUploadStore] = None


def get_store() -> Optional[RawUploadStore]:
    """The process-wide store, or ``None`` when landing is disabled."""
    return _store


async def init_store(
    pool, cfg: Optional[EnhancementSettings] = None
) -> Optional[RawUploadStore]:
    """Create the store and its table at startup (no-op when disabled)."""
    global _store
    cfg = cfg or settings
    if not cfg.raw_upload_landing:
        _store = None
        return None
    store = RawUploadStore(
        pool, build_backend(cfg), keep_on_success=cfg.raw_upload_keep_on_success
    )
    await store.ensure_schema()
    _store = store
    logger.info("Raw-upload landing enabled (backend=%s)", store._backend.tag)
    return store


# --- Thin helpers the routes call; each is a no-op when landing is disabled ---


async def land_upload(
    path, *, file_id, user_id, filename, content_type, executor=None
) -> Optional[int]:
    """Land an upload before processing. Never raises: landing is best-effort,
    so a storage outage degrades durability rather than blocking ingestion."""
    store = get_store()
    if store is None:
        return None
    try:
        return await store.land(
            path=path,
            file_id=file_id,
            user_id=user_id,
            filename=filename,
            content_type=content_type,
            executor=executor,
        )
    except Exception as exc:
        logger.warning("Raw-upload landing failed for file_id=%s: %s", file_id, exc)
        return None


async def finish_upload(row_id: Optional[int], error: Optional[str] = None) -> None:
    store = get_store()
    if store is None or row_id is None:
        return
    try:
        if error is None:
            await store.mark_succeeded(row_id)
        else:
            await store.mark_failed(row_id, error)
    except Exception as exc:
        logger.warning("Could not update raw-upload row %s: %s", row_id, exc)


async def forget_files(file_ids: Sequence[str], owners: Sequence[str]) -> None:
    store = get_store()
    if store is None:
        return
    try:
        await store.delete_for_files(file_ids, owners)
    except Exception as exc:
        logger.warning(
            "Could not remove landed uploads for %s: %s", list(file_ids), exc
        )
