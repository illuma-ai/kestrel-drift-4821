﻿"""The only functions the stock modules call into this package.

Keeping every integration point here means the stock files gain a few one-line
calls and nothing else; each hook is a no-op (or returns ``None`` to mean "use
the stock path") when its feature is disabled.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Optional

from app.enhancements.config import RetrievalStrategy, settings

logger = logging.getLogger(__name__)

# Background startup tasks are held here so they are not garbage-collected
# mid-flight (asyncio keeps only weak references to tasks).
_background_tasks: set = set()


def _spawn(awaitable) -> None:
    # ensure_future (not create_task): executor work arrives as a Future, not a coroutine.
    task = asyncio.ensure_future(awaitable)
    _background_tasks.add(task)
    task.add_done_callback(_background_tasks.discard)


async def on_startup(app, *, is_pgvector: bool, pg_pool_getter) -> None:
    """Prepare enabled enhancements. Never blocks startup on slow work.

    * Raw-upload table: created synchronously (cheap, and the embed routes
      depend on it).
    * Full-text index: built ``CONCURRENTLY`` in the background â€” on a large
      table this can take minutes and must not hold up readiness.
    * Reranker: model loaded in the background so the first query is fast.
    """
    from app.enhancements import raw_uploads
    from app.enhancements.retrieval import fts, rerank

    if settings.raw_upload_landing:
        if is_pgvector:
            await raw_uploads.init_store(await pg_pool_getter())
        else:
            logger.warning(
                "RAG_RAW_UPLOAD_LANDING needs the Postgres backend; landing disabled"
            )

    if settings.retrieval == RetrievalStrategy.HYBRID:
        if not is_pgvector:
            logger.warning(
                "RAG_RETRIEVAL_STRATEGY=hybrid needs the Postgres backend; using vector retrieval"
            )
        elif settings.fts_create_index:
            _spawn(fts.ensure_fts_index(await pg_pool_getter(), settings.fts_language))

    if settings.rerank:
        loop = asyncio.get_running_loop()
        _spawn(
            loop.run_in_executor(
                app.state.thread_pool, rerank.warm_up, settings.rerank_model
            )
        )

    logger.info(
        "Retrieval enhancements | extraction=%s ocr=%s captions=%s chunking=%s retrieval=%s "
        "rerank=%s merge=%s expansion=%s landing=%s",
        settings.extraction.value,
        settings.ocr_provider.value,
        settings.figure_captions,
        settings.chunking.value,
        settings.retrieval.value,
        settings.rerank,
        settings.merge_adjacent_chunks,
        settings.query_expansion,
        settings.raw_upload_landing,
    )


def get_loader_override(filename, content_type, filepath, raw_text=False):
    """Return ``(loader, known_type, file_ext)`` or ``None`` for the stock loader."""
    if not settings.enhanced_extraction_enabled:
        return None
    from app.enhancements.extraction import get_enhanced_loader

    return get_enhanced_loader(filename, content_type, filepath, raw_text=raw_text)


def build_text_splitter(chunk_size: int, chunk_overlap: int):
    """The configured splitter (stock RecursiveCharacterTextSplitter by default)."""
    from app.enhancements.chunking import build_text_splitter as _build

    return _build(chunk_size, chunk_overlap)


async def search(
    request,
    *,
    query: str,
    k: int,
    file_ids,
    scope,
    query_filter: dict,
    vector_store,
    embed_query,
    distance_threshold,
) -> Optional[list]:
    """Enhanced /query; returns ``None`` when no retrieval enhancement is on."""
    if not settings.retrieval_pipeline_enabled:
        return None

    from app.config import COLLECTION_NAME, VECTOR_DB_TYPE, VectorDBType
    from app.enhancements.retrieval.pipeline import enhanced_search
    from app.services.database import PSQLDatabase
    from app.services.vector_store.async_pg_vector import AsyncPgVector
    from app.utils.async_utils import run_in_executor

    executor = request.app.state.thread_pool

    async def vector_search(embedding, k_, filter_):
        if isinstance(vector_store, AsyncPgVector):
            return await vector_store.asimilarity_search_with_score_by_vector(
                embedding, k=k_, filter=filter_, executor=executor
            )
        return await run_in_executor(
            executor,
            vector_store.similarity_search_with_score_by_vector,
            embedding,
            k=k_,
            filter=filter_,
        )

    is_pgvector = VECTOR_DB_TYPE == VectorDBType.PGVECTOR
    return await enhanced_search(
        query=query,
        k=k,
        file_ids=list(file_ids),
        owners=list(scope.owners),
        query_filter=query_filter,
        vector_search=vector_search,
        embed_query=embed_query,
        executor=executor,
        distance_threshold=distance_threshold,
        pg_pool_getter=PSQLDatabase.get_pool if is_pgvector else None,
        collection_name=COLLECTION_NAME if is_pgvector else None,
    )
