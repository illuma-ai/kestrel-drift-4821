"""Endpoints for the durable raw-upload store.

* ``GET  /uploads/failed`` — the caller's failed ingestions.
* ``POST /uploads/{upload_id}/replay`` — re-run ingestion from the landed bytes.

Both are owner-scoped exactly like the document routes: the caller's identity
comes from the verified token (plus an optional ``entity_id``), and an upload
owned by someone else reads as 404 rather than 403, so these routes are not an
existence oracle.

Always mounted; both answer 404 unless ``RAG_RAW_UPLOAD_LANDING=true``.
"""

from __future__ import annotations

import os
import tempfile
import traceback
import uuid

from fastapi import APIRouter, HTTPException, Request

from app.enhancements.raw_uploads import get_store
from app.scope import resolve_scope

router = APIRouter(prefix="/uploads", tags=["uploads"])


def _require_store():
    store = get_store()
    if store is None:
        raise HTTPException(status_code=404, detail="Raw-upload landing is not enabled")
    return store


@router.get("/failed")
async def list_failed_uploads(
    request: Request, entity_id: str = None, limit: int = 100
):
    store = _require_store()
    scope = resolve_scope(request, entity_id)
    records = await store.list_failed(scope.owners, limit=max(1, min(limit, 500)))
    return [record.public() for record in records]


@router.post("/{upload_id}/replay")
async def replay_upload(request: Request, upload_id: int, entity_id: str = None):
    """Re-ingest a landed upload through the normal embed pipeline.

    Ingestion runs under the upload's recorded owner (already proven to be in
    the caller's scope), so a replay can never write chunks under a different
    owner than the original upload.
    """
    # Imported lazily: the document routes import this package's hooks.
    from app.config import logger
    from app.routes.document_routes import load_file_content, store_data_in_vector_db

    store = _require_store()
    scope = resolve_scope(request, entity_id)
    record = await store.get_owned(upload_id, scope.owners)
    if record is None:
        raise HTTPException(status_code=404, detail="Upload not found")
    if not record.storage_key:
        raise HTTPException(
            status_code=409, detail="The original bytes are no longer retained"
        )

    suffix = os.path.splitext(record.filename)[1][:16]
    temp_path = os.path.join(
        tempfile.gettempdir(), f"replay_{uuid.uuid4().hex}{suffix}"
    )
    executor = request.app.state.thread_pool
    await store.begin_retry(record.id)
    try:
        import asyncio

        await asyncio.get_running_loop().run_in_executor(
            executor, store.fetch_bytes, record, temp_path
        )
        data, known_type, file_ext = await load_file_content(
            record.filename, record.content_type, temp_path, executor
        )
        result = await store_data_in_vector_db(
            data=data,
            file_id=record.file_id,
            user_id=record.user_id,
            clean_content=file_ext == "pdf",
            executor=executor,
            route_name="replay",
            filename=record.filename,
            content_type=record.content_type,
            temp_file_path=temp_path,
        )
        if not result or "error" in result:
            error = (result or {}).get(
                "error"
            ) or "Failed to process/store the file data."
            await store.mark_failed(record.id, str(error))
            raise HTTPException(status_code=500, detail=str(error))
        await store.mark_succeeded(record.id)
        return {
            "status": True,
            "message": "File processed successfully.",
            "upload_id": record.id,
            "file_id": record.file_id,
            "filename": record.filename,
            "known_type": known_type,
        }
    except HTTPException:
        raise
    except Exception as exc:
        logger.error(
            "Replay failed | upload_id=%s | error=%s | %s",
            record.id,
            exc,
            traceback.format_exc(),
        )
        await store.mark_failed(record.id, str(exc))
        raise HTTPException(
            status_code=400, detail=f"Error during file processing: {exc}"
        )
    finally:
        try:
            os.remove(temp_path)
        except OSError:
            pass
