"""Opt-in chunking strategies for the ingestion pipeline.

Stock ingestion splits every document with ``RecursiveCharacterTextSplitter``,
which cuts markdown tables mid-row (dropping the column headers that give the
numbers meaning) and discards the heading hierarchy a passage lives under. This
module provides two drop-in replacements that expose the same
``split_documents(list[Document]) -> list[Document]`` contract:

* :class:`TableAwareSplitter` - tables are kept whole, or split into row batches
  that each repeat the header + separator, so every fragment stays queryable.
* :class:`StructureSplitter` - markdown is converted to a structured document
  and packed to a token budget; each chunk is prefixed with its heading path.

Every output chunk COPIES its source document's metadata so downstream
consumers (e.g. the client reading ``metadata["page"]``) keep working.

Heavy dependencies (docling-core, marko, tiktoken) are imported lazily so this
module imports - and the default RECURSIVE strategy runs - without them.
"""

from __future__ import annotations

import logging
import re
from typing import Any, List, Optional

from langchain_core.documents import Document
from langchain_text_splitters import RecursiveCharacterTextSplitter

from app.enhancements.config import ChunkingStrategy, settings

logger = logging.getLogger(__name__)

# A markdown table separator row: | --- | :---: |
_SEPARATOR_RE = re.compile(r"^\s*\|\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|\s*$")


def _is_table_row(line: str) -> bool:
    """True if the line looks like a pipe-delimited markdown table row."""
    s = line.strip()
    return s.startswith("|") and s.endswith("|") and s.count("|") >= 2


def _split_regions(text: str) -> List[tuple]:
    """Split text into ordered ``(is_table, content)`` regions.

    A table region is header row + separator row + the contiguous data rows
    that follow; everything else is a plain-text region.
    """
    lines = text.split("\n")
    regions: List[tuple] = []
    buf: List[str] = []
    i = 0
    while i < len(lines):
        line = lines[i]
        if _SEPARATOR_RE.match(line) and buf and _is_table_row(buf[-1]):
            header = buf.pop()
            if buf:
                regions.append((False, "\n".join(buf).strip()))
                buf = []
            table_lines = [header, line]
            i += 1
            while i < len(lines) and _is_table_row(lines[i]):
                table_lines.append(lines[i])
                i += 1
            regions.append((True, "\n".join(table_lines)))
        else:
            buf.append(line)
            i += 1
    tail = "\n".join(buf).strip()
    if tail:
        regions.append((False, tail))
    return regions


class TableAwareSplitter:
    """Character splitter that never cuts a markdown table mid-row.

    WHY: a table fragment without its header row is meaningless to retrieval,
    so oversized tables are split by row batches and each batch repeats the
    header + separator.

    Args:
        chunk_size: Max characters per non-table chunk.
        chunk_overlap: Character overlap for non-table chunks.
        rows_per_chunk: Max data rows per table fragment.
    """

    def __init__(
        self, chunk_size: int, chunk_overlap: int, rows_per_chunk: Optional[int] = None
    ):
        self._text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=chunk_size, chunk_overlap=chunk_overlap
        )
        self._rows_per_chunk = max(1, rows_per_chunk or settings.table_rows_per_chunk)

    def split_text(self, text: str) -> List[str]:
        """Split raw text into chunks, keeping tables intact."""
        if not text or not text.strip():
            return []
        if not any(_SEPARATOR_RE.match(line) for line in text.split("\n")):
            return self._text_splitter.split_text(text)
        chunks: List[str] = []
        for is_table, content in _split_regions(text):
            if is_table:
                chunks.extend(self._chunk_table(content))
            elif content:
                chunks.extend(self._text_splitter.split_text(content))
        return chunks

    def _chunk_table(self, table: str) -> List[str]:
        lines = table.split("\n")
        if len(lines) < 2:
            return [table]
        header, separator, rows = lines[0], lines[1], lines[2:]
        if len(rows) <= self._rows_per_chunk:
            return [table]
        return [
            "\n".join([header, separator, *rows[i : i + self._rows_per_chunk]])
            for i in range(0, len(rows), self._rows_per_chunk)
        ]

    def split_documents(self, documents: List[Document]) -> List[Document]:
        """Split each document, copying its metadata onto every chunk."""
        out: List[Document] = []
        for doc in documents:
            for chunk in self.split_text(doc.page_content):
                out.append(Document(page_content=chunk, metadata=dict(doc.metadata)))
        return out


# ---------------------------------------------------------------------------
# Structure-aware chunking (markdown -> structured document -> hybrid chunker)
# ---------------------------------------------------------------------------


def _inline_text(element: Any) -> str:
    """Recursively collect plain text from a marko element."""
    children = getattr(element, "children", None)
    if isinstance(children, str):
        return children
    if isinstance(children, list):
        return "".join(_inline_text(c) for c in children)
    return ""


def _add_table(doc: Any, table_el: Any) -> None:
    """Append a GFM table to the structured document as real table data."""
    from docling_core.types.doc import TableCell, TableData

    rows = list(getattr(table_el, "children", []) or [])
    head = getattr(table_el, "head", None)
    if head is not None and (not rows or rows[0] is not head):
        rows = [head] + rows
    if not rows:
        return
    n_cols = max((len(getattr(r, "children", []) or []) for r in rows), default=0)
    if n_cols == 0:
        return
    cells = []
    for r_idx, row in enumerate(rows):
        for c_idx, cell in enumerate(getattr(row, "children", []) or []):
            cells.append(
                TableCell(
                    text=_inline_text(cell).strip(),
                    row_span=1,
                    col_span=1,
                    start_row_offset_idx=r_idx,
                    end_row_offset_idx=r_idx + 1,
                    start_col_offset_idx=c_idx,
                    end_col_offset_idx=c_idx + 1,
                    column_header=(r_idx == 0),
                )
            )
    doc.add_table(
        data=TableData(num_rows=len(rows), num_cols=n_cols, table_cells=cells)
    )


def markdown_to_structured_document(md: str, name: str = "document") -> Any:
    """Build a structured document (headings, text, tables, lists) from markdown.

    Uses a light marko GFM walk instead of the full document-conversion stack,
    which would pull in heavy ML dependencies. Unknown block types degrade to
    plain text so no content is dropped.
    """
    import marko
    import marko.block
    from docling_core.types.doc import DoclingDocument

    ast = marko.Markdown(extensions=["gfm"]).parse(md)
    doc = DoclingDocument(name=name)
    for el in getattr(ast, "children", []) or []:
        if isinstance(el, (marko.block.Heading, marko.block.SetextHeading)):
            text = _inline_text(el).strip()
            if text:
                doc.add_heading(
                    text=text, level=min(max(int(getattr(el, "level", 1)), 1), 6)
                )
        elif type(el).__name__ == "Table":
            _add_table(doc, el)
        elif isinstance(el, marko.block.List):
            items = [
                t
                for t in (
                    _inline_text(i).strip() for i in (getattr(el, "children", []) or [])
                )
                if t
            ]
            if items:
                group = doc.add_list_group(name="list")
                for item in items:
                    doc.add_list_item(text=item, parent=group)
        elif isinstance(el, marko.block.BlankLine):
            continue
        else:
            text = _inline_text(el).strip()
            if text:
                doc.add_text(label="text", text=text)
    return doc


class StructureSplitter:
    """Heading/table-aware, token-budgeted splitter.

    WHY: contextualised chunks carry their heading path ("Report, Revenue"),
    which disambiguates passages that are otherwise identical across sections.
    Chunks are budgeted in tokens (not characters) so they line up with what
    the embedding model actually sees.

    Any per-document failure falls back to :class:`TableAwareSplitter` for that
    document; this class never raises from ``split_documents``.
    """

    def __init__(
        self,
        chunk_size: int,
        chunk_overlap: int,
        max_tokens: Optional[int] = None,
        tokenizer_name: Optional[str] = None,
    ):
        self._max_tokens = max_tokens or settings.structure_chunk_max_tokens
        self._tokenizer_name = tokenizer_name or settings.structure_chunk_tokenizer
        self._fallback = TableAwareSplitter(chunk_size, chunk_overlap)
        self._chunker: Any = None

    def _get_chunker(self) -> Any:
        """Build the hybrid chunker once (tokenizer load is the costly step)."""
        if self._chunker is None:
            import tiktoken
            from docling_core.transforms.chunker.hybrid_chunker import HybridChunker
            from docling_core.transforms.chunker.tokenizer.openai import OpenAITokenizer

            tokenizer = OpenAITokenizer(
                tokenizer=tiktoken.get_encoding(self._tokenizer_name),
                max_tokens=self._max_tokens,
            )
            self._chunker = HybridChunker(tokenizer=tokenizer)
        return self._chunker

    def _split_one(self, doc: Document) -> List[Document]:
        text = doc.page_content
        if not text or not text.strip():
            return []
        try:
            structured = markdown_to_structured_document(text)
            chunker = self._get_chunker()
            texts = [chunker.contextualize(chunk=c) for c in chunker.chunk(structured)]
            texts = [t for t in (s.strip() for s in texts) if t]
            if texts:
                return [
                    Document(page_content=t, metadata=dict(doc.metadata)) for t in texts
                ]
            logger.warning(
                "Structure chunker produced no chunks; using table-aware fallback"
            )
        except (
            Exception
        ) as exc:  # noqa: BLE001 - ingestion must never break on one document
            logger.warning(
                "Structure chunking failed (%s); using table-aware fallback", exc
            )
        return self._fallback.split_documents([doc])

    def split_documents(self, documents: List[Document]) -> List[Document]:
        """Split each document, copying its metadata onto every chunk."""
        out: List[Document] = []
        for doc in documents:
            out.extend(self._split_one(doc))
        return out


def _structure_deps_available() -> bool:
    try:
        import docling_core.transforms.chunker.hybrid_chunker  # noqa: F401
        import docling_core.transforms.chunker.tokenizer.openai  # noqa: F401
        import marko  # noqa: F401
        import tiktoken  # noqa: F401
    except ImportError:
        return False
    return True


def build_text_splitter(
    chunk_size: int, chunk_overlap: int, strategy: Optional[ChunkingStrategy] = None
):
    """Return the splitter for the configured chunking strategy.

    RECURSIVE returns the stock ``RecursiveCharacterTextSplitter`` so default
    behaviour is unchanged. STRUCTURE degrades to TABLE_AWARE (with a warning)
    when its optional dependencies are not installed.
    """
    strategy = strategy or settings.chunking
    if strategy == ChunkingStrategy.TABLE_AWARE:
        return TableAwareSplitter(chunk_size, chunk_overlap)
    if strategy == ChunkingStrategy.STRUCTURE:
        if _structure_deps_available():
            return StructureSplitter(chunk_size, chunk_overlap)
        logger.warning(
            "Chunking strategy 'structure' needs docling-core, marko and tiktoken; "
            "falling back to table_aware"
        )
        return TableAwareSplitter(chunk_size, chunk_overlap)
    return RecursiveCharacterTextSplitter(
        chunk_size=chunk_size, chunk_overlap=chunk_overlap
    )
