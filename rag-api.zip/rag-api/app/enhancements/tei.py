"""Embeddings client for a self-hosted Text Embeddings Inference (TEI) server.

Why this exists: the stock ``huggingfacetei`` provider passes the server URL to
``HuggingFaceEndpointEmbeddings(model=...)``, which current releases reject
("model must be a HuggingFace repo ID, not a URL"), and it sends every chunk of
a batch in one request, which TEI refuses above ``--max-client-batch-size``
(32 by default). This client talks to TEI's ``/embed`` route directly:

* splits documents into requests of ``RAG_TEI_BATCH_SIZE`` texts;
* keeps up to ``RAG_TEI_CONCURRENCY`` requests in flight so the server's own
  dynamic batching stays busy (PERF: TEI batches across requests);
* retries 429/503/5xx and connection errors with exponential backoff (SCALE:
  a busy pod sheds load with 429 instead of dropping the upload);
* asks the server to truncate over-long inputs instead of failing the upload.

A self-hosted server has no per-token quota or billing, so it removes managed
API throttling entirely; capacity is set by the number of replicas.
"""

from __future__ import annotations

import logging
import time
from concurrent.futures import ThreadPoolExecutor
from typing import List

import httpx
from langchain_core.embeddings import Embeddings

logger = logging.getLogger(__name__)

_RETRY_STATUS = {408, 425, 429, 500, 502, 503, 504}


class TeiEmbeddings(Embeddings):
    """LangChain ``Embeddings`` backed by a TEI server's ``/embed`` endpoint.

    Args:
        base_url: Server root, e.g. ``http://tei.rag.svc:80``.
        batch_size: Texts per request; keep <= the server's
            ``--max-client-batch-size``.
        concurrency: Requests in flight per ``embed_documents`` call.
        query_prefix: Optional instruction prepended to queries only (some
            models, e.g. bge, were trained with one).
        timeout: Per-request timeout in seconds.
        max_retries: Attempts per request before giving up.
    """

    def __init__(
        self,
        base_url: str,
        batch_size: int = 32,
        concurrency: int = 4,
        query_prefix: str = "",
        timeout: float = 60.0,
        max_retries: int = 6,
        retry_delay: float = 0.5,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.batch_size = max(1, batch_size)
        self.concurrency = max(1, concurrency)
        self.query_prefix = query_prefix
        self.max_retries = max(1, max_retries)
        self.retry_delay = retry_delay
        self._client = httpx.Client(
            timeout=timeout,
            limits=httpx.Limits(max_connections=self.concurrency * 2),
            transport=transport,
        )

    def _post(self, texts: List[str]) -> List[List[float]]:
        payload = {"inputs": texts, "truncate": True, "normalize": True}
        delay = self.retry_delay
        for attempt in range(1, self.max_retries + 1):
            try:
                response = self._client.post(f"{self.base_url}/embed", json=payload)
                if response.status_code not in _RETRY_STATUS:
                    response.raise_for_status()
                    return response.json()
                reason = f"HTTP {response.status_code}"
            except (httpx.TransportError, httpx.TimeoutException) as exc:
                reason = str(exc) or type(exc).__name__
            if attempt == self.max_retries:
                raise RuntimeError(
                    f"Embedding server {self.base_url} failed after {attempt} attempts: {reason}"
                )
            logger.warning(
                "Embedding request retry %d/%d (%s)", attempt, self.max_retries, reason
            )
            time.sleep(delay)
            delay = min(delay * 2, 8.0)
        raise AssertionError("unreachable")

    def embed_documents(self, texts: List[str]) -> List[List[float]]:
        if not texts:
            return []
        batches = [
            texts[i : i + self.batch_size]
            for i in range(0, len(texts), self.batch_size)
        ]
        if len(batches) == 1:
            return self._post(batches[0])
        with ThreadPoolExecutor(
            max_workers=min(self.concurrency, len(batches))
        ) as pool:
            results = list(pool.map(self._post, batches))  # map keeps input order
        return [vector for batch in results for vector in batch]

    def embed_query(self, text: str) -> List[float]:
        return self._post([f"{self.query_prefix}{text}"])[0]
