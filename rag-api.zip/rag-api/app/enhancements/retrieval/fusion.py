﻿"""Candidate identity, rank fusion, and adjacent-chunk merging.

Pure functions (no I/O) so they are cheap to unit test.

Score contract: the public /query response is a list of ``(Document, score)``
pairs where ``score`` is a *distance* â€” lower is better, roughly in ``[0, 1]``.
Clients sort ascending by it and display ``1 - score`` as relevance, so every
stage here must emit a distance whose ascending order matches the final ranking.
"""

from __future__ import annotations

import hashlib
from typing import Dict, Hashable, List, Sequence, Tuple

from langchain_core.documents import Document

# Metadata keys stamped on every chunk at ingestion time by the stock pipeline
# (see ``_tag_documents_for_ingestion`` in the document routes). Reused here so
# chunk identity and order come from the same source of truth.
CHUNK_INDEX_KEY = "_rag_chunk_index"
ATTEMPT_ID_KEY = "_rag_ingestion_attempt_id"

ScoredDocs = List[Tuple[Document, float]]


def doc_key(doc: Document) -> Hashable:
    """Stable identity for a stored chunk across retrieval legs.

    The vector and full-text legs return separate ``Document`` objects for the
    same row, so dedupe needs a content-independent key. Prefer the ingestion
    attempt + chunk index (unique per stored row); fall back to the content
    digest for rows written before those keys existed.
    """
    meta = doc.metadata or {}
    file_id = meta.get("file_id")
    attempt = meta.get(ATTEMPT_ID_KEY)
    index = meta.get(CHUNK_INDEX_KEY)
    if attempt is not None and isinstance(index, int) and not isinstance(index, bool):
        return ("chunk", file_id, attempt, index)
    digest = (
        meta.get("digest")
        or hashlib.md5((doc.page_content or "").encode("utf-8", "ignore")).hexdigest()
    )
    return ("digest", file_id, digest)


def reciprocal_rank_fusion(
    ranked_lists: Sequence[ScoredDocs], k: int = 60
) -> ScoredDocs:
    """Fuse several ranked candidate lists with Reciprocal Rank Fusion.

    RRF combines lists whose raw scores are not comparable (cosine distance vs.
    ``ts_rank``) using rank position only: ``sum(1 / (k + rank))``. It is the
    standard, tuning-free way to merge dense and lexical retrieval.

    The fused score is converted to a distance by normalising against the best
    possible fused score (rank 1 in every list), so a chunk that tops every list
    gets distance 0 and ordering stays monotonic.

    Args:
        ranked_lists: Each list ordered best-first (its scores are ignored).
        k: RRF damping constant (60 is the value from the original paper).

    Returns:
        Unique documents ordered best-first, each with a fused distance.
    """
    lists = [lst for lst in ranked_lists if lst]
    if not lists:
        return []
    if len(lists) == 1:
        return list(lists[0])

    fused: Dict[Hashable, float] = {}
    first_seen: Dict[Hashable, Document] = {}
    for lst in lists:
        for rank, (doc, _score) in enumerate(lst, start=1):
            key = doc_key(doc)
            fused[key] = fused.get(key, 0.0) + 1.0 / (k + rank)
            first_seen.setdefault(key, doc)

    best_possible = len(lists) / (k + 1)
    ordered = sorted(fused.items(), key=lambda item: item[1], reverse=True)
    return [(first_seen[key], 1.0 - (score / best_possible)) for key, score in ordered]


def merge_adjacent_chunks(results: ScoredDocs) -> ScoredDocs:
    """Join consecutive chunks of the same file into one passage.

    When retrieval returns chunks 4, 5 and 6 of one file, the model reads them
    best as one contiguous passage rather than three fragments that each lose
    their neighbours' context. Runs are formed per (file, ingestion attempt) on
    consecutive chunk indexes; the merged entry keeps the first chunk's metadata
    (so its page number is where the passage starts) and the run's best
    (lowest) distance. Chunks without index metadata pass through unchanged.

    Runs never cross a page boundary: clients cite a passage by its single
    ``page`` value, so a passage spanning pages 1-3 labelled "page 1" would
    send readers to the wrong page for the rest of its text.

    The output is re-sorted by distance, so ranking is preserved. Idempotent.
    """
    if len(results) < 2:
        return list(results)

    groups: Dict[Hashable, List[Tuple[Document, float]]] = {}
    passthrough: ScoredDocs = []
    for doc, score in results:
        meta = doc.metadata or {}
        index = meta.get(CHUNK_INDEX_KEY)
        if isinstance(index, int) and not isinstance(index, bool):
            group = (meta.get("file_id"), meta.get(ATTEMPT_ID_KEY), meta.get("page"))
            groups.setdefault(group, []).append((doc, score))
        else:
            passthrough.append((doc, score))

    merged: ScoredDocs = list(passthrough)
    for members in groups.values():
        members.sort(key=lambda item: item[0].metadata[CHUNK_INDEX_KEY])
        run: List[Tuple[Document, float]] = []

        def flush() -> None:
            if not run:
                return
            if len(run) == 1:
                merged.append(run[0])
                return
            first_doc = run[0][0]
            metadata = dict(first_doc.metadata or {})
            metadata["merged_chunk_count"] = len(run)
            merged.append(
                (
                    Document(
                        page_content="\n\n".join(d.page_content for d, _ in run),
                        metadata=metadata,
                    ),
                    min(score for _, score in run),
                )
            )

        for doc, score in members:
            index = doc.metadata[CHUNK_INDEX_KEY]
            if run and index == run[-1][0].metadata[CHUNK_INDEX_KEY] + 1:
                run.append((doc, score))
            else:
                flush()
                run = [(doc, score)]
        flush()

    merged.sort(key=lambda item: item[1])
    return merged
