"""LLM query expansion.

Rewrites the user's question into a few alternative phrasings so retrieval can
also match documents that use different vocabulary (e.g. "revenue" vs. "net
sales"). Every phrasing is searched and the result lists are rank-fused.

Opt-in and eval-gated: it adds one LLM call per query and can lower precision
on already-precise queries, so measure before enabling it in production.
"""

from __future__ import annotations

import logging
from typing import Callable, List, Optional

from app.enhancements.config import make_aws_client

logger = logging.getLogger(__name__)

_SYSTEM_PROMPT = (
    "Rewrite the user's search query into {n} alternative phrasings that a document "
    "might use to express the same information need (synonyms, related terms, more "
    "specific or more general forms). Output ONLY the rephrasings, one per line, with "
    "no numbering and no commentary."
)


def parse_variants(original: str, raw: str, count: int) -> List[str]:
    """Clean the model output into at most ``count`` new, distinct phrasings."""
    seen = {original.strip().lower()}
    variants: List[str] = []
    for line in (raw or "").splitlines():
        candidate = line.strip().lstrip("-*0123456789.) \t").strip().strip('"')
        if candidate and candidate.lower() not in seen:
            seen.add(candidate.lower())
            variants.append(candidate)
    return variants[:count]


def build_bedrock_expander(model_id: str, count: int) -> Callable[[str], List[str]]:
    """Return a blocking ``query -> [variants]`` function backed by Bedrock.

    Returns an empty list on any error so the caller just searches the original
    query.
    """
    client = make_aws_client("bedrock-runtime")

    def expand(query: str) -> List[str]:
        if not query or not query.strip():
            return []
        try:
            response = client.converse(
                modelId=model_id,
                system=[{"text": _SYSTEM_PROMPT.format(n=count)}],
                messages=[{"role": "user", "content": [{"text": query}]}],
                inferenceConfig={"maxTokens": 150, "temperature": 0.3},
            )
            text = response["output"]["message"]["content"][0]["text"]
            return parse_variants(query, text, count)
        except Exception as exc:
            logger.warning("Query expansion failed, using original query only: %s", exc)
            return []

    return expand


_expander: Optional[Callable[[str], List[str]]] = None


def get_expander(model_id: str, count: int) -> Callable[[str], List[str]]:
    """Process-wide expander (one boto3 client, created on first use)."""
    global _expander
    if _expander is None:
        _expander = build_bedrock_expander(model_id, count)
    return _expander
