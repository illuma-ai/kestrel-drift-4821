"""Cross-encoder reranking of first-stage candidates.

A cross-encoder scores each ``(query, chunk)`` pair jointly, which is much more
precise than comparing two independently computed embeddings. It is too slow to
run over a whole corpus, so it only re-orders the small candidate pool the
first stage produced (``RAG_CANDIDATE_POOL``).

Runs locally on CPU through ``sentence-transformers`` (already a dependency of
the full image) — no GPU, no external API, no data leaving the service.
"""

from __future__ import annotations

import logging
import math
import threading
from typing import List, Optional, Tuple

from langchain_core.documents import Document

logger = logging.getLogger(__name__)

_MODELS: dict = {}
_LOCK = threading.Lock()


def _load_model(model_id: str):
    """Load (once per process) and cache the cross-encoder.

    Guarded by a lock because the first concurrent queries would otherwise all
    load the model in parallel worker threads.
    """
    model = _MODELS.get(model_id)
    if model is not None:
        return model
    with _LOCK:
        model = _MODELS.get(model_id)
        if model is None:
            from sentence_transformers import CrossEncoder

            model = CrossEncoder(model_id)
            _MODELS[model_id] = model
            logger.info("Reranker model loaded: %s", model_id)
    return model


def _sigmoid(value: float) -> float:
    # Clamp to avoid OverflowError on extreme logits.
    value = max(min(value, 50.0), -50.0)
    return 1.0 / (1.0 + math.exp(-value))


def rerank(
    model_id: str,
    query: str,
    candidates: List[Tuple[Document, float]],
    top_k: int,
) -> List[Tuple[Document, float]]:
    """Re-order candidates by cross-encoder relevance (blocking; run in a thread).

    The raw logit is squashed with a sigmoid into a ``(0, 1)`` relevance and
    returned as distance ``1 - relevance``, matching the /query score contract.
    On any failure the first-stage order is returned unchanged, so a reranker
    problem never fails a query.
    """
    if not candidates:
        return []
    try:
        model = _load_model(model_id)
        scores = model.predict(
            [(query, doc.page_content or "") for doc, _ in candidates]
        )
        ranked = sorted(
            zip(candidates, scores), key=lambda item: float(item[1]), reverse=True
        )
        return [
            (doc, 1.0 - _sigmoid(float(score))) for (doc, _), score in ranked[:top_k]
        ]
    except Exception as exc:
        logger.warning(
            "Rerank failed (%s), keeping first-stage order: %s", model_id, exc
        )
        return list(candidates[:top_k])


def warm_up(model_id: Optional[str]) -> None:
    """Load the model and run one prediction so the first query is not slow."""
    if not model_id:
        return
    try:
        _load_model(model_id).predict([("warm up", "warm up")])
    except Exception as exc:
        logger.warning("Reranker warm-up failed for %s: %s", model_id, exc)
