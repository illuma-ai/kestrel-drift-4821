"""Enhanced retrieval for /query and /query_multiple.

Entry point: :func:`app.enhancements.retrieval.pipeline.enhanced_search`.
"""
