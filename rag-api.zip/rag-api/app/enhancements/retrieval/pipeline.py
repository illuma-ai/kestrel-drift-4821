"""Enhanced /query pipeline: expand → retrieve (vector + lexical) → fuse →
rerank → merge.

Stages, each independently switchable (see :mod:`app.enhancements.config`):

1. **Query expansion** (``RAG_QUERY_EXPANSION``): alternative phrasings of the
   question are searched too.
2. **Candidate retrieval**: the stock vector search, oversampled to
   ``RAG_CANDIDATE_POOL`` when later stages need a pool to choose from, plus a
   scoped Postgres full-text leg when ``RAG_RETRIEVAL_STRATEGY=hybrid``.
3. **Fusion**: Reciprocal Rank Fusion across every (phrasing x leg) list.
4. **Rerank** (``RAG_RERANK_ENABLED``): local cross-encoder re-orders the pool
   against the original question.
5. **Merge** (``RAG_MERGE_ADJACENT_CHUNKS``): consecutive chunks of one file
   become a single passage.

The response keeps the stock contract: ``[(Document, distance), ...]`` sorted
by ascending distance, at most ``k`` entries, with the stored metadata (file,
page, ...) intact. Authorization is unchanged: every leg receives the same
``(file, owner)`` scope the stock route built, enforced in the store query.
"""

from __future__ import annotations

import asyncio
import logging
from typing import Awaitable, Callable, List, Optional, Sequence, Tuple

from langchain_core.documents import Document

from app.enhancements.config import EnhancementSettings, RetrievalStrategy, settings
from app.enhancements.retrieval import expansion, fts, rerank
from app.enhancements.retrieval.fusion import (
    ScoredDocs,
    merge_adjacent_chunks,
    reciprocal_rank_fusion,
)
from app.utils.async_utils import run_in_executor

logger = logging.getLogger(__name__)

VectorSearch = Callable[[List[float], int, dict], Awaitable[ScoredDocs]]


def candidate_pool_size(k: int, cfg: EnhancementSettings) -> int:
    """How many first-stage candidates each leg fetches.

    Fusion and reranking can only promote a chunk that made it into the pool,
    so they need more than ``k`` candidates; merge-only keeps the stock ``k``.
    """
    needs_pool = (
        cfg.rerank or cfg.query_expansion or cfg.retrieval == RetrievalStrategy.HYBRID
    )
    return max(k, cfg.candidate_pool) if needs_pool else k


async def enhanced_search(
    *,
    query: str,
    k: int,
    file_ids: Sequence[str],
    owners: Sequence[str],
    query_filter: dict,
    vector_search: VectorSearch,
    embed_query: Callable[[str], List[float]],
    executor,
    distance_threshold: Callable[[ScoredDocs], ScoredDocs],
    pg_pool_getter: Optional[Callable[[], Awaitable[object]]] = None,
    collection_name: Optional[str] = None,
    cfg: Optional[EnhancementSettings] = None,
) -> List[Tuple[Document, float]]:
    """Run the enhanced retrieval pipeline for one request.

    Args:
        query: The user's question.
        k: Number of results to return.
        file_ids: Files the request is scoped to.
        owners: Owner ids the request may read (from the verified token).
        query_filter: The stock store predicate (owner + file) for the vector leg.
        vector_search: ``(embedding, k, filter) -> [(doc, distance)]`` using the
            configured store; keeps this module store-agnostic.
        embed_query: Blocking query-embedding function (cached upstream).
        executor: Request worker pool for blocking work.
        distance_threshold: The stock ``RAG_DISTANCE_THRESHOLD`` filter, applied
            to the vector leg so weak dense matches are still dropped.
        pg_pool_getter: Returns the asyncpg pool; ``None`` disables the lexical
            leg (e.g. non-Postgres stores).
        collection_name: pgvector collection the lexical leg must stay inside.
        cfg: Settings override (tests); defaults to the process settings.

    Returns:
        At most ``k`` ``(Document, distance)`` pairs, ascending by distance.
    """
    cfg = cfg or settings
    pool_k = candidate_pool_size(k, cfg)

    phrasings = [query]
    if cfg.query_expansion:
        expander = expansion.get_expander(
            cfg.query_expansion_model, cfg.query_expansion_count
        )
        phrasings += await run_in_executor(executor, expander, query)

    use_lexical = (
        cfg.retrieval == RetrievalStrategy.HYBRID
        and pg_pool_getter is not None
        and collection_name is not None
    )
    pool = await pg_pool_getter() if use_lexical else None

    async def vector_leg(text: str) -> ScoredDocs:
        embedding = await run_in_executor(executor, embed_query, text)
        return distance_threshold(await vector_search(embedding, pool_k, query_filter))

    async def lexical_leg(text: str) -> ScoredDocs:
        return await fts.fts_search(
            pool,
            query=text,
            collection_name=collection_name,
            file_ids=file_ids,
            owners=owners,
            limit=pool_k,
            language=cfg.fts_language,
        )

    legs = [vector_leg(text) for text in phrasings]
    if use_lexical:
        legs += [lexical_leg(text) for text in phrasings]
    ranked_lists = await asyncio.gather(*legs)

    candidates = reciprocal_rank_fusion(ranked_lists, k=cfg.rrf_k)[:pool_k]

    if cfg.rerank and candidates:
        results = await run_in_executor(
            executor, rerank.rerank, cfg.rerank_model, query, candidates, k
        )
    else:
        results = candidates[:k]

    if cfg.merge_adjacent_chunks:
        results = merge_adjacent_chunks(results)

    logger.debug(
        "Enhanced search | phrasings=%d | lexical=%s | lists=%s | candidates=%d | returned=%d",
        len(phrasings),
        use_lexical,
        [len(lst) for lst in ranked_lists],
        len(candidates),
        len(results),
    )
    return results
