"""Postgres full-text (lexical) retrieval leg for hybrid search.

Dense vectors miss exact tokens — part numbers, names, codes, rare acronyms —
that lexical search matches trivially. This module adds that leg directly over
the stock ``langchain_pg_embedding`` table without changing its schema:

* An **expression GIN index** on ``to_tsvector(<lang>, document)`` is built
  ``CONCURRENTLY`` in the background, so there is no table rewrite and no
  write lock; queries work (more slowly) before it finishes.
* Queries use the identical expression so the planner can use that index.
* The same ``(collection, file, owner)`` scope the vector leg uses is applied
  *in SQL*, so a foreign chunk is never read into this process.
"""

from __future__ import annotations

import logging
from typing import List, Optional, Sequence, Tuple

from langchain_core.documents import Document

from app.enhancements.config import settings

logger = logging.getLogger(__name__)

EMBEDDING_TABLE = "langchain_pg_embedding"
COLLECTION_TABLE = "langchain_pg_collection"


def _tsvector_expr(language: str) -> str:
    # language is validated as a plain identifier in config (regconfig names
    # cannot be bound as parameters inside an index expression).
    return f"to_tsvector('{language}'::regconfig, document)"


def index_name(language: str) -> str:
    return f"ix_{EMBEDDING_TABLE}_fts_{language}"


def build_index_sql(language: str) -> str:
    return (
        f"CREATE INDEX CONCURRENTLY IF NOT EXISTS {index_name(language)} "
        f"ON {EMBEDDING_TABLE} USING gin ({_tsvector_expr(language)})"
    )


def build_search_sql(language: str) -> str:
    """SQL for one scoped full-text query.

    ``plainto_tsquery`` ANDs every term, which is too strict for natural-
    language questions ("what was revenue in q4" would need every lexeme in one
    chunk). Rewriting its output with ``|`` gives OR semantics while keeping its
    safe parsing and stemming; ``ts_rank_cd`` still rewards chunks that match
    more terms, closer together.

    Parameters: $1 query text, $2 collection name, $3 file ids, $4 owners,
    $5 limit.
    """
    tsv = _tsvector_expr(language)
    return f"""
        WITH q AS (
            SELECT NULLIF(
                replace(plainto_tsquery('{language}'::regconfig, $1)::text, '&', '|'),
                ''
            )::tsquery AS query
        )
        SELECT e.document, e.cmetadata, ts_rank_cd({tsv}, q.query) AS rank
        FROM {EMBEDDING_TABLE} e
        JOIN {COLLECTION_TABLE} c ON c.uuid = e.collection_id
        CROSS JOIN q
        WHERE q.query IS NOT NULL
          AND c.name = $2
          AND e.cmetadata->>'file_id' = ANY($3::text[])
          AND e.cmetadata->>'user_id' = ANY($4::text[])
          AND {tsv} @@ q.query
        ORDER BY rank DESC
        LIMIT $5
    """


def _metadata(raw) -> dict:
    """asyncpg returns json/jsonb as text unless a codec is registered."""
    if raw is None:
        return {}
    if isinstance(raw, dict):
        return raw
    import json

    try:
        return json.loads(raw)
    except (TypeError, ValueError):
        return {}


async def fts_search(
    pool,
    *,
    query: str,
    collection_name: str,
    file_ids: Sequence[str],
    owners: Sequence[str],
    limit: int,
    language: Optional[str] = None,
) -> List[Tuple[Document, float]]:
    """Run the scoped lexical query.

    Returns ``(Document, rank)`` pairs ordered best-first. ``rank`` is a raw
    ``ts_rank_cd`` value — only its order is used (via rank fusion).
    Failures are logged and return ``[]`` so a lexical-leg problem degrades to
    vector-only retrieval instead of failing the request.
    """
    if not query or not query.strip() or not file_ids or not owners or limit <= 0:
        return []
    language = language or settings.fts_language
    try:
        async with pool.acquire() as conn:
            rows = await conn.fetch(
                build_search_sql(language),
                query,
                collection_name,
                list(file_ids),
                list(owners),
                limit,
            )
    except Exception as exc:  # degrade to the vector leg only
        logger.warning("Full-text leg failed, continuing with vector results: %s", exc)
        return []
    return [
        (
            Document(
                page_content=row["document"] or "", metadata=_metadata(row["cmetadata"])
            ),
            float(row["rank"]),
        )
        for row in rows
    ]


async def ensure_fts_index(pool, language: Optional[str] = None) -> None:
    """Create the full-text expression index if it is missing.

    Runs ``CREATE INDEX CONCURRENTLY`` (must be outside a transaction, which a
    plain asyncpg ``execute`` is). Safe to call from every replica: the
    ``IF NOT EXISTS`` makes repeats no-ops, and a concurrent build from another
    replica just logs a warning. An interrupted concurrent build leaves an
    INVALID index; that is detected and reported so an operator can drop it.
    """
    language = language or settings.fts_language
    name = index_name(language)
    try:
        async with pool.acquire() as conn:
            table_exists = await conn.fetchval(
                "SELECT to_regclass($1) IS NOT NULL", EMBEDDING_TABLE
            )
            if not table_exists:
                logger.info(
                    "Skipping full-text index: %s does not exist yet", EMBEDDING_TABLE
                )
                return
            await conn.execute(build_index_sql(language))
            valid = await conn.fetchval(
                "SELECT i.indisvalid FROM pg_index i JOIN pg_class c ON c.oid = i.indexrelid "
                "WHERE c.relname = $1",
                name,
            )
        if valid is False:
            logger.error(
                "Full-text index %s is INVALID (an earlier concurrent build was interrupted). "
                "Drop it with DROP INDEX CONCURRENTLY %s; it will be rebuilt on next start.",
                name,
                name,
            )
        else:
            logger.info("Full-text index %s is ready", name)
    except Exception as exc:
        logger.warning("Could not ensure full-text index %s: %s", name, exc)
