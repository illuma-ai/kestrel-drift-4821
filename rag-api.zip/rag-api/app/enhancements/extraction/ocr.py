"""OCR helpers (AWS Textract synchronous API).

Why a callable factory: loaders build the client once per document and pass a
plain ``bytes -> str`` callable around, so tests inject fakes and the layout
extractor stays independent of any provider.
"""

from __future__ import annotations

import io
import logging
from typing import Callable

from app.enhancements.config import make_aws_client

logger = logging.getLogger(__name__)

# Textract synchronous limits: 10MB and 10000px per side for PNG/JPEG bytes.
MAX_IMAGE_SIDE_PX = 10000
MAX_IMAGE_BYTES = 10 * 1024 * 1024
_DOWNSCALE_FACTOR = 0.8


def to_png_bytes(image_bytes: bytes) -> bytes:
    """Normalise any Pillow-readable image to an RGB PNG within Textract limits.

    Downscales when a side exceeds 10000px, then keeps shrinking until the
    encoded PNG is under 10MB.
    """
    from PIL import Image

    with Image.open(io.BytesIO(image_bytes)) as img:
        img = img.convert("RGB")
    longest = max(img.size)
    if longest > MAX_IMAGE_SIDE_PX:
        ratio = MAX_IMAGE_SIDE_PX / longest
        img = img.resize(
            (max(1, int(img.width * ratio)), max(1, int(img.height * ratio))),
            Image.LANCZOS,
        )
    while True:
        buf = io.BytesIO()
        img.save(buf, format="PNG", optimize=True)
        data = buf.getvalue()
        if len(data) < MAX_IMAGE_BYTES or min(img.size) <= 32:
            return data
        img = img.resize(
            (
                max(1, int(img.width * _DOWNSCALE_FACTOR)),
                max(1, int(img.height * _DOWNSCALE_FACTOR)),
            ),
            Image.LANCZOS,
        )


def build_textract_ocr() -> Callable[[bytes], str]:
    """Return ``ocr(png_or_image_bytes) -> text`` backed by Textract.

    The callable returns "" on any error so one bad page never fails a document.
    """
    client = make_aws_client("textract")

    def ocr(image_bytes: bytes) -> str:
        try:
            png = to_png_bytes(image_bytes)
            response = client.detect_document_text(Document={"Bytes": png})
            lines = [
                b for b in response.get("Blocks", []) if b.get("BlockType") == "LINE"
            ]
            lines.sort(
                key=lambda b: (
                    round(
                        b.get("Geometry", {}).get("BoundingBox", {}).get("Top", 0.0), 3
                    ),
                    b.get("Geometry", {}).get("BoundingBox", {}).get("Left", 0.0),
                )
            )
            return "\n".join(b.get("Text", "") for b in lines).strip()
        except Exception as exc:  # noqa: BLE001 - degrade, never fail the document
            logger.warning("OCR failed: %s", exc)
            return ""

    return ocr
