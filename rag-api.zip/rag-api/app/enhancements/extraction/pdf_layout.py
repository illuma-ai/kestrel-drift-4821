"""Layout-aware PDF -> per-page markdown.

Why not the stock page-text loader: it flattens tables into whitespace soup and
interleaves multi-column text line by line. Here each page is split into text
lines, tables and figures with positions, ordered column by column, and tables
are emitted as markdown so downstream chunking can keep rows together.

Only pdfplumber (text/tables) and pypdfium2 (rasterising) are used.
"""

from __future__ import annotations

import hashlib
import io
import logging
from dataclasses import dataclass
from typing import Callable, Optional

from app.enhancements.config import settings
from app.enhancements.extraction.ocr import to_png_bytes

logger = logging.getLogger(__name__)

PageOcr = Callable[[bytes], str]
FigureCaptioner = Callable[[bytes], str]

# An element wider than this fraction of the page is a "spanning" element
# (title, footer, wide table) and separates column regions vertically.
_SPAN_WIDTH_RATIO = 0.6
# A column band needs at least this many text lines to count as a column.
_MIN_COLUMN_LINES = 3
# Vertical gap (in line heights) above which a new paragraph starts.
_PARAGRAPH_GAP_RATIO = 0.6
# Horizontal gap (points) that separates two column bands.
_MIN_COLUMN_GUTTER = 12.0
# Words on one baseline further apart than this many line heights are split
# into separate lines (side-by-side columns).
_LINE_SPLIT_GAP_EM = 1.5


@dataclass
class PageResult:
    """Extraction result for one page (``page`` is a 0-based index)."""

    page: int
    markdown: str
    ocr_used: bool = False
    table_count: int = 0
    figure_count: int = 0


@dataclass
class _Element:
    kind: str  # "text" | "table" | "figure"
    x0: float
    x1: float
    top: float
    bottom: float
    text: str


def _escape_cell(value: object) -> str:
    text = str(value if value is not None else "")
    return text.replace("|", "\\|").replace("\r", " ").replace("\n", " ").strip()


def table_to_markdown(rows: list[list[object]]) -> str:
    """Serialise extracted table rows as a GitHub markdown table.

    The first non-empty row becomes the header. Returns "" for empty tables.
    """
    cleaned = [[_escape_cell(c) for c in row] for row in rows or []]
    cleaned = [r for r in cleaned if any(r)]
    if not cleaned:
        return ""
    width = max(len(r) for r in cleaned)
    cleaned = [r + [""] * (width - len(r)) for r in cleaned]
    lines = [
        "| " + " | ".join(cleaned[0]) + " |",
        "|" + "|".join([" --- "] * width) + "|",
    ]
    lines.extend("| " + " | ".join(r) + " |" for r in cleaned[1:])
    return "\n".join(lines)


def _merge_intervals(
    intervals: list[tuple[float, float]], gutter: float
) -> list[tuple[float, float]]:
    """Merge x-intervals that overlap or sit closer than ``gutter``."""
    merged: list[list[float]] = []
    for lo, hi in sorted(intervals):
        if merged and lo - merged[-1][1] < gutter:
            merged[-1][1] = max(merged[-1][1], hi)
        else:
            merged.append([lo, hi])
    return [(a, b) for a, b in merged]


def _column_bands(
    elements: list[_Element], page_width: float
) -> list[tuple[float, float]]:
    """Detect column x-bands from narrow text lines; ``[]`` means single column."""
    narrow = [
        e
        for e in elements
        if e.kind == "text" and (e.x1 - e.x0) < page_width * _SPAN_WIDTH_RATIO
    ]
    bands = _merge_intervals([(e.x0, e.x1) for e in narrow], _MIN_COLUMN_GUTTER)
    meaningful = [
        b
        for b in bands
        if sum(1 for e in narrow if b[0] <= (e.x0 + e.x1) / 2 <= b[1])
        >= _MIN_COLUMN_LINES
    ]
    return meaningful if len(meaningful) >= 2 else []


def _column_of(element: _Element, bands: list[tuple[float, float]]) -> int:
    centre = (element.x0 + element.x1) / 2
    for i, (lo, hi) in enumerate(bands):
        if lo <= centre <= hi:
            return i
    return min(
        range(len(bands)),
        key=lambda i: min(abs(centre - bands[i][0]), abs(centre - bands[i][1])),
    )


def _reading_order(elements: list[_Element], page_width: float) -> list[_Element]:
    """Order elements column by column; spanning elements split the page into regions."""
    bands = _column_bands(elements, page_width)
    by_position = sorted(elements, key=lambda e: (e.top, e.x0))
    if not bands:
        return by_position

    result: list[_Element] = []
    region: list[_Element] = []

    def flush() -> None:
        region.sort(key=lambda e: (_column_of(e, bands), e.top, e.x0))
        result.extend(region)
        region.clear()

    for e in by_position:
        if (e.x1 - e.x0) >= page_width * _SPAN_WIDTH_RATIO:
            flush()
            result.append(e)
        else:
            region.append(e)
    flush()
    return result


def _text_lines(page) -> list[dict]:
    """Build text lines from words, splitting a baseline at wide horizontal gaps.

    pdfplumber's own line grouping joins words that share a baseline, which
    glues side-by-side columns into one line; splitting on gaps keeps each
    column's text separate so reading order can be recovered.
    """
    words = page.extract_words(keep_blank_chars=False, use_text_flow=False)
    words.sort(key=lambda w: (w["top"], w["x0"]))
    rows: list[list[dict]] = []
    for w in words:
        height = max(w["bottom"] - w["top"], 1.0)
        if rows and abs(w["top"] - rows[-1][0]["top"]) < height * 0.5:
            rows[-1].append(w)
        else:
            rows.append([w])

    lines: list[dict] = []
    for row in rows:
        row.sort(key=lambda w: w["x0"])
        group = [row[0]]
        for w in row[1:]:
            gap = w["x0"] - group[-1]["x1"]
            height = max(w["bottom"] - w["top"], 1.0)
            if gap > max(_MIN_COLUMN_GUTTER, height * _LINE_SPLIT_GAP_EM):
                lines.append(_line_from_words(group))
                group = [w]
            else:
                group.append(w)
        lines.append(_line_from_words(group))
    return lines


def _line_from_words(words: list[dict]) -> dict:
    return {
        "text": " ".join(w["text"] for w in words).strip(),
        "x0": min(w["x0"] for w in words),
        "x1": max(w["x1"] for w in words),
        "top": min(w["top"] for w in words),
        "bottom": max(w["bottom"] for w in words),
    }


def _inside(top: float, bottom: float, x0: float, x1: float, bbox: tuple) -> bool:
    cx, cy = (x0 + x1) / 2, (top + bottom) / 2
    return bbox[0] <= cx <= bbox[2] and bbox[1] <= cy <= bbox[3]


def _render_page(pdfium_page, dpi: int):
    """Rasterise a pypdfium2 page to a PIL image."""
    return pdfium_page.render(scale=dpi / 72.0).to_pil()


def _png(pil_image) -> bytes:
    buf = io.BytesIO()
    pil_image.convert("RGB").save(buf, format="PNG")
    return buf.getvalue()


def _compose(ordered: list[_Element]) -> str:
    """Join ordered elements; consecutive text lines form paragraphs."""
    blocks: list[str] = []
    paragraph: list[str] = []
    prev: Optional[_Element] = None

    def close() -> None:
        if paragraph:
            blocks.append("\n".join(paragraph))
            paragraph.clear()

    for e in ordered:
        if e.kind != "text":
            close()
            blocks.append(e.text)
        else:
            if prev is not None and prev.kind == "text":
                height = max(prev.bottom - prev.top, 1.0)
                # e.top < prev.top means we jumped to the next column.
                if (
                    e.top - prev.bottom > height * _PARAGRAPH_GAP_RATIO
                    or e.top < prev.top
                ):
                    close()
            paragraph.append(e.text)
        prev = e
    close()
    return "\n\n".join(b for b in blocks if b.strip())


@dataclass
class _Figure:
    """A captionable figure: placement plus the cropped image to describe."""

    x0: float
    x1: float
    top: float
    bottom: float
    png: bytes
    digest: str


@dataclass
class _PagePlan:
    """Everything known about a page before any model call is made."""

    index: int
    width: float
    elements: list
    table_count: int
    ocr_png: Optional[bytes] = None
    figures: Optional[list] = None
    failed: bool = False


def _run_concurrently(jobs: dict, workers: int) -> dict:
    """Run independent ``key -> callable`` jobs in parallel; "" on any failure.

    PERF: OCR and caption calls are network-bound and independent, so running
    them sequentially made a 110-page upload with 17 such calls spend ~21 s
    waiting. The callables already degrade to "" on error; the extra guard
    keeps one misbehaving job from failing the document.
    """
    if not jobs:
        return {}
    from concurrent.futures import ThreadPoolExecutor

    def guarded(fn):
        try:
            return (fn() or "").strip()
        except Exception as exc:  # noqa: BLE001
            logger.warning("Extraction model call failed: %s", exc)
            return ""

    with ThreadPoolExecutor(max_workers=max(1, min(workers, len(jobs)))) as pool:
        futures = {key: pool.submit(guarded, fn) for key, fn in jobs.items()}
        return {key: future.result() for key, future in futures.items()}


def extract_pdf_pages(
    path: str,
    *,
    page_ocr: Optional[PageOcr] = None,
    figure_captioner: Optional[FigureCaptioner] = None,
) -> list[PageResult]:
    """Extract every page of a PDF as markdown.

    Three phases so model calls overlap instead of queueing:

    1. Parse every page and render what needs a model (sequential: the PDF
       renderer is not thread-safe).
    2. Send OCR for low-text pages and captions for distinct figures
       concurrently (``RAG_EXTRACTION_CONCURRENCY`` at a time). Figures on a
       low-text page are only captioned if OCR found no text there, matching
       the rule that an OCR'd page is represented by its transcription.
    3. Compose each page's markdown.

    Args:
        path: PDF file path.
        page_ocr: Optional ``png_bytes -> text``; used only for low-text pages.
        figure_captioner: Optional ``png_bytes -> caption``; called once per
            distinct figure image.

    Returns:
        One ``PageResult`` per page (including empty ones), 0-based ``page``.
    """
    import pdfplumber

    pdfium_doc = None
    if page_ocr is not None or figure_captioner is not None:
        import pypdfium2

        pdfium_doc = pypdfium2.PdfDocument(path)

    plans: list[_PagePlan] = []
    seen_digests: set = set()
    try:
        with pdfplumber.open(path) as pdf:
            for index, page in enumerate(pdf.pages):
                try:
                    plans.append(
                        _plan_page(
                            index,
                            page,
                            pdfium_doc,
                            page_ocr,
                            figure_captioner,
                            seen_digests,
                        )
                    )
                except (
                    Exception
                ) as exc:  # noqa: BLE001 - one bad page must not fail the document
                    logger.warning("Page %d extraction failed: %s", index, exc)
                    plans.append(_PagePlan(index, 0.0, [], 0, failed=True))
    finally:
        if pdfium_doc is not None:
            pdfium_doc.close()

    workers = settings.extraction_concurrency
    ocr_text = _run_concurrently(
        {p.index: (lambda png=p.ocr_png: page_ocr(png)) for p in plans if p.ocr_png},
        workers,
    )

    captions: dict = {}
    if figure_captioner is not None:
        pending = {}
        for p in plans:
            if p.ocr_png and ocr_text.get(p.index):
                continue  # page is represented by its OCR transcription
            for fig in p.figures or []:
                pending.setdefault(
                    fig.digest, lambda png=fig.png: figure_captioner(png)
                )
        captions = _run_concurrently(pending, workers)

    return [_compose_page(p, ocr_text.get(p.index, ""), captions) for p in plans]


def _plan_page(
    index: int, page, pdfium_doc, page_ocr, figure_captioner, seen_digests: set
) -> _PagePlan:
    page_w, page_h = float(page.width), float(page.height)
    elements: list[_Element] = []

    table_count = 0
    table_boxes = []
    for table in page.find_tables():
        md = table_to_markdown(table.extract())
        if md:
            x0, top, x1, bottom = table.bbox
            elements.append(_Element("table", x0, x1, top, bottom, md))
            table_boxes.append(table.bbox)
            table_count += 1

    for line in _text_lines(page):
        if any(
            _inside(line["top"], line["bottom"], line["x0"], line["x1"], b)
            for b in table_boxes
        ):
            continue
        elements.append(
            _Element(
                "text",
                line["x0"],
                line["x1"],
                line["top"],
                line["bottom"],
                line["text"],
            )
        )

    plan = _PagePlan(index, page_w, elements, table_count)
    if pdfium_doc is None:
        return plan

    rendered = None
    char_count = sum(len(e.text) for e in elements)
    if page_ocr is not None and char_count < settings.ocr_min_chars_per_page:
        rendered = _render_page(pdfium_doc[index], settings.ocr_render_dpi)
        plan.ocr_png = to_png_bytes(_png(rendered))

    if figure_captioner is not None:
        scale = settings.ocr_render_dpi / 72.0
        plan.figures = []
        for img in page.images:
            area = (img["x1"] - img["x0"]) * (img["bottom"] - img["top"])
            if area < page_w * page_h * settings.figure_min_area_ratio:
                continue
            if rendered is None:
                rendered = _render_page(pdfium_doc[index], settings.ocr_render_dpi)
            box = tuple(
                int(v * scale)
                for v in (
                    max(img["x0"], 0),
                    max(img["top"], 0),
                    min(img["x1"], page_w),
                    min(img["bottom"], page_h),
                )
            )
            if box[2] <= box[0] or box[3] <= box[1]:
                continue
            crop = _png(rendered.crop(box))
            digest = hashlib.sha256(crop).hexdigest()
            if digest in seen_digests:
                continue  # repeated logo/banner: caption (and emit) once per document
            seen_digests.add(digest)
            plan.figures.append(
                _Figure(img["x0"], img["x1"], img["top"], img["bottom"], crop, digest)
            )
    return plan


def _compose_page(plan: _PagePlan, ocr_text: str, captions: dict) -> PageResult:
    if plan.failed:
        return PageResult(page=plan.index, markdown="")

    ocr_used = bool(ocr_text)
    elements = list(plan.elements)
    figure_count = 0
    if not ocr_used:
        for fig in plan.figures or []:
            caption = captions.get(fig.digest, "")
            if caption:
                figure_count += 1
                elements.append(
                    _Element(
                        "figure",
                        fig.x0,
                        fig.x1,
                        fig.top,
                        fig.bottom,
                        f"**Figure:** {caption}",
                    )
                )

    if ocr_used:
        extras = [
            e.text
            for e in _reading_order(
                [e for e in elements if e.kind != "text"], plan.width
            )
        ]
        markdown = "\n\n".join([ocr_text] + extras)
    else:
        markdown = _compose(_reading_order(elements, plan.width))

    return PageResult(
        page=plan.index,
        markdown=markdown,
        ocr_used=ocr_used,
        table_count=plan.table_count,
        figure_count=figure_count,
    )
