"""Figure captioning through a Bedrock vision-capable model."""

from __future__ import annotations

import logging
from typing import Callable

from app.enhancements.config import make_aws_client
from app.enhancements.extraction.ocr import to_png_bytes

logger = logging.getLogger(__name__)

DECORATIVE_REPLY = "decorative image"

CAPTION_PROMPT = (
    "Describe this figure or chart in 2-3 sentences so it can be found by a text "
    "search. Include any data values, labels, axis names and units that are visible. "
    f"If the image carries no information (logo, border, decoration), reply exactly "
    f"'{DECORATIVE_REPLY}'."
)


def build_bedrock_captioner(model_id: str) -> Callable[[bytes], str]:
    """Return ``caption(image_bytes) -> text``; "" for decorative images or errors."""
    client = make_aws_client("bedrock-runtime")

    def caption(image_bytes: bytes) -> str:
        try:
            png = to_png_bytes(image_bytes)
            response = client.converse(
                modelId=model_id,
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {"image": {"format": "png", "source": {"bytes": png}}},
                            {"text": CAPTION_PROMPT},
                        ],
                    }
                ],
                inferenceConfig={"maxTokens": 300, "temperature": 0.0},
            )
            parts = response["output"]["message"]["content"]
            text = " ".join(p.get("text", "") for p in parts).strip()
            if not text or text.lower().strip(" .'\"") == DECORATIVE_REPLY:
                return ""
            return text
        except Exception as exc:  # noqa: BLE001 - degrade, never fail the document
            logger.warning("Figure captioning failed: %s", exc)
            return ""

    return caption
