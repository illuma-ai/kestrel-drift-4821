"""Loader selection for the enhanced extraction layer.

``get_enhanced_loader`` returns ``None`` whenever the stock loader should run,
so with default settings behaviour is identical to the unmodified service.
"""

from __future__ import annotations

import logging
import os
from typing import Iterator, Optional

from langchain_core.documents import Document

from app.enhancements.config import ExtractionMode, OcrProvider, settings
from app.enhancements.extraction.pdf_layout import extract_pdf_pages

logger = logging.getLogger(__name__)

IMAGE_EXTENSIONS = {"png", "jpg", "jpeg", "tif", "tiff", "bmp", "webp", "gif"}
OFFICE_EXTENSIONS = {"docx", "pptx", "xlsx"}
OFFICE_CONTENT_TYPES = {
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
}
FIGURE_PREFIX = "**Figure:**"


def _build_ocr():
    """OCR callable for the configured provider, or None."""
    if settings.ocr_provider == OcrProvider.TEXTRACT:
        from app.enhancements.extraction.ocr import build_textract_ocr

        return build_textract_ocr()
    return None


def _build_captioner():
    """Figure captioner when enabled, or None."""
    if settings.figure_captions:
        from app.enhancements.extraction.captioning import build_bedrock_captioner

        return build_bedrock_captioner(settings.vlm_model)
    return None


class _BaseLoader:
    """Shared loader surface: ``load()`` and the ``_temp_filepath`` cleanup hook."""

    # Stock cleanup code reads this attribute; ours never creates temp files.
    _temp_filepath = None

    def lazy_load(self) -> Iterator[Document]:  # pragma: no cover - abstract
        raise NotImplementedError

    def load(self) -> list[Document]:
        return list(self.lazy_load())


class StructuredPdfLoader(_BaseLoader):
    """One Document per non-empty page, layout-aware, optional OCR/captions."""

    def __init__(self, filepath: str):
        self.filepath = filepath
        # Built once per loader, not per page.
        self.page_ocr = _build_ocr()
        self.captioner = _build_captioner()

    def lazy_load(self) -> Iterator[Document]:
        pages = extract_pdf_pages(
            self.filepath, page_ocr=self.page_ocr, figure_captioner=self.captioner
        )
        total = len(pages)
        for result in pages:
            if not result.markdown.strip():
                continue
            metadata = {
                "source": self.filepath,
                "page": result.page,
                "total_pages": total,
            }
            if result.ocr_used:
                metadata["ocr"] = True
            yield Document(page_content=result.markdown, metadata=metadata)


class ImageLoader(_BaseLoader):
    """OCR text and/or figure caption for a standalone image upload."""

    def __init__(self, filepath: str):
        self.filepath = filepath
        self.page_ocr = _build_ocr()
        self.captioner = _build_captioner()

    def lazy_load(self) -> Iterator[Document]:
        with open(self.filepath, "rb") as f:
            data = f.read()
        parts: list[str] = []
        if self.page_ocr is not None:
            text = (self.page_ocr(data) or "").strip()
            if text:
                parts.append(text)
        if self.captioner is not None:
            caption = (self.captioner(data) or "").strip()
            if caption:
                parts.append(f"{FIGURE_PREFIX} {caption}")
        if parts:
            yield Document(
                page_content="\n\n".join(parts),
                metadata={"source": self.filepath, "page": 0},
            )


class MarkdownOfficeLoader(_BaseLoader):
    """docx/pptx/xlsx -> markdown (headings and tables preserved)."""

    def __init__(self, filepath: str):
        self.filepath = filepath

    def lazy_load(self) -> Iterator[Document]:
        from markitdown import MarkItDown

        text = MarkItDown(enable_plugins=False).convert(self.filepath).text_content
        if text and text.strip():
            yield Document(page_content=text, metadata={"source": self.filepath})


class RawMarkdownLoader(_BaseLoader):
    """Markdown verbatim, so headings survive for structure-aware chunking."""

    def __init__(self, filepath: str):
        self.filepath = filepath

    def lazy_load(self) -> Iterator[Document]:
        with open(self.filepath, "r", encoding="utf-8", errors="replace") as f:
            text = f.read()
        if text.strip():
            yield Document(page_content=text, metadata={"source": self.filepath})


def get_enhanced_loader(
    filename: str, content_type: str, filepath: str, raw_text: bool = False
) -> Optional[tuple]:
    """Pick an enhanced loader, or ``None`` to fall through to the stock one.

    Returns:
        ``(loader, known_type=True, file_ext)`` or ``None``.
    """
    file_ext = os.path.splitext(filename or "")[1].lstrip(".").lower()
    content_type = (content_type or "").lower()

    if (
        file_ext == "pdf" or content_type == "application/pdf"
    ) and settings.enhanced_extraction_enabled:
        return StructuredPdfLoader(filepath), True, file_ext or "pdf"

    if (file_ext in IMAGE_EXTENSIONS or content_type.startswith("image/")) and (
        settings.ocr_enabled or settings.figure_captions
    ):
        return ImageLoader(filepath), True, file_ext

    if settings.extraction == ExtractionMode.STRUCTURED:
        if file_ext in OFFICE_EXTENSIONS or content_type in OFFICE_CONTENT_TYPES:
            return MarkdownOfficeLoader(filepath), True, file_ext
        if file_ext == "md" and not raw_text:
            return RawMarkdownLoader(filepath), True, file_ext

    return None
