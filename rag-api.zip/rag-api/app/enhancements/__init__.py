"""Optional retrieval-quality enhancements.

Everything in this package is opt-in through environment variables (see
:mod:`app.enhancements.config`). With every flag at its default the service
behaves exactly like the stock pipeline: the hooks in the routes and loaders
fall straight through to the original code paths.

Kept as a separate package so the stock modules carry only a handful of
one-line hook points, which keeps future upstream pulls cheap.
"""
