---
description: Independent final verification — gates + acceptance + constitution + docs/code sweeps; verdict READY/NOT READY.
argument-hint: <feature-slug> (optional; defaults to most recent feature)
allowed-tools: Read, Glob, Grep, Bash
---

Independent adversarial pass for `specs/$ARGUMENTS/`. Read/run-only — report gaps,
don't fix. Paste real output for each:

1. **Gates** — `npm run lint`; `npm run build` (tsdown + tsc typecheck); `npm test`.
2. **Acceptance** — for every Given/When/Then in `spec.md`, show the proving jest
   spec. PASS/FAIL with evidence.
3. **Tasks** — every box `[x]`; flag any `[ ]`/`[~]`.
4. **Constitution (I–VI)** — re-check the diff: tests (II); **minimal upstream
   drift + brand-neutral (III)** — confirm no gratuitous reformat/refactor of
   untouched upstream code; SoT/functional-first/DRY (IV); docs+CHANGELOG with
   stale-doc sweep (V); public exports JSDoc'd (VI).
5. **Verdict:** READY / NOT READY with blocking gaps. If NOT READY → `/implement`.
