import { expect, test, describe } from '@jest/globals';
import type { ContentBlockDeltaEvent } from '@aws-sdk/client-bedrock-runtime';
import { handleConverseStreamContentBlockDelta } from './message_outputs';

/**
 * A REDACTED reasoning delta carries no text — only an opaque encrypted payload that
 * exists to be handed back to Bedrock on the next turn. Upstream copied that payload
 * into `additional_kwargs.reasoning_content` as a "we are reasoning" marker, and the
 * stream adapter surfaces `reasoning_content` verbatim as visible reasoning text. Every
 * model that reasons ONLY in redacted form (GPT-5.6 on Bedrock) therefore rendered a
 * wall of base64 ciphertext between tool steps, while Anthropic (text deltas) never did.
 */
describe('handleConverseStreamContentBlockDelta — redacted reasoning', () => {
  const redactedBytes = new Uint8Array(Buffer.from('rsn_opaque-envelope', 'utf8'));

  test('never surfaces the encrypted payload as reasoning text', () => {
    const chunk = handleConverseStreamContentBlockDelta({
      contentBlockIndex: 0,
      delta: { reasoningContent: { redactedContent: redactedBytes } },
    } as unknown as ContentBlockDeltaEvent);

    expect(chunk.message.additional_kwargs.reasoning_content).toBe('');
    expect(JSON.stringify(chunk.message.additional_kwargs)).not.toContain('rsn_');
  });

  test('still carries the payload in content so it round-trips to Bedrock', () => {
    const chunk = handleConverseStreamContentBlockDelta({
      contentBlockIndex: 0,
      delta: { reasoningContent: { redactedContent: redactedBytes } },
    } as unknown as ContentBlockDeltaEvent);

    const blocks = chunk.message.content as Array<Record<string, unknown>>;
    const block = blocks.find((b) => b.type === 'reasoning_content');
    expect(block).toBeDefined();
    expect(block?.redactedContent).toBe(Buffer.from(redactedBytes).toString('base64'));
  });

  test('a TEXT reasoning delta still exposes its text as reasoning_content', () => {
    const chunk = handleConverseStreamContentBlockDelta({
      contentBlockIndex: 0,
      delta: { reasoningContent: { text: 'Considering the slide layout.' } },
    } as unknown as ContentBlockDeltaEvent);

    expect(chunk.message.additional_kwargs.reasoning_content).toBe(
      'Considering the slide layout.'
    );
  });
});
