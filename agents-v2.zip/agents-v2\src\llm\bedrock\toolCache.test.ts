import { tool } from '@langchain/core/tools';
import type { Tool } from '@aws-sdk/client-bedrock-runtime';
import type { GraphTools } from '@/types';
import {
  insertBedrockToolCachePoint,
  partitionAndMarkBedrockToolCache,
} from './toolCache';

type OpenAITool = {
  type: 'function';
  function: {
    name: string;
    description?: string;
    parameters?: object;
  };
};

type CreateOpenAIToolOptions = {
  description?: string;
  omitDescription?: boolean;
};

function createOpenAITool(
  name: string,
  options: CreateOpenAIToolOptions = {}
): OpenAITool {
  const functionDefinition: OpenAITool['function'] = {
    name,
    parameters: {
      type: 'object',
      properties: {},
    },
  };
  const description = options.description ?? `${name} description`;
  if (options.omitDescription !== true) {
    functionDefinition.description = description;
  }

  return {
    type: 'function',
    function: functionDefinition,
  };
}

function toolName(entry: Tool): string {
  if ('cachePoint' in entry) {
    return 'cachePoint';
  }
  return entry.toolSpec?.name ?? 'missing';
}

function toolNames(tools: Tool[] | undefined): string[] {
  return (tools ?? []).map(toolName);
}

function getToolSpec(entry: Tool): Tool.ToolSpecMember['toolSpec'] {
  expect(entry).toHaveProperty('toolSpec');
  return (entry as Tool.ToolSpecMember).toolSpec;
}

describe('partitionAndMarkBedrockToolCache', () => {
  it('inserts the Bedrock cache point after the last static tool', () => {
    const tools = [
      createOpenAITool('static_one'),
      createOpenAITool('static_two'),
      createOpenAITool('dynamic_one'),
    ] as GraphTools;

    const marked = partitionAndMarkBedrockToolCache(
      tools,
      (name) => name === 'dynamic_one'
    ) as Tool[];
    const result = insertBedrockToolCachePoint({ tools: marked }, false);

    expect(toolNames(result?.tools)).toEqual([
      'static_one',
      'static_two',
      'cachePoint',
      'dynamic_one',
    ]);
    expect(JSON.stringify(result?.tools)).not.toContain(
      '__lc_bedrock_cache_point_after'
    );
  });

  it('converts LangChain tools to Bedrock tool specs before marking', () => {
    const staticTool = tool(async () => 'static', {
      name: 'static_tool',
      description: 'Static tool',
      schema: {
        type: 'object',
        properties: {},
      },
    });
    const dynamicTool = tool(async () => 'dynamic', {
      name: 'dynamic_tool',
      description: 'Dynamic tool',
      schema: {
        type: 'object',
        properties: {},
      },
    });

    const marked = partitionAndMarkBedrockToolCache(
      [dynamicTool, staticTool] as GraphTools,
      (name) => name === 'dynamic_tool'
    ) as Tool[];
    const result = insertBedrockToolCachePoint({ tools: marked }, false);

    expect(toolNames(result?.tools)).toEqual([
      'static_tool',
      'cachePoint',
      'dynamic_tool',
    ]);
  });

  it('does not add a cache point when every tool is deferred', () => {
    const tools = [createOpenAITool('dynamic_one')] as GraphTools;
    const marked = partitionAndMarkBedrockToolCache(
      tools,
      () => true
    ) as Tool[];
    const result = insertBedrockToolCachePoint({ tools: marked }, false);

    expect(toolNames(result?.tools)).toEqual(['dynamic_one']);
    expect(JSON.stringify(result?.tools)).not.toContain(
      '__lc_bedrock_skip_tool_cache'
    );
  });

  it('can fall back to caching all directly-bound tools', () => {
    const result = insertBedrockToolCachePoint(
      {
        tools: [
          {
            toolSpec: {
              name: 'direct_tool',
              description: 'Direct tool',
              inputSchema: { json: { type: 'object', properties: {} } },
            },
          },
        ],
      },
      true
    );

    expect(toolNames(result?.tools)).toEqual(['direct_tool', 'cachePoint']);
  });

  it('omits empty OpenAI tool descriptions when converting for Bedrock', () => {
    const tools = [
      createOpenAITool('missing_description', { omitDescription: true }),
      createOpenAITool('empty_description', { description: '' }),
      createOpenAITool('described_tool'),
    ] as GraphTools;

    const marked = partitionAndMarkBedrockToolCache(
      tools,
      () => false
    ) as Tool[];
    const result = insertBedrockToolCachePoint({ tools: marked }, false);
    const convertedTools = result?.tools ?? [];

    expect(getToolSpec(convertedTools[0])).not.toHaveProperty('description');
    expect(getToolSpec(convertedTools[1])).not.toHaveProperty('description');
    expect(getToolSpec(convertedTools[2]).description).toBe(
      'described_tool description'
    );
  });

  it('normalizes an existing tool cache point to the resolved 1h ttl', () => {
    const result = insertBedrockToolCachePoint(
      {
        tools: [
          {
            toolSpec: {
              name: 'direct_tool',
              description: 'Direct tool',
              inputSchema: { json: { type: 'object', properties: {} } },
            },
          },
          { cachePoint: { type: 'default' } },
        ] as Tool[],
      },
      false,
      '1h'
    );
    const cachePoints = (result?.tools ?? []).filter(
      (t): t is Tool.CachePointMember => 'cachePoint' in t
    );
    expect(cachePoints).toHaveLength(1);
    expect(cachePoints[0].cachePoint).toEqual({ type: 'default', ttl: '1h' });
  });
});
