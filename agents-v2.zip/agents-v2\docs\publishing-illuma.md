# Publishing this fork as `@illuma-ai/agents`

This repository is a fork of the upstream agent runtime. Its tracked `package.json` keeps
**upstream's name and version** on purpose: every upstream pull then merges cleanly on
identity, and the fork's deltas live in code, not in metadata.

The platform consumes the fork under its own name, `@illuma-ai/agents`, through an npm alias
on the host side (`"@librechat/agents": "npm:@illuma-ai/agents@<version>"`), so the host's
source never changes an import to consume the fork.

## The platform's own version line

`illuma.version.json` (fork-owned — an upstream merge never touches it):

```json
{ "name": "@illuma-ai/agents", "version": "4.0.0", "upstream": "3.8.4" }
```

The version is the platform's semver, not upstream's. `upstream` records which upstream
release the build carries — traceability, not identity. The published manifest also carries
`illuma: { base, commit }`.

| Event                                   | Bump    | Example       |
| --------------------------------------- | ------- | ------------- |
| an upstream merge lands                 | `minor` | 4.0.0 → 4.1.0 |
| a fork-only fix on the same upstream    | `patch` | 4.1.0 → 4.1.1 |
| a breaking change in the fork's own API | `major` | 4.1.1 → 5.0.0 |

`4.0.0` is the first version on this line: it clears the legacy `2.1.1` that was on the
package before, and it is above upstream's 3.x so it can never be mistaken for a registry build.

## Steps

```bash
# 1. merge upstream, keep the fork deltas, run the suite (diff the failing SET against the pre-merge tag)
npx jest --coverage=false

# 2. see what would publish (after an upstream merge, bump minor)
node scripts/publish-illuma.mjs --dry-run --bump minor

# 3. publish (auth via .npmrc -> ${NPM_TOKEN}; prepublishOnly rebuilds dist)
NPM_TOKEN=<token> node scripts/publish-illuma.mjs --bump minor

# 4. in the host repo, point the alias at the new version and install it
npm run agents:version -- 4.1.0 --install
```

The script commits `illuma.version.json` when it bumps, rewrites `package.json` only for the
duration of `npm publish`, restores it, and tags the commit `illuma/v<version>`. It refuses to
run when `upstream` in the version file does not match `package.json` (upstream merged, version
not bumped), when the version is already on the registry, and on a dirty tree.

## What must stay true

- Every fork delta the host depends on has an entry in the host's installed-bundle guard
  (`packages/api/src/agents/__tests__/agentsLibraryForkDeltas.spec.ts`). A registry build of
  upstream's package fails it; the published fork build passes it.
- `.npmrc` uses `${NPM_TOKEN}` — never a stored token.
