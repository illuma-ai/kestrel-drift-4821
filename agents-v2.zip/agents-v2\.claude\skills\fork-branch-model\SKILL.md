---
name: fork-branch-model
description: >-
  Two-branch model and upstream-integration workflow for this agents library (a
  fork of upstream @librechat/agents). Use when creating a branch, starting a
  feature, merging or pulling upstream changes, resolving upstream merge
  conflicts, cutting a release, or reasoning about which branch owns what.
  develop = fork-owned default; main = pristine upstream mirror; releases = tags.
---

# Fork branch model (agents-v2)

This repo (`illuma-ai/agents-v2`, package `@librechat/agents`) is a fork of upstream
`danny-avila/agents`. It keeps **exactly two long-lived branches**. Do not create a
third long-lived branch; feature branches are short-lived and merge back into
`develop`.

## The two branches

| Branch | Owner | Rule |
|---|---|---|
| **`develop`** | fork (illuma-ai) | **Default branch.** All fork work lands here. It equals `main` + the fork deltas. Build, run, and PR against this. |
| **`main`** | upstream mirror | **Pristine mirror of `upstream/main`.** NEVER commit fork code here. It exists so upstream lands cleanly and `git diff main develop` is the exact fork delta. |

Remotes: `origin` = illuma-ai/agents-v2 (fork) · `upstream` = danny-avila/agents.

**Releases are git tags / npm publish, not a branch.** There is deliberately no
"stable fork" branch — a published version is a tag on `develop`. (If this repo ever
becomes consumed by a build that tracks `main` as a branch instead of via npm, revisit
this decision — until then, mirror model wins because it keeps drift continuously
auditable on our own remote.)

## Feature work

```
git checkout develop && git pull
git checkout -b feat/<slug>        # short-lived, off develop
# ...work, keep the gate green...
# PR feat/<slug> -> develop   (never -> main)
```
Delete the feature branch after merge. Transient `merge/upstream-*` branches are also
deleted once merged into `develop` — they are not kept.

## Integrate upstream (the only way upstream enters)

The chain is `upstream/main` → `main` → `develop`. `main` relays upstream; it is not a
source of fork code.

```
git fetch upstream --prune
git checkout main
git reset --hard upstream/main                 # main is a mirror: reset, don't merge
git push --force-with-lease origin main        # force is expected here — history follows upstream
git checkout develop
git merge main                                 # conflicts surface HERE
# resolve, DEFENDING the fork deltas (below); then re-green the gate
npm run lint && npm run build && npm test
```

Notes:
- Conflict work is identical regardless of what `main` is — upstream code always
  collides with fork code at the **merge into `develop`**. The mirror adds no extra
  conflict burden.
- Never `git merge upstream/main` directly into `develop` and never open a PR into
  `main`. Upstream always transits `main` first (keeps the mirror honest).
- After resolving, per repo policy re-green every test the merge touched (including
  inherited upstream tests) as part of the merge, not a follow-up.

## The fork deltas to defend during conflict resolution

`git diff main develop` is authoritative; as of the 2026-07-14 migration the fork delta
was ~16 commits, clustering in known areas:
- shared code-exec sandbox session + image-vision content blocks
- Windows-safe tsdown `neverBundle` build config
- the `.claude/` spec-kit workflow + manual-only CI (`workflow_dispatch`)
- two HITL resume fixes (step-tracking rehydrate on resume; gate ON_RUN_STEP
  re-dispatch to pending tool_calls)

When a conflict lands in these files, keep the fork side's behavior and re-apply the
upstream change around it — do not drop the delta to take upstream wholesale.

## Guardrails

- Local `main` pushes to `origin/main` but is only ever updated **from** `upstream/main`
  (reset, never hand-edited).
- `git diff main develop` must only ever show intended fork deltas. If it shows
  something unexpected, a stray commit leaked onto `main` — fix before merging.
- Do not add repo-specific/fork code to `main` to "fix" a build — that belongs on
  `develop`.
