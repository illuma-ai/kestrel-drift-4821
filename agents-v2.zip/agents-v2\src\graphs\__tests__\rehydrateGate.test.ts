/**
 * NOTE: the whole `src/graphs/__tests__` suite currently fails to RUN under jest due
 * to pre-existing ESM-transform debt — importing `../Graph` pulls in
 * `@langchain/mistralai` → `@mistralai/mistralai` (ESM `export`), which jest does not
 * transform (no `transformIgnorePatterns` allow-list). That is a separate infra fix.
 * This spec is written correctly and executes once that debt is resolved; the gate it
 * pins was verified end-to-end live (both HITL paths, 0 `duplicate Ids` in backend logs).
 */
import { describe, it, expect, jest } from '@jest/globals';
import { ContentTypes, GraphEvents } from '@/common';
import { StandardGraph } from '../Graph';

/**
 * Regression: rehydrateFromContentParts must re-dispatch ON_RUN_STEP ONLY for a
 * tool_call still PENDING at resume (no output). A tool_call that already completed
 * before the pause (e.g. an answered ask_user_question in a multi-question turn —
 * upstream's checkpointer already restores it) must NOT be re-dispatched, or the
 * rebuilt assistant message carries the SAME tool_use id twice and the provider
 * rejects the next turn ("toolUse blocks contain duplicate Ids"). All parts are
 * still seeded into toolCallStepIds for content ordering / resumed-stream continuity.
 *
 * Built on a prototype-only instance so the test exercises the exact method without
 * standing up a full graph (model/tools/agents) it does not touch.
 */
function makeGraph() {
  const g = Object.create(StandardGraph.prototype) as StandardGraph;
  const handle = jest.fn(
    (..._args: unknown[]): Promise<undefined> => Promise.resolve(undefined)
  );
  Object.assign(g, {
    contentData: [],
    stepKeyIds: new Map<string, string[]>(),
    contentIndexMap: new Map<string, number>(),
    toolCallStepIds: new Map<string, string>(),
    handlerDispatchedStepIds: new Set<string>(),
    runId: 'run_1',
    handlerRegistry: {
      getHandler: (event: string) =>
        event === GraphEvents.ON_RUN_STEP ? { handle } : undefined,
    },
  });
  return { g, handle };
}

describe('StandardGraph.rehydrateFromContentParts — re-dispatch gate', () => {
  it('re-dispatches ON_RUN_STEP only for pending tool_calls, seeds toolCallStepIds for all', async () => {
    const { g, handle } = makeGraph();
    const seed = [
      // Already completed (has output) — upstream restores it; must NOT re-dispatch.
      {
        type: ContentTypes.TOOL_CALL,
        tool_call: {
          id: 'answered_q1',
          name: 'ask_user_question',
          args: '{}',
          output: 'Blue',
        },
      },
      // Pending (no output) — the paused approval tool; MUST re-dispatch so its
      // completion binds output instead of dropping to "Cancelled".
      {
        type: ContentTypes.TOOL_CALL,
        tool_call: {
          id: 'pending_mcp',
          name: 'search_mcp_deepwiki',
          args: '{}',
        },
      },
    ];

    await g.rehydrateFromContentParts(seed);

    // Ordering seed happens for BOTH parts.
    expect(g.toolCallStepIds.has('answered_q1')).toBe(true);
    expect(g.toolCallStepIds.has('pending_mcp')).toBe(true);

    // Re-dispatch fires exactly once — for the pending tool only.
    expect(handle).toHaveBeenCalledTimes(1);
    const dispatchedStep = handle.mock.calls[0][1] as { id: string };
    expect(dispatchedStep.id).toBe(g.toolCallStepIds.get('pending_mcp')!);
    expect(
      g.handlerDispatchedStepIds.has(g.toolCallStepIds.get('pending_mcp')!)
    ).toBe(true);
    // The completed part's step was NOT re-dispatched (no duplicate tool_use id).
    expect(
      g.handlerDispatchedStepIds.has(g.toolCallStepIds.get('answered_q1')!)
    ).toBe(false);
  });

  it('treats empty-string output as pending (re-dispatches)', async () => {
    const { g, handle } = makeGraph();
    await g.rehydrateFromContentParts([
      {
        type: ContentTypes.TOOL_CALL,
        tool_call: { id: 'p', name: 't', args: '{}', output: '' },
      },
    ]);
    expect(handle).toHaveBeenCalledTimes(1);
  });

  it('no-ops on an empty seed', async () => {
    const { g, handle } = makeGraph();
    await g.rehydrateFromContentParts([]);
    expect(handle).not.toHaveBeenCalled();
    expect(g.toolCallStepIds.size).toBe(0);
  });
});
