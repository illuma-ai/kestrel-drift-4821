import { describe, it, expect } from '@jest/globals';
import { CODE_EXECUTION_TOOLS, Constants } from '@/common';

/**
 * Session-sharing guard (illuma delta).
 *
 * File-authoring/read tools MUST be members of `CODE_EXECUTION_TOOLS` so
 * `ToolNode` threads the shared sandbox `session_id` through them. Without it a
 * `create_file` writes its script into an orphan sandbox and the following
 * `bash`/`node` run (a fresh sandbox) can't find it — the multi-step
 * "No such file" retry loop that breaks Excel/Word/PowerPoint skills.
 *
 * This test fails loudly if a future upstream merge drops them from the set.
 */
describe('CODE_EXECUTION_TOOLS — shared sandbox session membership', () => {
  it('includes the file-authoring/read tools that must share the session', () => {
    expect(CODE_EXECUTION_TOOLS.has(Constants.READ_FILE)).toBe(true);
    expect(CODE_EXECUTION_TOOLS.has(Constants.EDIT_FILE)).toBe(true);
    expect(CODE_EXECUTION_TOOLS.has('create_file')).toBe(true);
  });

  it('still includes the base code-execution tools', () => {
    expect(CODE_EXECUTION_TOOLS.has(Constants.EXECUTE_CODE)).toBe(true);
    expect(CODE_EXECUTION_TOOLS.has(Constants.BASH_TOOL)).toBe(true);
  });
});
