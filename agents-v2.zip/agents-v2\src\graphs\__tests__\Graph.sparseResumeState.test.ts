import { describe, it, expect } from '@jest/globals';
import { StandardGraph } from '../Graph';
import { Providers } from '@/common';
import type * as t from '@/types';

/**
 * `rehydrateFromContentParts` seeds a SPARSE `contentData` when it restores a
 * pre-pause content-part array — the indices it does not own are left as holes.
 * `getRunSteps` and `getRunStepsByAgent` both guard for that;
 * `createRunStepResumeState` did not, and `for...of` yields `undefined` for each
 * hole, so reading `.status` threw
 * `TypeError: Cannot read properties of undefined (reading 'status')`.
 *
 * Live impact: it failed the resume of a MULTI-question `ask_user_question`
 * batch every time ("An error occurred while resuming the request"). A single
 * question leaves no hole and resumed fine, which is why it survived earlier
 * verification.
 */
const makeGraph = (): StandardGraph =>
  new StandardGraph({
    runId: 'sparse-resume',
    agents: [
      {
        agentId: 'primary',
        provider: Providers.OPENAI,
        instructions: 'Sparse contentData resume state.',
      },
    ],
  });

const openStep = (id: string): t.RunStep =>
  ({ id, agentId: 'primary', index: 0, type: 'tool_calls' }) as unknown as t.RunStep;

describe('createRunStepResumeState with a sparse contentData', () => {
  it('skips holes instead of throwing on undefined.status', () => {
    const graph = makeGraph();
    /* Exactly the shape a seeded pre-pause array has: real steps around holes. */
    const sparse: t.RunStep[] = [];
    sparse[0] = openStep('step_a');
    sparse[3] = openStep('step_b');
    graph.contentData = sparse;

    expect(() => graph.createRunStepResumeState()).not.toThrow();

    const state = graph.createRunStepResumeState();
    /* Both real steps survive; neither hole becomes an entry. */
    expect(state.steps).toHaveLength(2);
    expect(state.steps.map((entry) => entry.step.id)).toEqual(['step_a', 'step_b']);
  });

  it('still drops steps that already closed', () => {
    const graph = makeGraph();
    const closed = openStep('step_closed');
    (closed as { status?: string }).status = 'completed';
    const sparse: t.RunStep[] = [];
    sparse[1] = closed;
    sparse[4] = openStep('step_open');
    graph.contentData = sparse;

    const state = graph.createRunStepResumeState();
    expect(state.steps.map((entry) => entry.step.id)).toEqual(['step_open']);
  });
});
