import { AIMessage, HumanMessage, ToolMessage } from '@langchain/core/messages';
import type { BaseMessage } from '@langchain/core/messages';
import type { TokenCounter } from '@/types/run';
import {
  maskConsumedToolResults,
  ORIGINAL_CONTENT_MAX_CHARS,
} from '@/messages/prune';

const charCounter: TokenCounter = (msg) => {
  const raw = msg.content;
  if (typeof raw === 'string') return raw.length;
  return JSON.stringify(raw).length;
};

function toolMsg(
  content: string,
  name = 'tool',
  toolCallId = `tc_${Math.random().toString(36).slice(2, 8)}`
): ToolMessage {
  return new ToolMessage({ content, tool_call_id: toolCallId, name });
}

function aiWithText(text: string): AIMessage {
  return new AIMessage(text);
}

function aiToolCall(toolCallId: string, name = 'tool'): AIMessage {
  return new AIMessage({
    content: [{ type: 'tool_use', id: toolCallId, name, input: {} }],
    tool_calls: [{ id: toolCallId, name, args: {}, type: 'tool_call' }],
  });
}

describe('maskConsumedToolResults', () => {
  it('masks consumed tool results (followed by AI with text)', () => {
    const tcId = 'tc_1';
    const messages: BaseMessage[] = [
      new HumanMessage('hello'),
      aiToolCall(tcId, 'search'),
      toolMsg('A'.repeat(1000), 'search', tcId),
      aiWithText('Based on the search results, here is the answer.'),
    ];
    const map: Record<string, number | undefined> = {
      0: 5,
      1: 20,
      2: 1000,
      3: 50,
    };

    const count = maskConsumedToolResults({
      messages,
      indexTokenCountMap: map,
      tokenCounter: charCounter,
    });

    expect(count).toBe(1);
    const maskedContent = messages[2].content as string;
    expect(maskedContent.length).toBeLessThan(1000);
    expect(maskedContent.length).toBeLessThanOrEqual(300);
  });

  it('does NOT mask unconsumed tool results (no subsequent AI text)', () => {
    const tcId = 'tc_1';
    const messages: BaseMessage[] = [
      new HumanMessage('hello'),
      aiToolCall(tcId, 'search'),
      toolMsg('A'.repeat(1000), 'search', tcId),
    ];
    const map: Record<string, number | undefined> = {
      0: 5,
      1: 20,
      2: 1000,
    };

    const count = maskConsumedToolResults({
      messages,
      indexTokenCountMap: map,
      tokenCounter: charCounter,
    });

    expect(count).toBe(0);
    expect((messages[2].content as string).length).toBe(1000);
  });

  it('does NOT mask tool results followed by AI with only tool calls (no text)', () => {
    const tcId1 = 'tc_1';
    const tcId2 = 'tc_2';
    const messages: BaseMessage[] = [
      new HumanMessage('hello'),
      aiToolCall(tcId1, 'search'),
      toolMsg('A'.repeat(1000), 'search', tcId1),
      aiToolCall(tcId2, 'fetch'),
      toolMsg('B'.repeat(500), 'fetch', tcId2),
    ];
    const map: Record<string, number | undefined> = {
      0: 5,
      1: 20,
      2: 1000,
      3: 20,
      4: 500,
    };

    const count = maskConsumedToolResults({
      messages,
      indexTokenCountMap: map,
      tokenCounter: charCounter,
    });

    // No AI message with substantive text exists, so nothing is consumed
    expect(count).toBe(0);
  });

  it('masks multiple consumed results before a text AI response', () => {
    const tcId1 = 'tc_1';
    const tcId2 = 'tc_2';
    const messages: BaseMessage[] = [
      new HumanMessage('hello'),
      aiToolCall(tcId1, 'search'),
      toolMsg('A'.repeat(1000), 'search', tcId1),
      aiToolCall(tcId2, 'fetch'),
      toolMsg('B'.repeat(800), 'fetch', tcId2),
      aiWithText('Here are the combined results.'),
    ];
    const map: Record<string, number | undefined> = {
      0: 5,
      1: 20,
      2: 1000,
      3: 20,
      4: 800,
      5: 30,
    };

    const count = maskConsumedToolResults({
      messages,
      indexTokenCountMap: map,
      tokenCounter: charCounter,
    });

    expect(count).toBe(2);
    expect((messages[2].content as string).length).toBeLessThanOrEqual(300);
    expect((messages[4].content as string).length).toBeLessThanOrEqual(300);
  });

  it('never masks AI messages', () => {
    const messages: BaseMessage[] = [
      new HumanMessage('hello'),
      aiWithText('A'.repeat(2000)),
    ];
    const map: Record<string, number | undefined> = {
      0: 5,
      1: 2000,
    };

    const count = maskConsumedToolResults({
      messages,
      indexTokenCountMap: map,
      tokenCounter: charCounter,
    });

    expect(count).toBe(0);
    expect((messages[1].content as string).length).toBe(2000);
  });

  it('skips short tool results below maxChars threshold', () => {
    const tcId = 'tc_1';
    const messages: BaseMessage[] = [
      new HumanMessage('hello'),
      aiToolCall(tcId, 'search'),
      toolMsg('short result', 'search', tcId),
      aiWithText('Got it.'),
    ];
    const map: Record<string, number | undefined> = {
      0: 5,
      1: 20,
      2: 12,
      3: 7,
    };

    const count = maskConsumedToolResults({
      messages,
      indexTokenCountMap: map,
      tokenCounter: charCounter,
    });

    expect(count).toBe(0);
    expect(messages[2].content).toBe('short result');
  });

  it('updates indexTokenCountMap for masked messages', () => {
    const tcId = 'tc_1';
    const messages: BaseMessage[] = [
      new HumanMessage('hello'),
      aiToolCall(tcId, 'search'),
      toolMsg('A'.repeat(2000), 'search', tcId),
      aiWithText('Summary of results.'),
    ];
    const map: Record<string, number | undefined> = {
      0: 5,
      1: 20,
      2: 2000,
      3: 20,
    };

    maskConsumedToolResults({
      messages,
      indexTokenCountMap: map,
      tokenCounter: charCounter,
    });

    // Token count should be updated to match the masked content length
    expect(map[2]).toBeLessThan(2000);
    expect(map[2]).toBe((messages[2].content as string).length);
  });

  it('masks consumed structured tool results with a bounded text preview', () => {
    const tcId = 'tc-structured';
    const toolMessage = new ToolMessage({
      content: [
        {
          type: 'json',
          rows: Array.from({ length: 20 }, (_, index) => ({
            id: index,
            value: `${'x'.repeat(100)}-${index}`,
          })),
        },
      ],
      tool_call_id: tcId,
      name: 'run_select_query',
      status: 'success',
      artifact: { source: 'clickhouse' },
    });
    const messages: BaseMessage[] = [
      new HumanMessage('query the table'),
      aiToolCall(tcId, 'run_select_query'),
      toolMessage,
      aiWithText('The query returned 20 rows.'),
    ];
    const map: Record<string, number | undefined> = {
      0: 5,
      1: 20,
      2: 0,
      3: 30,
    };
    const originalContentStore = new Map<number, string>();
    const originalContent = JSON.stringify(toolMessage.content);

    const count = maskConsumedToolResults({
      messages,
      indexTokenCountMap: map,
      tokenCounter: charCounter,
      originalContentStore,
    });

    expect(count).toBe(1);
    expect(typeof messages[2].content).toBe('string');
    expect(messages[2].content).toContain('truncated');
    expect((messages[2].content as string).length).toBeLessThanOrEqual(300);
    const masked = messages[2] as ToolMessage;
    expect(masked.tool_call_id).toBe(tcId);
    expect(masked.name).toBe('run_select_query');
    expect(masked.status).toBe('success');
    expect(masked.artifact).toEqual({ source: 'clickhouse' });
    expect(map[2]).toBe(charCounter(masked));
    expect(originalContentStore.get(2)).toBe(originalContent);
  });

  it('bounds stored structured originals without invoking custom toJSON', () => {
    const tcId = 'tc-large-structured';
    const toJSON = jest.fn(() => ({ expanded: 'should not run' }));
    const messages: BaseMessage[] = [
      new HumanMessage('query the table'),
      aiToolCall(tcId, 'run_select_query'),
      new ToolMessage({
        content: [
          {
            type: 'json',
            payload: 'x'.repeat(ORIGINAL_CONTENT_MAX_CHARS + 1_000),
            toJSON,
          },
        ],
        tool_call_id: tcId,
        name: 'run_select_query',
      }),
      aiWithText('The query completed.'),
    ];
    const originalContentStore = new Map<number, string>();

    const count = maskConsumedToolResults({
      messages,
      indexTokenCountMap: { 0: 1, 1: 1, 2: 1, 3: 1 },
      tokenCounter: () => 1,
      originalContentStore,
    });

    expect(count).toBe(1);
    expect(toJSON).not.toHaveBeenCalled();
    expect(originalContentStore.get(2)?.length).toBeLessThanOrEqual(
      ORIGINAL_CONTENT_MAX_CHARS
    );
    expect(originalContentStore.get(2)).toContain('truncated');
  });

  it('preserves the legacy aggregate masking budget', () => {
    const messages: BaseMessage[] = [
      new HumanMessage('hello'),
      aiToolCall('tc_old'),
      toolMsg('A'.repeat(5_000), 'tool', 'tc_old'),
      aiToolCall('tc_new'),
      toolMsg('B'.repeat(5_000), 'tool', 'tc_new'),
      aiWithText('done'),
    ];

    const count = maskConsumedToolResults({
      messages,
      indexTokenCountMap: {},
      tokenCounter: charCounter,
      availableRawBudget: 500,
    });

    expect(count).toBe(2);
    expect((messages[2].content as string).length).toBeLessThanOrEqual(350);
    expect((messages[4].content as string).length).toBeGreaterThan(1_000);
  });

  it('handles empty messages array', () => {
    const map: Record<string, number | undefined> = {};
    const count = maskConsumedToolResults({
      messages: [],
      indexTokenCountMap: map,
      tokenCounter: charCounter,
    });
    expect(count).toBe(0);
  });
});

describe('consumed image pruning (fork delta)', () => {
  const IMG_URL = 'data:image/png;base64,AAAA';

  function imageToolMsg(toolCallId: string, label: string): ToolMessage {
    return new ToolMessage({
      content: [
        { type: 'text', text: `Image: ${label}` },
        { type: 'image_url', image_url: { url: IMG_URL } },
      ],
      tool_call_id: toolCallId,
      name: 'read_file',
    });
  }

  function hasImageBlock(content: unknown): boolean {
    return (
      Array.isArray(content) &&
      content.some(
        (b) => (b as Record<string, unknown>).type === 'image_url'
      )
    );
  }

  function buildQaLoop(imageCount: number): {
    messages: BaseMessage[];
    map: Record<string, number | undefined>;
    imageIndices: number[];
  } {
    const messages: BaseMessage[] = [new HumanMessage('run the QA loop')];
    const map: Record<string, number | undefined> = { 0: 5 };
    const imageIndices: number[] = [];
    for (let n = 0; n < imageCount; n++) {
      const tcId = `tc_img_${n}`;
      messages.push(aiToolCall(tcId, 'read_file'));
      map[messages.length - 1] = 20;
      messages.push(imageToolMsg(tcId, `page-${n}.png`));
      imageIndices.push(messages.length - 1);
      map[messages.length - 1] = 1200;
      messages.push(aiWithText(`Reviewed page ${n}, looks fine.`));
      map[messages.length - 1] = 20;
    }
    return { messages, map, imageIndices };
  }

  it('strips images from consumed image results beyond the newest retained ones', () => {
    const { messages, map, imageIndices } = buildQaLoop(5);
    const count = maskConsumedToolResults({
      messages,
      indexTokenCountMap: map,
      tokenCounter: charCounter,
    });

    expect(count).toBeGreaterThanOrEqual(3);
    // Oldest three lose their image; the newest two consumed keep theirs.
    for (const i of imageIndices.slice(0, 3)) {
      expect(hasImageBlock(messages[i].content)).toBe(false);
      expect(JSON.stringify(messages[i].content)).toContain('[image removed');
    }
    for (const i of imageIndices.slice(-2)) {
      expect(hasImageBlock(messages[i].content)).toBe(true);
    }
  });

  it('never strips an UNCONSUMED image result', () => {
    const { messages, map } = buildQaLoop(3);
    // Append an unconsumed image read (no AI text after it).
    const tcId = 'tc_img_last';
    messages.push(aiToolCall(tcId, 'read_file'));
    map[messages.length - 1] = 20;
    messages.push(imageToolMsg(tcId, 'latest.png'));
    const lastIndex = messages.length - 1;
    map[lastIndex] = 1200;

    maskConsumedToolResults({
      messages,
      indexTokenCountMap: map,
      tokenCounter: charCounter,
    });

    expect(hasImageBlock(messages[lastIndex].content)).toBe(true);
  });
});
