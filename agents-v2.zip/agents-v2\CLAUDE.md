See [AGENTS.md](./AGENTS.md) for all project instructions, code style, and development guidelines.

## Branch model (two branches only)

This fork keeps exactly two long-lived branches:

- **`develop`** — the **fork-owned default branch**. All fork work lands here; it
  is `main` + the fork deltas. Branch feature work off `develop` and PR back into
  it. This is the branch to check out and build against.
- **`main`** — a **pristine mirror of upstream `@librechat/agents`** (`upstream/main`).
  **Never commit fork code to `main`.** It exists so upstream lands cleanly and so
  `git diff main develop` is always the exact fork delta.

Update flow (integrate upstream):
```
git fetch upstream --prune
git checkout main && git reset --hard upstream/main && git push --force-with-lease origin main
git checkout develop && git merge main        # resolve, keeping fork deltas
```
`main` pulls upstream directly; `develop` receives upstream by merging `main` in.
Do not open PRs into `main`. Delete transient `merge/upstream-*` branches once merged
into `develop` — they are not kept.

## Spec-driven workflow (fork-aware)

Non-trivial changes flow through a gated, step-verified workflow so nothing is
skipped or hallucinated and deltas stay surgical (this is a fork of upstream
`@librechat/agents` — keep it cleanly pullable):
`/specify`→`/clarify`→`/plan`→`/tasks`→`/implement`→`/converge`→`/verify`
(Claude Code commands in `.claude/commands/`) + the `verified-development` skill,
governed by `.specify/memory/constitution.md` (principles I–VI) and
`docs/coding-standards.md`. **Right-size it:** trivial = gate + CHANGELOG only;
small = spec + tasks; substantial (or anything widening upstream drift) = full
pipeline. Gate = `npm run lint` + `npm run build` + `npm test`. CI + publish are
**manual-only** (`workflow_dispatch`). Full guide: `docs/development-workflow.md`.
