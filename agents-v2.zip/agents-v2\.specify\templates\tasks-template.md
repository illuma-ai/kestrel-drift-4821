# Tasks: <FEATURE NAME>

> Produced by `/tasks`. `/implement` checks a box `[x]` only after its
> verification passes. No box on assumption; never batch-check.

## Linked plan

`specs/<feature-slug>/plan.md`

## Tests first

- [ ] T010 — jest spec for <FR-1> · verify: `npm test` (RED first)

## Implementation

- [ ] T020 — <smallest change> · verify: T010 green
- [ ] T028 — SoT/DRY: reuse `common/*` + `types/*`, functional-first, delete
      redundant, keep upstream delta surgical · verify: `npm run build`
- [ ] T029 — JSDoc public exports + why-comments (Principle VI) · verify: review

## Docs & changelog

- [ ] T040 — update `AGENTS.md`/`docs/*` for the change
- [ ] T041 — `CHANGELOG.md` `[Unreleased]` entry (record the upstream delta)
- [ ] T042 — stale-doc sweep: nothing describes removed/renamed behaviour

## Final gate

- [ ] G1 — `npm run lint` clean
- [ ] G2 — `npm run build` (tsdown + tsc typecheck) clean
- [ ] G3 — `npm test` green
- [ ] G4 — acceptance criteria demonstrated
- [ ] G5 — Constitution I–VI re-checked; drift minimal
