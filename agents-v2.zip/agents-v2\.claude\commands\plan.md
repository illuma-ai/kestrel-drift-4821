---
description: Produce a technical plan from an approved spec, with the architecture survey + constitution check.
argument-hint: <feature-slug> (optional; defaults to most recent spec)
allowed-tools: Read, Write, Edit, Glob, Grep, Bash
---

Read `.specify/memory/constitution.md`, `AGENTS.md`, and `specs/$ARGUMENTS/spec.md`.
Create `specs/<feature-slug>/plan.md` from `.specify/templates/plan-template.md`.

1. **Architecture survey first** — read the real code; map "where is what" across
   `messages`/`graphs`/`llm`/`tools`/`agents`/`types`/`common`/`run.ts`/`stream.ts`.
   State what to reuse/extend (`common/*`, `types/*`), what upstream code must
   change (keep it surgical), what redundant code to delete. Cite real `src/...`.
2. Fill the **Constitution Check (I–VI)** — PASS + how, or FLAG + resolution. Pay
   special attention to III (minimal upstream drift). Not done until all PASS/resolved.
3. Map every acceptance criterion to components; define verification (jest/build).

No feature code yet. End by telling the user to run `/tasks`.
