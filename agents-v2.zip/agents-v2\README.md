# @illuma-ai/agents

The **Illuma agent runtime** — the TypeScript engine behind Illuma's agents: graph
orchestration, streaming event handling, tool execution, provider adapters, subagent
delegation, and message/context management for single-agent and multi-agent runs.

It is published under Illuma's own version line and consumed by the Illuma platform
(`illuma-ai/chat-v2`) as `@illuma-ai/agents`.

|              |                                                                                                    |
| ------------ | -------------------------------------------------------------------------------------------------- |
| Package      | `@illuma-ai/agents` (npm, public)                                                                  |
| Version line | `illuma.version.json` — Illuma semver, e.g. `4.0.0`                                                |
| Repository   | `illuma-ai/agents-v2`                                                                              |
| Consumer     | `illuma-ai/chat-v2`, pinned through `branding.config.json` (`npm run agents:version -- <version>`) |

## Install

```bash
npm install @illuma-ai/agents
```

## What the runtime provides

- Single-agent and multi-agent workflows on LangGraph, with handoffs and subagent delegation
- Streaming content aggregation and run-step event handlers (reasoning, tool calls, artifacts)
- Tool calling, tool search, programmatic tool execution, background tasks
- Provider adapters: Anthropic, Amazon Bedrock, Vertex AI, Google, OpenAI-compatible, Mistral,
  DeepSeek, xAI
- Message formatting, context pruning and fading, summarization/compaction, prompt-cache control

## Basic usage

```typescript
import { HumanMessage } from '@langchain/core/messages';
import { Providers, Run } from '@illuma-ai/agents';

const run = await Run.create({
  runId: crypto.randomUUID(),
  graphConfig: {
    type: 'standard',
    instructions: 'You are a helpful assistant.',
    llmConfig: {
      provider: Providers.BEDROCK,
      model: 'us.anthropic.claude-sonnet-5',
    },
  },
});

await run.processStream(
  { messages: [new HumanMessage('Hello')] },
  { version: 'v2' }
);
```

## Platform guarantees

Behaviour the Illuma platform depends on is asserted by its installed-bundle guard
(`chat-v2/packages/api/src/agents/__tests__/agentsLibraryGuards.spec.ts`), so the platform
can only ever run a build of this package that carries it.

- **Bedrock redacted reasoning is never surfaced as text.** Bedrock returns some reasoning as an
  encrypted, opaque payload. The runtime emits an empty reasoning marker for it and keeps the
  payload on the round-trip path where it belongs, so nothing opaque reaches the UI.
  (`src/llm/bedrock/utils/message_outputs.ts`)

## Versioning and publishing

The published identity lives in `illuma.version.json`:

```json
{ "name": "@illuma-ai/agents", "version": "4.0.0" }
```

| Event                               | Bump    |
| ----------------------------------- | ------- |
| a runtime feature release           | `minor` |
| a fix                               | `patch` |
| a breaking change in the public API | `major` |

```bash
node scripts/publish-illuma.mjs --dry-run --bump minor
NPM_TOKEN=<token> node scripts/publish-illuma.mjs --bump minor
```

The script publishes the version in `illuma.version.json`, records the source commit in the
published manifest, and tags `illuma/v<version>`. Details: `docs/publishing-illuma.md`.

## Branches

- `develop` — the default branch. All work lands here and is published from here.
- `main` — the release baseline; never receives feature work directly.

### Accepted tool-call projection (opt-in)

`createOpenAIToolCallStream` from `@librechat/agents/openai` formats finalized
calls accepted by the graph, not provider fragments. Existing handlers are unchanged.

- Register `projection.handlers` in `Run.create({ customHandlers })`.
- For streaming, share `{ tracker, emit }` with the text/reasoning handlers and
  `sendOpenAIFinalChunk`. Do not also register legacy raw tool-call handlers.
  Map-only `{ toolCalls }` supports JSON/custom finalization. Use fresh output state.
- Call `finish()` only after natural completion: no error, aborted signal,
  `getInterrupt()` or `getHaltReason()`. Otherwise call `abort()` and discard it.
  A resolved `processStream()` alone does not mean success.
- Calls execute in the graph by default. To hand a complete call to the OpenAI
  client instead, set `clientDelegatedToolNames: ['my_tool']` in `Run.create`
  for a single-agent run and register its model-facing schema. The graph ends
  without executing that call. Batches mixing delegated and graph/provider
  tools fail closed; make separate model turns. ToolNode claims remain an
  additional guard, never proof that an unclaimed call belongs to the client.
- `emit` is synchronous. Failed/partial writes cannot be retried; the host owns
  HTTP backpressure. This helper does not provide durable resume or undo tool effects.

Projected arguments must be JSON data: primitives, plain objects and dense arrays.
Getters, custom objects, cycles and nesting beyond 64 levels are rejected before projection.
Observers receive isolated snapshots; provider IDs are reserved before synthetic IDs.
Accepted-event snapshots cap each response at **1,024 calls / 4 MiB**. Projection
uses those defaults for pending calls (`maxToolCalls` / `maxBufferedBytes`). These
formatting limits do not apply to ordinary runs without accepted-event handlers;
descriptor safety checks still apply before stream accounting and dispatch.
These are output limits, not bounds on provider memory or tool execution.

See [the design decision](docs/adr/0010-project-accepted-model-results.md).

## Development

```bash
npm install
npm run build          # tsdown + tsc types
npx jest --coverage=false
```

Windows note: a handful of suites assume POSIX paths (`/tmp`) or tight timing and fail on
Windows regardless of the code; compare the failing **set** against the previous tag rather than
the count.

## License

MIT — see `LICENSE`.
