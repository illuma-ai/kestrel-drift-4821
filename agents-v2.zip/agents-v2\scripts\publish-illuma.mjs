#!/usr/bin/env node
/**
 * Publish this fork of the agent runtime as `@illuma-ai/agents` on the platform's
 * OWN version line.
 *
 * Identity lives in `illuma.version.json` (fork-owned; an upstream merge never
 * touches it): the published name, the platform's version, and the upstream
 * release this build carries. The tracked `package.json` keeps upstream's name
 * and version so upstream pulls never conflict on identity. For the duration of
 * one `npm publish` the manifest is rewritten (name, version, `publishConfig`,
 * and an `illuma` block recording the base release and the commit) and then
 * restored — nothing about a publish is committed except the version file.
 *
 * Version scheme — the platform's semver, not upstream's:
 *   --bump minor   after an upstream merge         4.0.0 -> 4.1.0
 *   --bump patch   for a fork-only fix             4.1.0 -> 4.1.1
 *   --bump major   for a breaking fork API change  4.1.1 -> 5.0.0
 *
 * Usage:
 *   node scripts/publish-illuma.mjs --dry-run                 # show what would publish
 *   NPM_TOKEN=… node scripts/publish-illuma.mjs               # publish illuma.version.json's version
 *   NPM_TOKEN=… node scripts/publish-illuma.mjs --bump minor  # bump, commit the version file, publish
 *   node scripts/publish-illuma.mjs --tag next                # dist-tag (default: latest)
 *
 * Refuses when the recorded `upstream` does not match `package.json`'s version —
 * that means upstream was merged and the version file was not bumped — and when
 * the version is already on the registry. Auth comes from `.npmrc` (`${NPM_TOKEN}`).
 * `prepublishOnly` runs the full build, so the tarball is always fresh.
 */
import { execSync, spawnSync } from 'node:child_process';
import { readFileSync, writeFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const PKG = path.join(ROOT, 'package.json');
const VERSION_FILE = path.join(ROOT, 'illuma.version.json');

const args = process.argv.slice(2);
const flag = (name) => args.includes(name);
const option = (name) => {
  const i = args.indexOf(name);
  return i === -1 ? undefined : args[i + 1];
};
const dryRun = flag('--dry-run');
const distTag = option('--tag') ?? 'latest';
const bump = option('--bump');

const shell = process.platform === 'win32';
const originalManifest = readFileSync(PKG, 'utf8');
const pkg = JSON.parse(originalManifest);
const identity = JSON.parse(readFileSync(VERSION_FILE, 'utf8'));

function fail(message) {
  console.error(`\n${message}`);
  process.exit(1);
}

function bumped(version, kind) {
  const [major, minor, patch] = version.split('.').map(Number);
  if (kind === 'major') return `${major + 1}.0.0`;
  if (kind === 'minor') return `${major}.${minor + 1}.0`;
  if (kind === 'patch') return `${major}.${minor}.${patch + 1}`;
  fail(`--bump must be major, minor or patch (got ${kind})`);
}

function publishedVersions() {
  const out = spawnSync('npm', ['view', identity.name, 'versions', '--json'], {
    cwd: ROOT,
    encoding: 'utf8',
    shell,
  });
  if (out.status !== 0) return [];
  const parsed = JSON.parse(out.stdout || '[]');
  return Array.isArray(parsed) ? parsed : [parsed];
}

function gitStatus() {
  return execSync('git status --porcelain', {
    cwd: ROOT,
    encoding: 'utf8',
  }).trim();
}

if (bump) {
  identity.version = bumped(identity.version, bump);
  identity.upstream = pkg.version;
}

const spec = `${identity.name}@${identity.version}`;
const commit = execSync('git rev-parse --short HEAD', {
  cwd: ROOT,
  encoding: 'utf8',
}).trim();

console.log(`upstream base : ${pkg.name}@${pkg.version} (${commit})`);
console.log(`publishing as : ${spec}  (dist-tag: ${distTag})`);
console.log(`host alias    : "@librechat/agents": "npm:${spec}"`);

if (identity.upstream !== pkg.version) {
  fail(
    `illuma.version.json records upstream ${identity.upstream} but package.json is ${pkg.version}.\n` +
      'Upstream was merged without a bump. Run with --bump minor (or patch/major) so the version file follows the merge.'
  );
}
if (publishedVersions().includes(identity.version)) {
  fail(
    `${spec} is already on the registry. Bump the version (--bump patch|minor|major).`
  );
}

if (dryRun) {
  console.log('\n--dry-run: nothing published, nothing written.');
  process.exit(0);
}
if (!process.env.NPM_TOKEN) {
  fail(
    'NPM_TOKEN is not set. Run: NPM_TOKEN=<token> node scripts/publish-illuma.mjs'
  );
}

const dirty = gitStatus();
if (dirty.length > 0) {
  fail(
    'Working tree is not clean. Commit or stash first — the publish rewrites package.json and must be able to restore it.\n' +
      dirty
  );
}

if (bump) {
  writeFileSync(VERSION_FILE, JSON.stringify(identity, null, 2) + '\n');
  execSync(
    `git add illuma.version.json && git commit -q -m "chore(release): ${spec} (upstream ${pkg.version})"`,
    {
      cwd: ROOT,
      stdio: 'inherit',
      shell,
    }
  );
}

const rewritten = {
  ...pkg,
  name: identity.name,
  version: identity.version,
  publishConfig: { ...(pkg.publishConfig ?? {}), access: 'public' },
  illuma: { base: pkg.version, commit },
};

try {
  writeFileSync(PKG, JSON.stringify(rewritten, null, 2) + '\n');
  const result = spawnSync(
    'npm',
    ['publish', '--access', 'public', '--tag', distTag],
    {
      cwd: ROOT,
      stdio: 'inherit',
      shell,
      env: process.env,
    }
  );
  if (result.status !== 0)
    throw new Error(`npm publish exited with ${result.status}`);
} finally {
  writeFileSync(PKG, originalManifest);
}

const gitTag = `illuma/v${identity.version}`;
execSync(
  `git tag -a ${gitTag} -m "published ${spec} (upstream ${pkg.version}, ${commit})"`,
  {
    cwd: ROOT,
    stdio: 'inherit',
    shell,
  }
);
console.log(`\npublished ${spec}; tagged ${gitTag}`);
console.log(
  `next, in the host repo: npm run agents:version -- ${identity.version} --install`
);
