# Engineering Constitution — agents library

Non-negotiable principles for every change. This repo is a **fork** of the
upstream `@librechat/agents` library; the overriding constraint is to stay
cleanly mergeable with upstream while shipping verified, well-scoped deltas. The
spec-driven workflow (`/specify`→`/clarify`→`/plan`→`/tasks`→`/implement`→
`/converge`→`/verify`) and the `verified-development` skill enforce these. Code
style ground-truth is `AGENTS.md`; these principles add the process gate.

## I. Quality gate is law

`npm run lint` (eslint) + `npm run build` (tsdown + `tsc` typecheck) + `npm test`
(jest) all green before "done". The local gate is the source of truth; CI
(`.github/workflows/ci.yml`) mirrors it and is **manual-only**
(`workflow_dispatch`) on this private repo. Publishing is manual
(`publish.yml`, `workflow_dispatch`), never on push.

## II. Every change ships with a test

A fix ships a regression test; new behaviour ships jest specs (real logic over
mocks). Full suite green; coverage may not regress.

## III. Minimal upstream drift (fork discipline)

This is a fork — keep deltas **surgical and clearly scoped** so upstream stays
cleanly pullable. Do not gratuitously refactor or reformat upstream code; touch
only what the change needs. Workflow/process scaffolding lives **outside `src/`**
(`.specify/`, `.claude/`, `.github/`, `docs/`) so it never collides with upstream
source merges. Record every intentional delta in `CHANGELOG.md`. Brand-neutral:
no company/product names introduced into code, comments, or tests.

## IV. SoT, modular, functional-first

Enums/constants live in `src/common/`; never inline what belongs there. **Survey
first and reuse** before adding. Functional-first (pure functions, immutable
data, `map`/`filter`/`reduce`); never-nesting (early returns, flat, small
well-named helpers); no dynamic imports unless necessary. DRY — extract a tested
helper instead of copy-paste; **delete redundant/dead code**. No patch-fixes —
fix at the right layer.

## V. Documentation stays current (add AND prune)

In the same change: update the relevant docs (`AGENTS.md`/`docs/*`) and add a
`CHANGELOG.md` `[Unreleased]` entry. A change that invalidates existing docs MUST
update or delete the stale parts — no doc may describe removed/altered behaviour;
no dangling links. Docs and the CHANGELOG tell the same story.

## VI. Code documented to standard

JSDoc on public/exported APIs; comments explain **WHY** (intent, non-obvious
tradeoff), not what. Modern TS typing; shared types from `src/types/`. See
`docs/coding-standards.md`.

## Right-sizing the process (apply the tier that fits)

- **Trivial** (typo, comment, tiny tweak): no spec — keep the gate green + a
  CHANGELOG entry if behaviour/docs of record change.
- **Small** (one contained change, clear scope, no public-API or ambiguity): a
  short `spec.md` + `tasks.md`; skip formal plan, `/clarify`, `/converge`.
- **Substantial** (public-API/streaming/graph change, cross-cutting, or ambiguity,
  or anything that increases upstream drift): the full pipeline.
  The gate + non-negotiables (I–VI) ALWAYS apply. Anything that widens upstream
  drift is never "trivial". When in doubt, size up.

## Definition of Done

- [ ] Tier chosen; small/substantial have `specs/<feature>/` artifacts + the
      plan's Constitution Check.
- [ ] `npm run lint` + `npm run build` + `npm test` green.
- [ ] Tests added (regression test for fixes).
- [ ] Deltas surgical; no gratuitous upstream churn; CHANGELOG `[Unreleased]` + docs updated; stale docs pruned.
- [ ] Brand-neutral; public APIs JSDoc'd; specific paths staged (no `-A`).

## Amendment & versioning

Semantic version below; amend via a documented PR; keep templates, commands, and
the `verified-development` skill in sync.

**Version:** 1.0.0 · **Ratified:** 2026-06-20
