# Spec: <FEATURE NAME>

> Produced by `/specify`. WHAT/WHY only — no HOW.

## Status

- **Feature slug:** <kebab-id>
- **State:** draft | approved
- **Constitution touch:** <principles I–VI affected>

## Problem / motivation

<What library capability/fix does this serve? Why now?>

## Goals / Non-goals

- Goal: <measurable> · Non-goal: <out of scope>

## Acceptance criteria (testable Given/When/Then)

1. GIVEN … WHEN … THEN …

## Public-API / upstream-drift impact (Principle III)

- New/changed exported API or behaviour? How much does it diverge from upstream,
  and can the delta be kept surgical? **State "none / internal-only" if so.**

## Edge cases & failure modes

- streaming/graph edge cases; provider differences; error paths.

## Review checklist (before `/plan`)

- [ ] No implementation detail leaked
- [ ] Every criterion testable
- [ ] Public-API / upstream-drift impact stated
