<!-- Non-trivial changes flow through the verified-development workflow. See
docs/development-workflow.md. This is a fork — keep deltas surgical. -->

## What & why

- **Feature/fix:** <!-- specs/<slug> or "trivial — no spec" -->
- **Tier:** trivial | small | substantial
- **Upstream-drift:** <!-- none/internal-only | describe the delta -->

## Workflow

- [ ] Spec (+ `/clarify` if ambiguous) — or justified trivial
- [ ] Plan with **Constitution Check (I–VI)** passing
- [ ] Tasks generated; all boxes checked (`/implement`); `/converge` ran
- [ ] `/verify` verdict = READY (paste below)

## Gate (must be green)

- [ ] `npm run lint`
- [ ] `npm run build` (tsdown + tsc typecheck)
- [ ] `npm test`

## Constitution (I–VI)

- [ ] **II** Tests added (regression test for fixes)
- [ ] **III** Minimal upstream drift; no gratuitous reformat/refactor; brand-neutral
- [ ] **IV** SoT in `common/*`; functional-first; redundant code removed
- [ ] **V** Docs + CHANGELOG `[Unreleased]` updated; stale docs pruned
- [ ] **VI** Public/exported APIs JSDoc'd; why-comments

## `/verify` verdict

<!-- READY / NOT READY + gate output -->
