---
name: verified-development
description: >-
  Spec-driven, step-verified workflow for this agents library (a fork of upstream
  @librechat/agents). Use for any non-trivial change so work is planned,
  structured, and verified with no step skipped, assumed, or hallucinated — and so
  deltas stay surgical and the fork stays cleanly pullable. Enforces the
  constitution and the gate (npm run lint + build + test). Trivial edits skip the
  ceremony but keep the gate green.
---

# Verified Development (agents library / fork)

The "superpower" over the Spec Kit commands. Match ceremony to risk (constitution
**Right-sizing** tiers): trivial → gate+CHANGELOG; small → spec+tasks; substantial
(or anything widening upstream drift) → full pipeline. Code style: `AGENTS.md`.

## Pipeline (don't reorder, don't skip)

1. **`/specify`** → `specs/<slug>/spec.md` — what/why + public-API/upstream-drift impact.
   1b. **`/clarify`** (if ambiguous) → ≤5 questions, answers written back to spec.
2. **`/plan`** → `plan.md` — architecture survey + **Constitution Check (I–VI)**.
3. **`/tasks`** → `tasks.md` — small, test-first, Final Gate G1–G5.
4. **`/implement`** → execute in order; box checked only after its verification; RED→GREEN.
   4b. **`/converge`** → re-assess code vs artifacts; append remaining work as tasks.
5. **`/verify`** → independent pass: gates + acceptance + constitution. READY/NOT.

## Hard rules (anti-hallucination)

- A box is checked only after its own verification passed — never batched.
- Test-first; read before write; root-cause not patch-fix.
- **Minimal upstream drift**: keep deltas surgical; never reformat/refactor
  untouched upstream code; scaffold lives outside `src/`.
- The gate is law: `npm run lint` + `npm run build` + `npm test` green before done.
  Stage specific paths; brand-neutral; truthful reporting (state failures/skips).

## References

- Constitution: `.specify/memory/constitution.md` (I–VI + tiers) · Style: `AGENTS.md`
- Templates: `.specify/templates/*` · Standards: `docs/coding-standards.md`
- Guide: `docs/development-workflow.md` · CI: `.github/workflows/ci.yml` (manual)
