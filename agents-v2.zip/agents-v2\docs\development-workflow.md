# Development Workflow — Spec-Driven & Verified

This agents library (a fork of upstream `@librechat/agents`) uses a spec-driven,
step-verified workflow so every change is planned, structured, and verified with
no skipped/hallucinated steps — and so deltas stay surgical and the fork stays
cleanly pullable. Pairs a Spec Kit-style pipeline (Claude Code commands) with the
`verified-development` skill, gated by `npm run lint` + `npm run build` + `npm test`.

## Pipeline

```
request ─▶ /specify ─▶ /clarify? ─▶ /plan ─▶ /tasks ─▶ /implement ─▶ /converge ─▶ /verify ─▶ PR
            spec.md      (≤5 Qs)     plan.md   tasks.md   (check off)   (gap→tasks)   READY?
                                  + Constitution Check (I–VI)
```

Artifacts: `specs/<feature-slug>/{spec,plan,tasks}.md`. Constitution:
`.specify/memory/constitution.md` (I–VI). Code style: `AGENTS.md`.

## Right-size it

- **Trivial** (typo/comment): gate + CHANGELOG only.
- **Small** (contained, clear scope, no public-API/ambiguity): short spec + tasks.
- **Substantial** (public-API/streaming/graph change, ambiguity, or anything
  widening upstream drift): full pipeline.
  The gate + non-negotiables always apply; widening drift is never trivial.

## The gate (law)

```bash
npm run lint     # eslint
npm run build    # tsdown + tsc typecheck
npm test         # jest
```

CI (`.github/workflows/ci.yml`) mirrors the gate and is **manual-only**
(`workflow_dispatch`) on this private repo; publishing (`publish.yml`) is manual
too (never on push).

## Anti-hallucination rules

Box checked only after its verification passes (never batched); test-first
(RED→GREEN); read before write; root-cause not patch-fix; **minimal upstream
drift** (no gratuitous reformat/refactor; scaffold outside `src/`); docs +
CHANGELOG stay current; truthful reporting.
