# Plan: <FEATURE NAME>

> Produced by `/plan` from the approved `spec.md`. HOW. Must pass the
> Constitution Check before tasks.

## Linked spec

`specs/<feature-slug>/spec.md`

## Existing-architecture survey (do FIRST)

- **Where is what** — `messages/`, `graphs/`, `llm/`, `tools/`, `agents/`,
  `types/`, `common/`, `run.ts`, `stream.ts`.
- **Reuse/extend** — existing `common/` enums/constants, `types/`, helpers.
- **Drift** — what upstream code must change (keep it minimal) vs new files;
  what redundant code to delete.

## Constitution Check (I–VI) — PASS / N-A / FLAG+resolution

- [ ] I gate (lint/build/test) · II tests · III minimal drift + brand-neutral ·
      IV SoT/functional-first/never-nesting/DRY · V docs+CHANGELOG · VI JSDoc.

## Components & changes

| Area         | File(s)                                      | Change          |
| ------------ | -------------------------------------------- | --------------- |
| common (SoT) | `src/common/...`                             | enums/constants |
| core         | `src/{graphs,llm,messages,tools,agents}/...` |                 |
| types        | `src/types/...`                              |                 |
| tests        | `src/**/*.spec.ts` / `test/...`              |                 |
| docs         | `AGENTS.md`/`docs/*`, `CHANGELOG.md`         |                 |

## Risks & mitigations · Verification

- <risk → mitigation>; how each acceptance criterion is proven (jest / build).
