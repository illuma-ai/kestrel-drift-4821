# Coding Standards

Code-level reference for **Constitution IV & VI**. Full code style lives in
`AGENTS.md`; this consolidates the expectations + the verifiable docstring check.

## In-code developer documentation (Principle VI)

- **JSDoc on public/exported APIs** explaining the **why** (intent, non-obvious
  tradeoff); `@param`/`@returns`/`@throws` where it adds clarity.
- Comment the "why", not the "what".

## Structure, SoT & style (Principle IV)

- **Survey before adding** — reuse/extend existing modules; don't reinvent.
- **Single source of truth:** enums/constants → `src/common/`; shared types →
  `src/types/`. Never inline what belongs there.
- **Functional-first**: pure functions, immutable data, `map`/`filter`/`reduce`.
  **Never-nesting**: early returns, flat, small well-named helpers. No dynamic
  imports unless necessary. **Delete redundant/dead code**; no patch-fixes.

## Fork discipline (Principle III)

- Keep deltas **surgical** — touch only what the change needs; never reformat or
  refactor untouched upstream code (it creates merge conflicts on upstream pulls).
- Workflow/config scaffolding stays outside `src/`. Record deltas in `CHANGELOG.md`.

## Types, build & gate

- Modern TS. Gate: `npm run lint` (eslint) + `npm run build` (tsdown + tsc
  typecheck) + `npm test` (jest) — all green.

## Verifiable docstring check (public exports JSDoc'd)

```bash
grep -rEln 'export (async )?(function|class|const) ' src --include='*.ts' | while read f; do
  node -e '
    const fs=require("fs"),s=fs.readFileSync(process.argv[1],"utf8").split("\n");
    s.forEach((l,i)=>{ if(/^export (async )?(function|class) /.test(l) &&
      !/\*\//.test((s[i-1]||""))) console.log(process.argv[1]+":"+(i+1)+" "+l.trim().slice(0,60)); });
  ' "$f";
done
```
