# Changelog

Notable changes to this fork of `@librechat/agents` are documented here. Format:
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/); [SemVer](https://semver.org/).
Record intentional **deltas from upstream** here (Constitution III). Update
`[Unreleased]` in the same change that alters behaviour.

## [Unreleased]

### Changed

- **Integrated upstream v3.8.4 → v3.8.6** (4 commits, 78 files) into `develop`. One
  conflict, `graphs/Graph.ts`: upstream re-ordered its import blocks (moved the
  `@/summarization`, `@/llm/prepareProviderRequest` and `@/messages/reducer` imports up the
  file) across the line where the fork imports `compactToolContent` from `@/utils/toolContent`.
  Resolved take-both; every symbol imports once. The fork deltas in that file — the
  degrade-before-hard-fail trim (`emergencyTrimLargestToolResults`), the HITL resume seeding
  (`rehydrateFromContentParts`, `SeedContentPart`) and the sparse-`contentData` guards — are
  untouched; `types/tools.ts`'s `media_type`/`view_url` on `FileRef` auto-merged.
  - Upstream #538 hardens the tool-approval replay lifecycle (`toolBatchReplay`,
    `ToolNode` approval scope) and #539 adds a host-owned execution context for subagent
    runs (`subagentContext` adapter on `StandardGraph`, isolated code-session partitions,
    authorized inputs retained across failed code calls). Both are additive to the fork's
    behaviour; the redacted-reasoning guard (`llm/bedrock/utils/message_outputs.ts`) is the
    only `UPSTREAM DELTA` site and it is unchanged.

- **Integrated upstream v3.7.17 → v3.8.4** (42 commits, 128 files) into `develop`,
  bumping the package to **3.8.4** so the host's `@librechat/agents@^3.8.2`
  requirement resolves to a build that still carries the fork deltas. Four
  conflicts, none resolved by a blind keep-ours:
  - `graphs/Graph.ts` — upstream (#502) extracted the inline serving-artifact
    projection into a `projectServingArtifacts` helper, which collided with the
    fork's `emergencyTrimLargestToolResults`. Upstream's helper adopted wholesale
    as the base; the fork's degrade-before-hard-fail block re-grafted above it,
    untouched.
  - `tools/CodeExecutor.ts` and `tools/BashExecutor.ts` — upstream (#515) began
    appending an artifact-delivery warning, renaming the tool text the return
    site consumes (`outputWithReminder` → `outputWithDeliveryWarning`). The fork's
    image-vision wrapper now wraps **upstream's** new text, so the delivery
    warning is preserved; keeping the fork's side verbatim would have silently
    dropped it. Also took upstream's `CodeApiRequestError` (#535) and Code API
    auth-failure logging (#508), and merged both sides' imports.
  - `tools/__tests__/SubagentReplay.test.ts` — additive; took upstream's
    `toolBatchReplay` import (#531) and dropped its duplicate
    `RunStepResumeState` type import.
  - `tools/__tests__/CodeApiAuthHeaders.test.ts` auto-merged to upstream's
    formatting; the fork's delta there was pure prettier churn on `.invoke()`
    argument layout, so nothing behavioural was lost.
  All 14 fork-only files are byte-identical to their pre-merge state, and the
  fork footprint measured against `upstream/main` is unchanged (285 insertions in
  `Graph.ts`, all fork deltas). Re-verified present: the REDACTED-reasoning guard
  (`UPSTREAM DELTA` marker count 1 → 1, and `dist/{cjs,esm}` both assign `""`
  rather than the base64 payload), `rehydrateFromContentParts` and the sparse
  `contentData` guards, `emergencyTrimLargestToolResults`, the consumed-image
  prune, the image-vision content blocks, `session_id` threading, the extra
  `CODE_EXECUTION_TOOLS` members, `FileRef.media_type`/`view_url`, and the
  OpenAI cache-breakpoint casts. `applicationInferenceProfile`/`serviceTier` and
  the locally-ported bedrock utils are now upstream-owned — no fork delta remains
  for them. Gate: `tsc` clean, lint 0 errors (only pre-existing `indent` churn and
  warnings, counts identical pre/post), build clean, and a pre-merge baseline run
  proves **zero test regressions** — the failing set is byte-identical (7 suites /
  26 tests, all pre-existing live-API and Windows-platform failures) while
  upstream adds 418 passing tests (5,022 → 5,440).

- **Integrated upstream v3.7.3 → v3.7.7** (7 commits) into `develop`. **Zero conflicts.**
  Carries #473 (align compaction with provider cache prefixes — a new
  `llm/promptCacheTools` module plus summarization-node changes, with ADR 0006), #475
  (prefer keenable snippets, falling back to descriptions when blank) and #478 (serialize
  suspended event-actor invocations — the SDK half of the host's bound-actor mailbox work).
  Fork deltas re-verified present afterwards (`rehydrateFromContentParts`, the
  `emergencyTrimLargestToolResults` degrade and its `compactToolContent` import, the prune
  guards, `neverBundle`, the extra `CODE_EXECUTION_TOOLS` members). Gate: tsc clean, lint 0
  errors, build clean, and the failing-suite set is the known pre-existing one MINUS
  `llm/stream/smoother.test.ts`, which now passes — zero regressions, one fixed.

- **Integrated upstream v3.6.8 → v3.7.3** (36 commits) into `develop`. Four
  conflicts, all resolved by re-applying the fork delta ON TOP of upstream rather
  than keeping either side wholesale:
  - `graphs/Graph.ts` final-payload projection — upstream now reuses the
    measurement already computed by `prepareProviderRequest`
    (`preparedRequest.measurement ?? measureProviderPayload(...)`), avoiding a
    redundant pass. Adopted, with the fork's degrade-before-hard-fail block
    (`emergencyTrimLargestToolResults`) re-applied on top of it.
  - The fork's inline synthetic-context compaction in `Graph.ts` is **deleted**:
    upstream extracted the identical logic into
    `compactSyntheticProviderContextMessage`. Upstream's helper is now the single
    implementation (collision resolved in upstream's favour, fork twin removed).
  - `tools/local/workspaceFS.ts` and `tools/__tests__/ProgrammaticToolCalling.test.ts`
    conflicted only on stray blank lines; upstream taken. The latter's remaining
    delta was upstream's own newly added manifest tests, not a fork change.
  - `package-lock.json` taken from upstream, `package.json` being byte-identical.
  - Repaired a silent auto-merge casualty: upstream's rewrite of the `Graph.ts`
    import block dropped `compactToolContent` while a fork call site survived, so
    the tree did not compile until the import was restored.
  Fork deltas re-verified present afterwards (`rehydrateFromContentParts` and the
  resume-seed gate, the extra `CODE_EXECUTION_TOOLS` members, the shared code-exec
  sandbox session and image-vision blocks, the prune guards, `neverBundle`).
  Gate: `tsc` clean, lint 0 errors, build clean, and a pre-merge baseline run
  proves **zero test regressions** — `utils/toolContent.test.ts` goes from red to
  green, and upstream adds 437 tests (4,407 → 4,844).

- **Integrated upstream v3.3.10 → v3.3.11** (2 commits) into `develop`. Zero
  conflicts. Carries #376 "Neutralize Preempted Responses References", which stops
  a preempted (interrupted) response's tool references from leaking into the
  replacement turn — the SDK half of the host's Interrupt & Steer work. Fork deltas
  re-verified present afterwards (`rehydrateFromContentParts` + resume-seed gate,
  `create_file` in `CODE_EXECUTION_TOOLS`, shared sandbox session + image-vision
  blocks, manual-only CI/publish, the `test/**` lint ignore).
- **Integrated upstream v3.2.68 → v3.3.10** (37 commits) into `develop`. Merged
  with zero conflicts; every fork delta verified present afterwards
  (`rehydrateFromContentParts` + resume-seed gate, `create_file` in
  `CODE_EXECUTION_TOOLS`, the shared code-exec sandbox session and image-vision
  content blocks, manual-only CI/publish workflows). The fork's Windows
  `neverBundle` guard is now redundant: upstream adopted the equivalent
  `!isAbsolute(id)` check, which covers `C:\…` paths, so the delta is dropped
  rather than re-applied.

### Fixed

- **Lint gate: exclude `test/**` from the type-aware parser.** Upstream's new
  Jest module stub (`test/stubs/mistralai.ts`) sits outside tsconfig's
  `src/**/*` include, so `parserOptions.project` could not resolve a project for
  it and the lint gate failed with a parsing error. Ignored alongside the
  existing out-of-project entries (`src/scripts/`, `**/*.spec.ts`).

- **HITL resume streaming — tool output binding + content ordering.** When a run
  is paused for tool approval and later resumed, the graph is rebuilt fresh and
  LangGraph restores channel/message state from the checkpoint, but NOT the
  graph's transient step-tracking instance fields (`toolCallStepIds`,
  `contentData`, `contentIndexMap`). The consumer's content aggregator keeps its
  own `stepMap`, seeded only by `ON_RUN_STEP` events — which never re-fire for the
  pre-pause tool call on resume. The result: the approved tool's
  `ON_RUN_STEP_COMPLETED` found no run step, so its output was dropped (rendered
  as "Cancelled"), and resumed content restarted its index at 0, mis-ordering the
  answer before the tool. New public method `StandardGraph.rehydrateFromContentParts(parts)`
  (called by the host after graph rebuild, before resume) re-seeds the graph's
  step-tracking from the pre-pause content parts using each part's **original
  content index**, and re-dispatches `ON_RUN_STEP` for tool_call parts through the
  handler registry so the aggregator's `stepMap` is seeded consistently. The
  approved tool's completion now binds its output in place (one card, no
  duplicate), and resumed content continues after the seed (correct order) — the
  resumed turn streams identically to a non-paused turn. No-op on non-resume runs.
  `getRunSteps`/`getRunStepsByAgent`/`getActiveAgentIds`/`getContentPartAgentMap`
  gained hole-tolerance guards since seeded `contentData` may be sparse.
- **HITL resume — re-dispatch gated to PENDING tool_calls only (duplicate-id fix).**
  `rehydrateFromContentParts` previously re-dispatched `ON_RUN_STEP` for _every_
  seed tool_call. After upstream added its own checkpointer-based `ask_user_question`
  resume (#14139/#14123), that double-registered **already-completed** tool_calls
  (e.g. answered questions in a multi-question turn), so the rebuilt assistant
  message carried the same `tool_use` id twice and the provider rejected the NEXT
  turn (`toolUse blocks contain duplicate Ids`). The re-dispatch is now gated on the
  tool_call being **pending** (`output == null || ''`) — the paused approval tool
  still gets re-dispatched (its completion needs the aggregator `stepMap`), while
  completed parts are only seeded into `toolCallStepIds`/`contentData` for ordering
  and stream continuity. Regression spec: `src/graphs/__tests__/rehydrateGate.test.ts`
  (blocked from running by the pre-existing `@mistralai` ESM jest-transform debt;
  verified end-to-end live — both HITL paths, 0 `duplicate Ids`). Keeps the fork's
  MCP-approval resume working without re-processing what upstream now handles.

### Added

- **Spec-driven, verified development workflow** — engineering constitution
  (`.specify/memory/constitution.md`, principles I–VI + right-sizing tiers),
  spec/plan/tasks templates, Claude Code commands (`/specify`, `/clarify`,
  `/plan`, `/tasks`, `/implement`, `/converge`, `/verify`), the
  `verified-development` skill, a PR template, `docs/coding-standards.md`, and
  `docs/development-workflow.md`. Fork-aware (keep deltas surgical); gate is
  `npm run lint` + `npm run build` + `npm test`. All scaffold lives outside `src/`.

### Changed

- **CI + publish are manual-only** — `ci.yml` runs on `workflow_dispatch` (was
  `pull_request`); `publish.yml` runs on `workflow_dispatch` only (was push to
  `main`) so the package never auto-publishes. Private fork, conserve Actions
  minutes; local gate is the enforced source of truth.
