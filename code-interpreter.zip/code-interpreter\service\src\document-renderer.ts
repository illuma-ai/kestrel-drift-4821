/**
 * UPSTREAM DELTA — Document Renderer sidecar.
 *
 * Converts office documents to PDF (LibreOffice) and rasterizes PDFs into
 * per-page images (poppler). This exists because the host platform previews
 * uploaded Word/Excel/PowerPoint files page-perfectly: the document is
 * converted to PDF once, and the client paints that PDF. Rendering a document
 * is NOT code execution, so it deliberately does not run in the code sandbox.
 *
 * Design — why a separate service rather than the sandbox image:
 *   * The sandbox rootfs stays byte-identical to upstream, so the fork remains
 *     cleanly pullable (LibreOffice would add ~1 GB to an image whose whole
 *     point is a minimal attack surface).
 *   * Rendering is bursty and CPU-heavy; it scales independently of execution.
 *   * Single responsibility — this process only transcodes bytes.
 *
 * Security posture: this service is PURE COMPUTE. It holds no credentials, has
 * no storage access, and never talks to S3 or Redis — the API router owns all
 * persistence and passes bytes in/out. It is bound to the internal network and
 * gated by the shared internal-service token, so it is not externally
 * reachable. Untrusted document parsing still happens here (LibreOffice is a
 * large parser surface), so the container runs non-root with a read-only
 * rootfs, a tmpfs work dir, no network egress, and a per-request timeout.
 *
 * Routes (internal only):
 *   POST /internal/documents/preview  body: raw bytes → application/pdf
 *   POST /internal/documents/pages    body: raw PDF  → JSON page images + text
 *   GET  /health | /ready | /metrics
 */

import express from 'express';
import { execFile } from 'node:child_process';
import { promises as fs } from 'node:fs';
import { tmpdir } from 'node:os';
import path from 'node:path';
import { promisify } from 'node:util';
import { nanoid } from 'nanoid';

import { isAuthorizedInternalServiceRequest, internalServiceAuthEnabled } from './internal-service-auth';
import logger from './toolCallServerLogger';

const execFileAsync = promisify(execFile);

const PORT = Number(process.env.DOCUMENT_RENDERER_PORT) || 3060;
/** Hard ceiling on a single LibreOffice/poppler invocation. A malformed
 *  document must not pin a worker forever. */
const RENDER_TIMEOUT_MS = Number(process.env.DOCUMENT_RENDER_TIMEOUT_MS) || 120_000;
/** Upper bound on an accepted document. Mirrors the API's upload limit. */
const MAX_BODY_BYTES = Number(process.env.DOCUMENT_RENDER_MAX_BYTES) || 100 * 1024 * 1024;
/** Rasterization defaults — tuned for on-screen preview, not print. */
const PAGES_DEFAULT_DPI = Number(process.env.DOCUMENT_PAGES_DPI) || 110;
const PAGES_DEFAULT_MAX = Number(process.env.DOCUMENT_PAGES_MAX) || 50;
const PAGES_MAX_CEILING = 200;

const app = express();

app.use(
  express.raw({
    type: ['application/octet-stream', 'application/pdf', 'application/*'],
    limit: MAX_BODY_BYTES,
  }),
);

if (!internalServiceAuthEnabled()) {
  logger.warn('CODEAPI_INTERNAL_SERVICE_TOKEN is not set; document renderer routes are unauthenticated');
}

/** Every `/internal/*` route is service-to-service only. */
function requireInternalAuth(
  req: express.Request,
  res: express.Response,
  next: express.NextFunction,
): void {
  if (internalServiceAuthEnabled() && !isAuthorizedInternalServiceRequest(req)) {
    res.status(401).json({ error: 'unauthorized' });
    return;
  }
  next();
}

/**
 * Run a render in a private scratch directory that is always removed, even on
 * failure — a leaked temp dir per request would exhaust the tmpfs.
 */
async function withScratchDir<T>(fn: (dir: string) => Promise<T>): Promise<T> {
  const dir = await fs.mkdtemp(path.join(process.env.DOCUMENT_RENDER_TMPDIR ?? tmpdir(), 'render-'));
  try {
    return await fn(dir);
  } finally {
    await fs.rm(dir, { recursive: true, force: true }).catch(() => undefined);
  }
}

/**
 * Convert any LibreOffice-supported document to PDF.
 *
 * `-env:UserInstallation` gives each invocation its own profile dir: without
 * it concurrent LibreOffice processes contend on a single shared profile and
 * silently serialize (or deadlock).
 */
async function convertToPdf(
  input: Buffer,
  filename: string,
  signal?: AbortSignal,
): Promise<Buffer> {
  return withScratchDir(async (dir) => {
    const safeName = path.basename(filename) || 'document';
    const inputPath = path.join(dir, safeName);
    await fs.writeFile(inputPath, input);

    await execFileAsync(
      'soffice',
      [
        `-env:UserInstallation=file://${path.join(dir, 'profile')}`,
        '--headless',
        '--norestore',
        '--invisible',
        '--convert-to',
        'pdf',
        '--outdir',
        dir,
        inputPath,
      ],
      /* `signal` kills the child when the caller goes away. Without it an
       * abandoned conversion keeps a LibreOffice process (and a CPU) busy until
       * its own timeout — under load that is how a renderer fills up with work
       * nobody is waiting for. */
      { timeout: RENDER_TIMEOUT_MS, maxBuffer: 32 * 1024 * 1024, signal },
    );

    const produced = path.join(dir, `${path.parse(safeName).name}.pdf`);
    return fs.readFile(produced);
  });
}

/** Page count via poppler; `null` when pdfinfo cannot parse the file. */
async function pdfPageCount(pdfPath: string): Promise<number | null> {
  try {
    const { stdout } = await execFileAsync('pdfinfo', [pdfPath], { timeout: 30_000 });
    const match = stdout.match(/^Pages:\s+(\d+)/m);
    return match ? Number(match[1]) : null;
  } catch {
    return null;
  }
}

type RenderedPage = {
  page: number;
  width: number;
  height: number;
  image_base64: string;
  text: string;
};

/**
 * Rasterize a PDF into per-page JPEGs plus extracted text ("rendered-native"
 * previews). Capped at `maxPages` so a 1,000-page upload cannot blow up the
 * response or the worker.
 */
async function renderPages(
  input: Buffer,
  opts: { dpi: number; maxPages: number },
  signal?: AbortSignal,
): Promise<{ pages: RenderedPage[]; totalPages: number; truncated: boolean }> {
  return withScratchDir(async (dir) => {
    const pdfPath = path.join(dir, 'source.pdf');
    await fs.writeFile(pdfPath, input);

    const totalPages = (await pdfPageCount(pdfPath)) ?? 0;
    const limit = Math.min(opts.maxPages, PAGES_MAX_CEILING);
    const renderCount = totalPages > 0 ? Math.min(totalPages, limit) : limit;

    await execFileAsync(
      'pdftoppm',
      ['-jpeg', '-r', String(opts.dpi), '-f', '1', '-l', String(renderCount), pdfPath, path.join(dir, 'page')],
      { timeout: RENDER_TIMEOUT_MS, maxBuffer: 64 * 1024 * 1024, signal },
    );

    const files = (await fs.readdir(dir))
      .filter((f) => f.startsWith('page') && f.endsWith('.jpg'))
      .sort();

    const pages: RenderedPage[] = [];
    for (let i = 0; i < files.length; i++) {
      /* Per-page loop: re-check between pages so an abandoned 200-page job
       * stops at the next boundary instead of rasterizing to completion. */
      if (signal?.aborted) {
        throw Object.assign(new Error('aborted'), { name: 'AbortError' });
      }
      const pageNumber = i + 1;
      const imageBuffer = await fs.readFile(path.join(dir, files[i]));
      let text = '';
      try {
        const { stdout } = await execFileAsync(
          'pdftotext',
          ['-f', String(pageNumber), '-l', String(pageNumber), pdfPath, '-'],
          { timeout: 30_000, maxBuffer: 8 * 1024 * 1024, signal },
        );
        text = stdout;
      } catch {
        /* Text extraction is best-effort: a scanned page legitimately has none,
         * and the image alone is still a valid preview. */
      }
      pages.push({
        page: pageNumber,
        width: 0,
        height: 0,
        image_base64: imageBuffer.toString('base64'),
        text,
      });
    }

    return {
      pages,
      totalPages: totalPages || pages.length,
      truncated: totalPages > pages.length,
    };
  });
}

/**
 * Tie a render to the life of its request.
 *
 * When the caller disconnects — the user closed the preview, the API gave up,
 * a load balancer cut the connection — the work becomes garbage the moment it
 * is abandoned. Aborting kills the LibreOffice/poppler child immediately
 * instead of letting it run to its own timeout, which is what keeps a renderer
 * under load from filling with conversions nobody is waiting for.
 *
 * `res.on('close')` fires on normal completion too, so the listener is removed
 * once the handler settles; only a close BEFORE completion aborts.
 */
function abortOnDisconnect(req: express.Request, res: express.Response): {
  signal: AbortSignal;
  done: () => void;
} {
  const controller = new AbortController();
  const onClose = (): void => {
    if (res.writableEnded) {
      return;
    }
    logger.info('document_render_client_disconnected');
    controller.abort();
  };
  /* ONLY `res` — `req` emits 'close' when its stream finishes being read,
   * which is the normal path for a body upload rather than a disconnect. */
  res.on('close', onClose);
  return {
    signal: controller.signal,
    done: () => {
      res.off('close', onClose);
    },
  };
}

/** True when a render ended because the caller went away, not because it failed. */
function isAbort(error: unknown): boolean {
  const name = (error as { name?: string } | undefined)?.name;
  return name === 'AbortError' || (error as { code?: string } | undefined)?.code === 'ABORT_ERR';
}

app.post('/internal/documents/preview', requireInternalAuth, async (req, res) => {
  const filename = String(req.query.filename ?? 'document');
  const started = Date.now();
  const { signal, done } = abortOnDisconnect(req, res);
  try {
    const pdf = await convertToPdf(req.body as Buffer, filename, signal);
    logger.info('document_render_pdf', { filename, bytes: pdf.length, ms: Date.now() - started });
    res.setHeader('content-type', 'application/pdf');
    res.status(200).send(pdf);
  } catch (error) {
    if (isAbort(error)) {
      logger.info('document_render_pdf_aborted', { filename, ms: Date.now() - started });
      return;
    }
    logger.error('document_render_pdf_failed', { filename, error: String(error) });
    res.status(422).json({ error: 'render_failed', message: 'Could not convert document to PDF.' });
  } finally {
    done();
  }
});

app.post('/internal/documents/pages', requireInternalAuth, async (req, res) => {
  const dpi = Number(req.query.dpi) || PAGES_DEFAULT_DPI;
  const maxPages = Number(req.query.max_pages) || PAGES_DEFAULT_MAX;
  const started = Date.now();
  const { signal, done } = abortOnDisconnect(req, res);
  try {
    const result = await renderPages(req.body as Buffer, { dpi, maxPages }, signal);
    logger.info('document_render_pages', {
      pages: result.pages.length,
      total: result.totalPages,
      ms: Date.now() - started,
    });
    res.status(200).json(result);
  } catch (error) {
    if (isAbort(error)) {
      logger.info('document_render_pages_aborted', { ms: Date.now() - started });
      return;
    }
    logger.error('document_render_pages_failed', { error: String(error) });
    res.status(422).json({ error: 'render_failed', message: 'Could not rasterize PDF.' });
  } finally {
    done();
  }
});

app.get('/health', (_req, res) => {
  res.status(200).send('OK');
});

/** Readiness proves the external binaries are actually present and runnable —
 *  a missing LibreOffice must fail the probe, not the first user request. */
app.get('/ready', async (_req, res) => {
  try {
    await execFileAsync('soffice', ['--version'], { timeout: 30_000 });
    await execFileAsync('pdftoppm', ['-v'], { timeout: 10_000 });
    res.status(200).send('READY');
  } catch (error) {
    logger.error('document_renderer_not_ready', { error: String(error) });
    res.status(503).send('NOT_READY');
  }
});

const server = app.listen(PORT, () => {
  logger.info(`Document renderer listening on ${PORT}`, { instance: nanoid(6) });
});

function shutdown(signal: string): void {
  logger.info(`Document renderer received ${signal}, shutting down`);
  server.close(() => process.exit(0));
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

export { app, convertToPdf, renderPages };
