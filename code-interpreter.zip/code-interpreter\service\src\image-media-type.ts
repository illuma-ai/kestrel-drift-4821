/**
 * UPSTREAM DELTA — vision-ingestible image detection.
 *
 * A harvested file that carries a `media_type` AND a fetchable `view_url` is
 * turned by the host into a vision content block on the tool message, so the
 * model SEES a generated chart or slide render instead of being told a binary
 * file exists. Without both fields the host falls back to text-only, which is
 * what made "0 image(s)" appear for runs that had in fact produced images.
 *
 * Detection is by extension: fast, deterministic, and sufficient for
 * sandbox-emitted artefacts where the producing code chooses the name.
 * Magic-byte sniffing would be more robust but costs a read of every output
 * file purely to classify it.
 */

import path from 'node:path';

/**
 * Image types vision encoders consistently accept — the common intersection
 * across major providers.
 *
 * SVG is deliberately excluded: it is text/XML, does not go through the vision
 * encoder, and providers reject it.
 */
const EXTENSION_TO_MEDIA_TYPE: ReadonlyMap<string, string> = new Map([
  ['.png', 'image/png'],
  ['.jpg', 'image/jpeg'],
  ['.jpeg', 'image/jpeg'],
  ['.gif', 'image/gif'],
  ['.webp', 'image/webp'],
]);

/**
 * The canonical image MIME for `name`, or `undefined` when it is not a
 * vision-supported image.
 *
 * @param name - File name or path; only the extension is inspected.
 */
export function detectImageMediaType(name: string): string | undefined {
  return EXTENSION_TO_MEDIA_TYPE.get(path.extname(name).toLowerCase());
}

/** Whether `name` is worth minting a view URL for. */
export function isViewableImage(name: string): boolean {
  return detectImageMediaType(name) !== undefined;
}
