# Changelog

Fork-owned changes to this repository. Upstream
(ClickHouse/code-interpreter) history is not restated here — only what this fork
adds, changes, or carries on top of it. See `docs/upstream-deltas.md` for the
standing delta inventory and the rationale behind each one.

Format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

## [Unreleased]

### Upstream merge (2026-09-19, upstream/main @ 277fa77, 14 commits)

One conflicted file, `service/src/file-server.ts`, and it was the dangerous kind. Upstream
extracted `createMinioClient` into a new `service/src/minio-client.ts` (adding an 8 MiB
multipart `partSize` so unknown-length streams stop growing SDK parts to 528 MiB). The
fork's two S3 authentication deltas lived INSIDE that function: the IMDSv2 instance-role
branch, and the empty `accessKey`/`secretKey` placeholders without which the SDK throws
before it ever consults a credentials provider. The new module arrived with neither and
with no conflict of its own. Both are re-homed there on top of upstream's version, and two
new tests pin them so the next extraction cannot drop them quietly.

Brings: registration and inspection of local coding projects, bounded repository
instruction discovery for attached workspaces, per-repository GitHub App credential
routing, workspace admission capacity reported without ambiguous timeout errors, the
input-file limit forwarded into sandbox guests, bounded memory for streamed uploads, and
Lambda MicroVM metadata allowed in hardened mode.

### Upstream merge (2026-09-16, upstream/main @ 840537b, 101 commits)

Nine conflicted files, all in `service/src`. The fork's delta is additive by design, so the
document-preview, vision-block and IMDSv2 files did not conflict at all.

- **Adopted upstream's rewritten egress ledger.** Upstream replaced the WATCH/MULTI record
  mutation with a single-key Lua script (`egress-ledger-script.ts`) that serializes admission
  against revocation and works on Redis Cluster, plus an optional compact hash representation
  (`CODEAPI_EGRESS_LEDGER_COMPACT`). The fork's ~200-line implementation is gone; only its two
  real deltas were grafted onto upstream's: `readEgressLedgerRecord` and the
  `compact_scope_missing` diagnosis that tells an operational ledger loss apart from an ordinary
  authorization rejection.
- **Kept the compact GRANT delta, and made it cheaper.** Upstream's `checkEgressGrantActive`
  deliberately authorizes without returning the large input policy. Hydration now happens only
  for a token that is actually compact (`scope_ref === 'ledger'`), so an ordinary grant keeps
  upstream's cheap path instead of always paying for the record read. Hydrating with the ledger
  disabled now fails loudly rather than authorizing against empty arrays.
- **Two compact-grant flags now coexist:** the fork's `EGRESS_COMPACT_GRANTS` (how a TOKEN is
  sealed, to keep the sandbox's download header under the HTTP size limit) and upstream's
  `EGRESS_LEDGER_COMPACT` (how the RECORD is stored in Redis). They are independent.
- **Fixed, found by the gate:** the fork's six compact-grant gateway tests still constructed
  `ioredis-mock`, which upstream removed - the ledger now runs a Lua script the mock cannot
  execute. They run on the same real `startTestRedis()` harness as every other ledger test.

Gate: 1096 pass / 1 fail against a pre-merge baseline of 614 pass / 1 fail, the single failure in
both being the k6 stress script, which needs the k6 runtime. Run in a Linux container because the
ledger suites need a real `redis-server` binary that the Windows dev box cannot provide.


### Added

- **`pymupdf` preinstalled in the Python sandbox runtime** (both package
  builders). Document-extraction skills prefer PyMuPDF for positional page
  text; it was absent while the sandbox (by design) has no route to PyPI, so
  models burned turns retrying `pip install` before falling back to `pypdf`.
  Preloading makes the preferred path deterministic and offline.

### Fixed

- **Skill-heavy jobs no longer fail code execution with a bare `HTTP error:
  431`.** A job priming 30+ files from a skill session (a real trigger:
  `skills/pptx/...` reference bundles) sealed an egress grant token past the
  HTTP server's ~16KB header limit — the header rides every sandbox download
  request, and the server rejected the request pre-handler with 431, so
  nothing in the chain could log or surface a real reason; users saw only
  "Code execution is temporarily unavailable." The grant's file scope
  (`input_files`/`read_sessions`) now lives in the egress ledger (Redis)
  instead of the token itself whenever the ledger is guaranteed to exist —
  the gateway hydrates it back before running the same per-file
  authorization checks as before, so nothing about what is authorized
  changes, only where the scope is read from. A grant whose ledger record
  has gone missing now fails with a distinct `compact_scope_missing` reason
  (was indistinguishable from a generic `scope_mismatch`) and a log line
  naming the grant and the ledger. Guarded by
  `CODEAPI_EGRESS_COMPACT_GRANTS` (default on wherever the ledger is
  required; `=false` rolls back to the pre-fix fat token without a rebuild,
  e.g. during a mixed-version rollout where older gateway replicas cannot
  hydrate a compact grant's scope); legacy fat tokens are unaffected and
  keep working unconditionally. See
  [`docs/egress-grant-scope.md`](docs/egress-grant-scope.md).
- **The single-host deployment now actually runs.** `deploy/` had never been
  executed end to end, so it carried mismatches that only surface on a real
  host — each fatal, and each masked by a misleading symptom.
  - *Image vs. command.* The workflow builds `--target production`, which ships
    only `node_modules` and `.build/file-server.js`, while the compose asked
    four services to run TypeScript from `src/` and one to run `.build-api/`.
    One command named `src/worker.ts`, a path that has never existed in this
    repo. Adds a `deployed` image stage carrying all four role bundles plus
    `src`, and repoints every command at what the image ships.
  - *Sandbox isolation.* NsJail's `clone(CLONE_NEW*)` is filtered by Docker's
    default seccomp profile, so the runner failed `EINVAL` and never became
    healthy. Applies the shipped `seccomp/nsjail.json` and the `/dev/kvm` stub,
    matching upstream's own no-KVM overlay. gVisor was evaluated and cannot
    work: it sandboxes a process, so it cannot host one that creates namespaces.
  - *Hardened mode.* Wires the execution-manifest keypair (private half only on
    the worker) and scopes the egress grant secret to the worker and gateway —
    the api refuses to start while holding it.
  - *Auth.* Replaces a non-existent "API-key mode" with real JWT verification;
    `getAuthProviderMode()` accepts only `librechat-jwt` or `none`, and refuses
    `none` outside local mode.
  - *S3 identity.* See below.
- **S3 authentication over IMDSv2.** `MINIO_USE_IRSA=true` selected the IAM
  branch, but its provider speaks IMDSv1, which an instance with
  `HttpTokens=required` answers with 401 — surfacing as `accessKey should be of
  type "string"` in an ever-widening retry loop while the file server reported
  itself Up. Adds an IMDSv2 credentials provider for the EC2 case, so IMDSv2
  stays enforced and no long-lived key is written to the host. The alternatives
  (relaxing to IMDSv1, or a static key on disk) were both rejected on a host
  that exists to run untrusted code.

  Verified on the dev host, 5/5: authenticated exec; a 52-page PDF rendering 52
  pages through `/v1/documents/pages` — the retired executor rendered 0 for
  every document, silently, which is what motivated this migration; 12/12
  concurrent execs where the old service shed load at 8; and a flat container
  count across the burst where the old one leaked orphans indefinitely.

### Added

- **Hosted-convention path aliases for the document skills.** The per-job NsJail
  overlay now also binds `/mnt/skills` (at the injected bundle) and
  `/mnt/user-data` (at the workspace root). The skills are authored against the
  hosted layout, so every document task began by probing a path that does not
  exist, failing, and recovering with a `find /` sweep — two wasted tool calls
  and a wrong error shown to the user. Fixing the sandbox rather than the skills
  keeps them updatable upstream. The `/mnt/skills` bind is emitted only when a
  bundle is present, because NsJail materializes a bind with a missing source as
  an empty regular file.

### Fixed

- **`npm` no longer stalls a bash execution against closed egress.** Offline mode
  was written to the Node runtime's `.env`, which is not read when the skills
  shell out to `npm` from a *bash* call — so `npm install -g` retried an
  unreachable registry until the job timeout (~5 min), burning a worker slot.
  The same settings now also go to `$prefix/etc/npmrc`, which npm reads for every
  invocation regardless of calling runtime. A missing package now fails in
  seconds with `ENOTCACHED`.

- **Image outputs are returned as vision blocks, not a text mention.**
  `/v1/exec` now annotates image files it harvests with `media_type` and a
  short-lived `view_url` (`GET /sessions/:id/objects/:id/view-url` on the file
  server presigns it). The host inlines a file into the tool message as a vision
  content block only when a ref carries *both* fields; without them a generated
  chart or slide render came back to the model as the sentence
  `Image: /mnt/data/slide-1.jpg (83559 bytes, image/jpeg)` — told it existed,
  never shown it. Applies to PNG/JPEG/GIF/WebP; SVG is excluded because
  providers reject it as a vision block. Annotation happens in the API tier
  (the only tier wired to the file server), is capped per result, and can never
  fail an execution — an unreachable file server degrades to the upstream shape.

- **Document preview rendering.** `POST /v1/documents/preview` converts office
  documents (Word/Excel/PowerPoint/ODF) to PDF, and `POST /v1/documents/pages`
  rasterizes a PDF into per-page images plus extracted text. Both accept a
  stored-object reference or a multipart upload, and persist their output as a
  normal stored object retrievable through `GET /v1/download/:session_id/:file_id`.
  Implemented as a stateless `document_renderer` sidecar (LibreOffice + poppler)
  that holds no credentials and no storage access, so the upstream sandbox image
  stays byte-identical. Replaces the retired in-house executor's `/render/pdf`
  and `/render/pages`, which named neither the domain nor the produced artifact
  and sat at the API root beside code-execution routes.
- **`docker-compose.fork.yml`** — local/deployed overlay that points file
  storage at real S3 instead of the bundled MinIO (platform rule: file storage
  is S3 everywhere, including local dev) and adds the `document_renderer`
  service.
- **Fork documentation** — `CLAUDE.md` (branch model, local bring-up, host
  contract), `docs/upstream-deltas.md` (delta inventory), and this changelog.
- **Deploy pipeline** — `deploy/docker-compose.deployed.yml` (seven services
  from ECR, S3 storage, sandbox concurrency/timeout/reaper bounds, published on
  the port the host platform already targets) and a manual-only
  `deploy-dev.yml` workflow that builds, ships the compose over SSM, and then
  proves the deployment can execute code before reporting success.
- **Sandbox toolchain** — `tesseract-ocr` (pytesseract shipped but was inert
  without its binary), `fonts-noto-core`, and the `pypdf` / `pdfplumber` Python
  packages the document skills import.
- **Client-disconnect abort** — an abandoned render now aborts and kills its
  LibreOffice/poppler child instead of running to its own timeout, matching how
  `/v1/exec` drops a job when its caller disappears.

### Fixed

- **Windows checkouts produced unusable container images.** `.gitattributes` now
  pins `eol=lf` for `*.sh`, `Dockerfile*`, `*.rs`, `*.py`, `*.toml`, `*.conf`,
  and `pre-commit`. With `core.autocrlf=true` these were rewritten to CRLF, so
  the container shebang parsed as `#!/bin/bash\r` and Docker failed with the
  misleading `exec /usr/local/bin/entrypoint.sh: no such file or directory`.
  Not fork-specific — offer this upstream.

### Notes

- This repository supersedes the in-house `code-executor-v2`, which existed only
  because the official engine was not public. Capabilities we previously
  maintained ourselves — JWT per-user isolation, Programmatic Tool Calling, warm
  sandbox sessions, egress control — are native upstream and are configured, not
  forked.
- **LibreOffice does not run inside the sandbox.** It was added, built and
  tested: `soffice` aborts with a UNO `RuntimeException` before converting,
  because the sandbox exposes no `/dev/shm` and NsJail blocks the rest. Skill
  code must not shell out to it; anything needing a rendition calls the preview
  endpoint, which is what the renderer sidecar exists for.
- Runtime `pip install` / `npm install` inside a sandbox cannot work — egress is
  gated by design. Packages must be added to `docker/package-init.sh` or
  `javascript-packages.txt` and the runtime volume repopulated.
