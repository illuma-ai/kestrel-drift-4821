#!/usr/bin/env python3
"""Render /opt/code-interpreter/.env from the runtime secret.

Runs ON the deploy host. Pulls a JSON secret from Secrets Manager and writes it
as the env file docker compose reads, so configuration changes are a secret
update plus a redeploy rather than an image rebuild.

Why a script rather than a shell one-liner: two of the values are shaped in ways
that break naive rendering, and both cost a debugging cycle when they were being
hand-maintained.

  * The JWT public key is a PEM. `docker compose` rejects a multi-line value, so
    it has to be one line with literal backslash-n escapes -- which the verifier
    un-escapes before parsing. A stored value containing real newlines would
    silently produce an unparseable env file.
  * Any value can contain `/`, `+` or `=` (base64, PEM bodies). Writing
    `KEY=$VALUE` through a shell risks word-splitting and expansion; writing it
    from Python does not.

Usage:  render-env.py <secret-id> <output-path> [KEY=VALUE ...]

Trailing KEY=VALUE pairs are applied last, so the deploy can pin IMAGE_TAG to
the tag it just built without that tag living in the secret.
"""
import json
import os
import re
import subprocess
import sys

VALID_KEY = re.compile(r"^[A-Za-z_][A-Za-z0-9_]*$")


def fetch(secret_id: str) -> dict:
    """Read the secret with the host's own identity (instance role)."""
    proc = subprocess.run(
        [
            "aws", "secretsmanager", "get-secret-value",
            "--secret-id", secret_id,
            "--query", "SecretString",
            "--output", "text",
        ],
        capture_output=True, text=True,
    )
    if proc.returncode != 0:
        sys.exit("failed to read secret {}: {}".format(secret_id, proc.stderr.strip()[:300]))
    try:
        data = json.loads(proc.stdout)
    except json.JSONDecodeError as exc:
        sys.exit("secret {} is not JSON: {}".format(secret_id, exc))
    if not isinstance(data, dict):
        sys.exit("secret {} must be a flat JSON object".format(secret_id))
    return data


def main() -> None:
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    secret_id, out_path = sys.argv[1], sys.argv[2]

    values = {str(k): v for k, v in fetch(secret_id).items()}

    for override in sys.argv[3:]:
        if "=" not in override:
            sys.exit("override {!r} is not KEY=VALUE".format(override))
        key, _, val = override.partition("=")
        values[key] = val

    lines = []
    skipped = []
    for key, raw in sorted(values.items()):
        if not VALID_KEY.match(key):
            skipped.append(key)
            continue
        if raw is None:
            continue
        val = raw if isinstance(raw, str) else json.dumps(raw)
        # Collapse any real newlines to the literal escape compose can carry.
        val = val.replace("\r\n", "\n").replace("\n", "\\n")
        lines.append("{}={}".format(key, val))

    tmp = out_path + ".tmp"
    with open(tmp, "w", encoding="utf-8", newline="\n") as fh:
        fh.write("\n".join(lines) + "\n")
    os.chmod(tmp, 0o600)
    os.replace(tmp, out_path)

    print("rendered {} keys to {}".format(len(lines), out_path))
    print("keys: {}".format(" ".join(sorted(k.split("=", 1)[0] for k in lines))))
    if skipped:
        print("skipped (not valid env names): {}".format(" ".join(skipped)))


if __name__ == "__main__":
    main()
