/**
 * UPSTREAM DELTA — regression tests for the document preview routes.
 *
 * These cover the contract seams that broke during the port and would break
 * silently again: the storage key/name split, format inference from the
 * original filename rather than the opaque object id, and PDF passthrough.
 */

import { describe, expect, test } from 'bun:test';

/**
 * Mirrors the object-id derivation in `storeDocument`.
 *
 * Stored objects are addressed by an opaque id and the download route rejects a
 * dotted path segment outright, so a rendition must never be stored under its
 * filename. Regression: storing `report.pdf` as the id produced the key
 * `report.pdf.pdf`, because the file server appends the extension it reads from
 * `x-original-filename`.
 */
function storageIdFor(filename: string): string {
  return filename.replace(/\.[^./]+$/, '');
}

/** Mirrors `extensionOf` in the router. */
function extensionOf(name: string): string {
  const idx = name.lastIndexOf('.');
  return idx === -1 ? '' : name.slice(idx + 1).toLowerCase();
}

/** Mirrors the rendition naming in the PDF route. */
function pdfNameFor(sourceFilename: string): string {
  return `${sourceFilename.replace(/\.[^.]+$/, '')}.pdf`;
}

describe('documents router — storage key derivation', () => {
  test('strips the extension so the file server does not double-append it', () => {
    expect(storageIdFor('report.pdf')).toBe('report');
    expect(storageIdFor('quarterly.docx')).toBe('quarterly');
  });

  test('leaves an extensionless name untouched', () => {
    expect(storageIdFor('report')).toBe('report');
  });

  test('does not strip past a path separator', () => {
    expect(storageIdFor('a.b/report')).toBe('a.b/report');
  });
});

describe('documents router — format inference', () => {
  test('infers the source format from the original filename', () => {
    expect(extensionOf('quarterly.DOCX')).toBe('docx');
    expect(extensionOf('sheet.xlsx')).toBe('xlsx');
  });

  /**
   * A by-reference request carries the opaque storage id, which has no
   * extension — the router must resolve the original filename from metadata
   * first, or every stored document is treated as an unknown format.
   */
  test('an opaque object id yields no format', () => {
    expect(extensionOf('T0IoeuOyit7jDTDYgFM4a')).toBe('');
  });
});

describe('documents router — rendition naming', () => {
  test('swaps the source extension for .pdf', () => {
    expect(pdfNameFor('report.docx')).toBe('report.pdf');
    expect(pdfNameFor('deck.pptx')).toBe('deck.pdf');
  });

  test('appends .pdf when the source has no extension', () => {
    expect(pdfNameFor('report')).toBe('report.pdf');
  });
});

/**
 * Regression: a rendition rendered fine and was then unreachable.
 *
 * `sessionAuth` on the download route compares the caller's session key against
 * a `session:<session_id>` entry in Redis. `/exec` writes that binding for every
 * session it creates; the document routes create their own session for an
 * upload-and-render call, so they must write it too — otherwise the cached key
 * reads null, every download 403s, and the UI shows "Preview unavailable".
 */
describe('documents router — session binding', () => {
  const SESSION_CACHE_TTL = 900;

  /** Mirrors the key writes in `storeDocument`. */
  function cacheWrites(sessionKey: string, sessionId: string, objectId: string) {
    return [
      { key: `upload:${sessionKey}${sessionId}${objectId}`, value: '1', ttl: SESSION_CACHE_TTL },
      { key: `session:${sessionId}`, value: sessionKey, ttl: SESSION_CACHE_TTL },
    ];
  }

  test('binds the session to its owning bucket so downloads authorize', () => {
    const writes = cacheWrites('local:user:alice', 'sess-1', 'obj-1');
    const binding = writes.find((w) => w.key === 'session:sess-1');
    expect(binding).toBeDefined();
    expect(binding?.value).toBe('local:user:alice');
  });

  test('also marks the object present for the download existence check', () => {
    const writes = cacheWrites('local:user:alice', 'sess-1', 'obj-1');
    expect(writes.some((w) => w.key === 'upload:local:user:alicesess-1obj-1')).toBe(true);
  });

  test('both cache entries carry a TTL so nothing leaks', () => {
    for (const write of cacheWrites('local:user:alice', 'sess-1', 'obj-1')) {
      expect(write.ttl).toBeGreaterThan(0);
    }
  });
});

/**
 * A document submitted for preview is the same class of user-supplied payload
 * as one submitted for execution, so it must respect the caller's plan tier.
 * Without this a plan-capped tenant could bypass their allowance by uploading
 * through the preview path instead of the upload path.
 */
describe('documents router — plan size limits', () => {
  const SERVICE_CEILING = 100 * 1024 * 1024;

  /** Mirrors `documentSizeLimit`. */
  function limitFor(planLimit: number | undefined): number {
    return Math.min(planLimit ?? SERVICE_CEILING, SERVICE_CEILING);
  }

  test('a plan smaller than the service ceiling wins', () => {
    expect(limitFor(5 * 1024 * 1024)).toBe(5 * 1024 * 1024);
  });

  test('a plan larger than the service ceiling is clamped', () => {
    expect(limitFor(500 * 1024 * 1024)).toBe(SERVICE_CEILING);
  });

  test('an unknown plan falls back to the service ceiling', () => {
    expect(limitFor(undefined)).toBe(SERVICE_CEILING);
  });
});

/**
 * A preview the caller walked away from is wasted work. `/exec` removes its job
 * on client disconnect; the document routes must abort theirs, which propagates
 * to the renderer and kills the LibreOffice/poppler child instead of letting it
 * run to its own timeout.
 */
describe('documents router — client disconnect', () => {
  /** Mirrors `abortOnDisconnect`. */
  function abortOnDisconnect(res: { writableEnded: boolean; handlers: Array<() => void> }) {
    const controller = new AbortController();
    const onClose = () => {
      if (!res.writableEnded) controller.abort();
    };
    res.handlers.push(onClose);
    return {
      signal: controller.signal,
      fireClose: () => res.handlers.forEach((h) => h()),
    };
  }

  test('aborts when the response closes before completion', () => {
    const res = { writableEnded: false, handlers: [] as Array<() => void> };
    const { signal, fireClose } = abortOnDisconnect(res);
    expect(signal.aborted).toBe(false);
    fireClose();
    expect(signal.aborted).toBe(true);
  });

  test('does NOT abort when the response already completed normally', () => {
    const res = { writableEnded: true, handlers: [] as Array<() => void> };
    const { signal, fireClose } = abortOnDisconnect(res);
    fireClose();
    expect(signal.aborted).toBe(false);
  });

  /** An abort is an expected outcome, so it must not be logged/handled as a
   *  render failure or turned into a 4xx for a caller that is already gone. */
  test('recognizes both abort error shapes', () => {
    const isAbort = (e: unknown): boolean => {
      const err = e as { name?: string; code?: string } | undefined;
      return err?.name === 'AbortError' || err?.code === 'ERR_CANCELED' || err?.code === 'ABORT_ERR';
    };
    expect(isAbort({ name: 'AbortError' })).toBe(true);
    expect(isAbort({ code: 'ERR_CANCELED' })).toBe(true);
    expect(isAbort({ code: 'ABORT_ERR' })).toBe(true);
    expect(isAbort(new Error('libreoffice exploded'))).toBe(false);
  });
});

describe('documents router — passthrough', () => {
  const PASSTHROUGH_FORMATS = new Set(['pdf']);

  test('a PDF source skips conversion', () => {
    expect(PASSTHROUGH_FORMATS.has(extensionOf('already.pdf'))).toBe(true);
  });

  test('office formats are converted', () => {
    for (const name of ['a.docx', 'b.xlsx', 'c.pptx', 'd.odt']) {
      expect(PASSTHROUGH_FORMATS.has(extensionOf(name))).toBe(false);
    }
  });
});
