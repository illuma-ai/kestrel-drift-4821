/**
 * UPSTREAM DELTA — document preview routes (`/v1/documents/*`).
 *
 * The host platform previews uploaded Word/Excel/PowerPoint/ODF files
 * page-perfectly: the document is converted to PDF once, and the client paints
 * that PDF. These routes own the request contract, authentication, and
 * persistence; the actual transcoding runs in the stateless
 * `document-renderer` sidecar (see `service/src/document-renderer.ts`).
 *
 * Naming: these replace the fork's earlier `POST /render/pdf` and
 * `POST /render/pages`. "Render" alone said nothing about *what* was rendered,
 * and sat at the API root next to code-execution routes. The document-preview
 * domain now has its own namespace, and each route is named for the OUTCOME it
 * serves rather than the file format it happens to emit — PDF is the transport
 * for a preview, not the contract, so the path does not name it:
 *
 *   POST /v1/documents/preview — a previewable rendition of a document
 *   POST /v1/documents/pages   — per-page images + text of a document
 *
 * Both accept either shape:
 *   * by reference — JSON `{ session_id, file_id }` for a document already in
 *     storage (e.g. an output harvested from a prior `/v1/exec`), or
 *   * upload-and-render — multipart `file`, stored first so the rendition and
 *     its source are both retrievable afterwards.
 *
 * A preview failure must never break the surrounding upload/execution flow, so
 * unsupported or corrupt documents return a 4xx the caller can degrade on
 * rather than a 500.
 */

import axios from 'axios';
import busboy from 'busboy';
import { nanoid } from 'nanoid';
import { Router } from 'express';
import type { Response } from 'express';
import type * as t from '../types';
import { checkServiceShutDown, checkServiceStartUp } from '../lifecycle';
import { uploadLimiter } from '../middleware/limits';
import { internalServiceHeaders } from '../internal-service-auth';
import { resolveOutputBucketSessionKey } from '../session-key';
import { connection } from '../queue';
import { getPrincipalOrReject } from '../auth/principal';
import { env, planLimits } from '../config';
import { getAxiosErrorDetails } from '../utils';
import logger from '../logger';

const router = Router();

const RENDERER_URL = process.env.DOCUMENT_RENDERER_URL ?? 'http://document_renderer:3060';
const RENDER_TIMEOUT_MS = Number(process.env.DOCUMENT_RENDER_TIMEOUT_MS) || 120_000;
/** Service-wide ceiling. The effective limit is the smaller of this and the
 *  caller's plan allowance — see {@link documentSizeLimit}. */
const MAX_DOCUMENT_BYTES = Number(process.env.DOCUMENT_RENDER_MAX_BYTES) || 100 * 1024 * 1024;

/**
 * Largest document this caller may render.
 *
 * Mirrors the upload routes: a tenant's plan tier caps file size, and a
 * document submitted for preview is the same class of user-supplied payload as
 * one submitted for execution. Without this a plan-capped tenant could bypass
 * their allowance through the preview path.
 */
function documentSizeLimit(req: t.AuthenticatedRequest): number {
  const planLimit =
    planLimits[req.planId ?? '']?.max_file_size ?? planLimits.default.max_file_size;
  return Math.min(planLimit ?? MAX_DOCUMENT_BYTES, MAX_DOCUMENT_BYTES);
}

/** Formats LibreOffice converts. A PDF source is passthrough (already a PDF),
 *  so it never reaches the renderer. */
const PASSTHROUGH_FORMATS = new Set(['pdf']);

type DocumentSource = {
  sessionId: string;
  /** Storage key of the source object (opaque id for stored files). */
  fileId: string;
  /** Human name the format is inferred from — may differ from `fileId`. */
  filename: string;
  bytes: Buffer;
};

function extensionOf(fileId: string): string {
  const idx = fileId.lastIndexOf('.');
  return idx === -1 ? '' : fileId.slice(idx + 1).toLowerCase();
}

/** Fetch an already-stored document's bytes from the file server. */
async function fetchStoredDocument(
  sessionId: string,
  fileId: string,
  maxBytes: number,
): Promise<Buffer> {
  const response = await axios({
    method: 'get',
    url: `${env.FILE_SERVER_URL}/sessions/${sessionId}/objects/${fileId}`,
    headers: internalServiceHeaders(),
    responseType: 'arraybuffer',
    timeout: RENDER_TIMEOUT_MS,
    /* Bound the read itself so an oversized object is refused mid-transfer
     * rather than after it has been buffered in full. */
    maxContentLength: maxBytes,
    maxBodyLength: maxBytes,
  });
  return Buffer.from(response.data as ArrayBuffer);
}

/**
 * Resolve a stored object's original filename.
 *
 * Stored objects are keyed by an opaque id, so a by-reference request carries
 * no extension — and the extension is what selects the conversion path. The
 * metadata record keeps the name the file was uploaded/harvested under; fall
 * back to the id when metadata is unavailable so a missing record degrades to
 * "unknown format" rather than failing the request.
 */
async function resolveOriginalFilename(sessionId: string, fileId: string): Promise<string> {
  try {
    const response = await axios({
      method: 'get',
      url: `${env.FILE_SERVER_URL}/sessions/${sessionId}/objects/${fileId}/metadata`,
      headers: internalServiceHeaders(),
      timeout: 30_000,
    });
    const meta = response.data as { originalFilename?: string; name?: string };
    return meta.originalFilename || meta.name || fileId;
  } catch {
    return fileId;
  }
}

/** Persist a produced rendition so the caller can retrieve it via
 *  `GET /v1/download/:session_id/:file_id` like any other output. */
/**
 * Persist bytes as a new stored object and return its id.
 *
 * Objects are addressed by an opaque id, never by filename: the download route
 * validates the path segment as an id, so a dotted name like `report.pdf` is
 * rejected outright. The human name travels in `x-original-filename` (which is
 * what metadata reports and what the download serves the file as), exactly
 * like the `{ id, name }` pairs `/v1/exec` returns for harvested outputs.
 */
async function storeDocument(
  sessionId: string,
  filename: string,
  bytes: Buffer,
  sessionKey: string,
  contentType = 'application/octet-stream',
): Promise<string> {
  const objectId = nanoid();
  await axios({
    method: 'put',
    url: `${env.FILE_SERVER_URL}/sessions/${sessionId}/objects/${objectId}`,
    headers: {
      ...internalServiceHeaders(),
      'content-type': contentType,
      'x-original-filename': encodeURIComponent(filename),
    },
    data: bytes,
    timeout: RENDER_TIMEOUT_MS,
    maxBodyLength: Infinity,
    maxContentLength: Infinity,
  });
  await Promise.all([
    /* Mirror the upload path's cache marker so the existing /download route's
     * existence check passes for a rendition it did not itself upload. */
    connection.set(`upload:${sessionKey}${sessionId}${objectId}`, '1', 'EX', env.SESSION_CACHE_TTL),
    /* Bind the session to its owning bucket, exactly as `/exec` does. Without
     * this, `sessionAuth` on the download route reads a null cached key,
     * compares it against the caller's session key, and rejects every fetch of
     * a rendition with 403 — the document renders successfully and is then
     * unreachable. */
    connection.set(`session:${sessionId}`, sessionKey, 'EX', env.SESSION_CACHE_TTL),
  ]);
  return objectId;
}

/**
 * Read the document out of the request: either by reference (JSON body) or from
 * a multipart upload, which is stored before rendering so the source stays
 * retrievable.
 */
async function resolveSource(
  req: t.AuthenticatedRequest,
  sessionKey: string,
): Promise<DocumentSource> {
  const contentType = req.headers['content-type'] ?? '';

  if (!contentType.includes('multipart/form-data')) {
    const body = (req.body ?? {}) as { session_id?: string; file_id?: string };
    if (!body.session_id || !body.file_id) {
      throw Object.assign(new Error('session_id and file_id are required'), { status: 400 });
    }
    const [bytes, filename] = await Promise.all([
      fetchStoredDocument(body.session_id, body.file_id, documentSizeLimit(req)),
      resolveOriginalFilename(body.session_id, body.file_id),
    ]);
    /* A stored object can predate the caller's current plan tier, so the
     * fetched size is checked too — not just the multipart boundary. */
    if (bytes.length > documentSizeLimit(req)) {
      throw Object.assign(new Error('Document exceeds the size limit'), { status: 413 });
    }
    return { sessionId: body.session_id, fileId: body.file_id, filename, bytes };
  }

  const { filename, buffer, sessionId } = await new Promise<{
    filename: string;
    buffer: Buffer;
    sessionId: string;
  }>((resolve, reject) => {
    const bb = busboy({
      headers: req.headers,
      limits: { fileSize: documentSizeLimit(req), files: 1 },
    });
    const chunks: Buffer[] = [];
    let name = 'document';
    let formSessionId: string | undefined;
    let truncated = false;

    bb.on('field', (field, value) => {
      if (field === 'session_id' && value) formSessionId = value;
    });
    bb.on('file', (_field, stream, info) => {
      name = info.filename || 'document';
      stream.on('data', (chunk: Buffer) => chunks.push(chunk));
      stream.on('limit', () => {
        truncated = true;
        stream.resume();
      });
    });
    bb.on('close', () => {
      if (truncated) {
        reject(Object.assign(new Error('Document exceeds the size limit'), { status: 413 }));
        return;
      }
      if (chunks.length === 0) {
        reject(Object.assign(new Error("A file is required (multipart field 'file')"), { status: 400 }));
        return;
      }
      resolve({
        filename: name,
        buffer: Buffer.concat(chunks),
        sessionId: formSessionId ?? nanoid(),
      });
    });
    bb.on('error', reject);
    req.pipe(bb);
  });

  const objectId = await storeDocument(sessionId, filename, buffer, sessionKey);
  return { sessionId, fileId: objectId, filename, bytes: buffer };
}

/** Resolve the storage bucket for this principal, or send the error response. */
function resolveBucketOrReject(req: t.AuthenticatedRequest, res: Response): string | null {
  try {
    return resolveOutputBucketSessionKey(req);
  } catch (error) {
    logger.error('[documents] session key resolution failed:', error);
    res.status(400).json({ error: 'Could not resolve a storage bucket for this request' });
    return null;
  }
}

/**
 * Tie a render to the life of its request, mirroring how `/exec` removes its
 * job when the client disconnects.
 *
 * A preview the caller has walked away from is wasted work: aborting propagates
 * through to the renderer, which kills the LibreOffice/poppler child rather
 * than letting it run to its own timeout. Without this a user closing a
 * document preview leaves a CPU busy for up to the render timeout.
 *
 * `res.on('close')` also fires on normal completion, so the listener is removed
 * once the handler settles; only a close BEFORE completion aborts.
 */
function abortOnDisconnect(
  req: t.AuthenticatedRequest,
  res: Response,
): { signal: AbortSignal; done: () => void } {
  const controller = new AbortController();
  const onClose = (): void => {
    if (res.writableEnded) {
      return;
    }
    logger.info('[documents] client disconnected; aborting render');
    controller.abort();
  };
  /* ONLY `res`. `req` also emits 'close' when the request stream simply
   * finishes being read — which is the normal path for an upload, not a
   * disconnect — so listening there aborts healthy renders. `res` closing
   * before `writableEnded` is the reliable "caller went away" signal.
   * A false abort breaks real work; a missed one only wastes CPU. */
  res.on('close', onClose);
  return {
    signal: controller.signal,
    done: () => {
      res.off('close', onClose);
    },
  };
}

/** True when a render ended because the caller went away, not because it failed. */
function isAbort(error: unknown): boolean {
  const err = error as { name?: string; code?: string } | undefined;
  return err?.name === 'AbortError' || err?.code === 'ERR_CANCELED' || err?.code === 'ABORT_ERR';
}

/** Shared guard: principal + service lifecycle. */
function guard(req: t.AuthenticatedRequest, res: Response): boolean {
  if (!getPrincipalOrReject(req, res)) return false;
  if (checkServiceShutDown()) {
    res.status(503).json({ error: 'Service is shutting down' });
    return false;
  }
  if (checkServiceStartUp()) {
    res.status(503).json({ error: 'Service is starting up' });
    return false;
  }
  return true;
}

function sendSourceError(error: unknown, res: Response, label: string): void {
  const status = (error as { status?: number }).status;
  if (typeof status === 'number') {
    res.status(status).json({ error: (error as Error).message });
    return;
  }
  logger.error(`[documents] ${label} failed:`, getAxiosErrorDetails(error));
  res.status(500).json({ error: 'Internal server error' });
}

/**
 * `POST /v1/documents/preview` — produce a PDF rendition of a document.
 *
 * Replaces the fork's `POST /render/pdf`. A PDF source short-circuits (it is
 * already the target format) so the renderer is only invoked for formats that
 * genuinely need LibreOffice.
 */
router.post('/documents/preview', uploadLimiter, async (req: t.AuthenticatedRequest, res: Response) => {
  if (!guard(req, res)) return;
  const sessionKey = resolveBucketOrReject(req, res);
  if (sessionKey == null) return;
  const { signal, done } = abortOnDisconnect(req, res);

  let source: DocumentSource;
  try {
    source = await resolveSource(req, sessionKey);
  } catch (error) {
    done();
    return sendSourceError(error, res, 'resolve source');
  }

  const sourceFormat = extensionOf(source.filename);

  /* Passthrough: the source already IS a PDF, so return the reference
   * unchanged rather than round-tripping it through LibreOffice. */
  if (PASSTHROUGH_FORMATS.has(sourceFormat)) {
    done();
    return res.status(200).json({
      session_id: source.sessionId,
      file_id: source.fileId,
      pages: null,
      bytes: source.bytes.length,
      source_format: sourceFormat,
    });
  }

  try {
    const rendered = await axios({
      method: 'post',
      url: `${RENDERER_URL}/internal/documents/preview`,
      params: { filename: source.filename },
      signal,
      headers: { ...internalServiceHeaders(), 'content-type': 'application/octet-stream' },
      data: source.bytes,
      responseType: 'arraybuffer',
      timeout: RENDER_TIMEOUT_MS,
      maxBodyLength: Infinity,
      maxContentLength: Infinity,
    });

    const pdfBytes = Buffer.from(rendered.data as ArrayBuffer);
    const baseName = source.filename.replace(/\.[^.]+$/, '');
    const pdfName = `${baseName}.pdf`;
    const pdfFileId = await storeDocument(
      source.sessionId,
      pdfName,
      pdfBytes,
      sessionKey,
      'application/pdf',
    );

    logger.info('[documents] rendered pdf', {
      session_id: source.sessionId,
      source: source.fileId,
      bytes: pdfBytes.length,
    });

    return res.status(200).json({
      session_id: source.sessionId,
      file_id: pdfFileId,
      file_name: pdfName,
      pages: null,
      bytes: pdfBytes.length,
      source_format: sourceFormat,
    });
  } catch (error) {
    const status = (error as { response?: { status?: number } }).response?.status;
    if (status === 422) {
      return res.status(422).json({ error: 'Unsupported or corrupt document' });
    }
    logger.error('[documents] pdf render failed:', getAxiosErrorDetails(error));
    return res.status(500).json({ error: 'Document render failed' });
  }
});

/**
 * `POST /v1/documents/pages` — rasterize a PDF into per-page images + text.
 *
 * Replaces the fork's `POST /render/pages` ("rendered-native" previews). With
 * `persist=true` the page payload is stored as a JSON sidecar and only its id
 * is returned, keeping the response small for large documents.
 */
router.post('/documents/pages', uploadLimiter, async (req: t.AuthenticatedRequest, res: Response) => {
  if (!guard(req, res)) return;
  const sessionKey = resolveBucketOrReject(req, res);
  if (sessionKey == null) return;

  const { signal, done } = abortOnDisconnect(req, res);

  let source: DocumentSource;
  try {
    source = await resolveSource(req, sessionKey);
  } catch (error) {
    done();
    return sendSourceError(error, res, 'resolve source');
  }

  const query = (req.query ?? {}) as Record<string, string | undefined>;
  const bodyOpts = (req.body ?? {}) as Record<string, unknown>;
  const persist = String(query.persist ?? bodyOpts.persist ?? 'false') === 'true';

  try {
    const rendered = await axios({
      method: 'post',
      url: `${RENDERER_URL}/internal/documents/pages`,
      signal,
      params: {
        dpi: query.dpi ?? bodyOpts.dpi,
        max_pages: query.max_pages ?? bodyOpts.max_pages,
      },
      headers: { ...internalServiceHeaders(), 'content-type': 'application/pdf' },
      data: source.bytes,
      timeout: RENDER_TIMEOUT_MS,
      maxBodyLength: Infinity,
      maxContentLength: Infinity,
    });

    const result = rendered.data as {
      pages: unknown[];
      totalPages: number;
      truncated: boolean;
    };

    let pagesFileId: string | null = null;
    if (persist) {
      const baseName = source.filename.replace(/\.[^.]+$/, '');
      pagesFileId = await storeDocument(
        source.sessionId,
        `${baseName}.pages.json`,
        Buffer.from(JSON.stringify({ pages: result.pages }), 'utf8'),
        sessionKey,
        'application/json',
      );
    }

    logger.info('[documents] rendered pages', {
      session_id: source.sessionId,
      source: source.fileId,
      pages: result.pages.length,
      persisted: persist,
    });

    return res.status(200).json({
      session_id: source.sessionId,
      file_id: source.fileId,
      total_pages: result.totalPages,
      rendered_pages: result.pages.length,
      truncated: result.truncated,
      pages_file_id: pagesFileId,
      /* Persisted responses stay small — the caller fetches the JSON sidecar
       * via /download instead of receiving every page inline. */
      pages: persist ? [] : result.pages,
    });
  } catch (error) {
    const status = (error as { response?: { status?: number } }).response?.status;
    if (status === 422) {
      return res.status(422).json({ error: 'Unsupported or corrupt PDF' });
    }
    logger.error('[documents] pages render failed:', getAxiosErrorDetails(error));
    return res.status(500).json({ error: 'Document render failed' });
  }
});

export default router;
