/**
 * UPSTREAM DELTA — turn image outputs into something the model can actually see.
 *
 * Upstream returns harvested files as `{ id, name, storage_session_id }`. The
 * host builds the tool message from that list and inlines a file as a vision
 * content block only when the ref carries BOTH a `media_type` and a fetchable
 * `view_url`; otherwise it emits a text mention. So a run that produced a chart
 * or a slide render came back to the model as the sentence "Image: /mnt/data/
 * slide-1.jpg (83559 bytes)" — the model was told an image existed but never
 * shown it, which defeats the point of generating one.
 *
 * This module fills in those two fields for image outputs. Credentials for
 * object storage live only in the file server, so the URL is minted there and
 * fetched over the internal network.
 */

import { env } from './config';
import logger from './logger';
import { detectImageMediaType } from './image-media-type';
import { internalServiceHeaders } from './internal-service-auth';
import type { FileRef } from './types/service';

/**
 * Cap on how many URLs one execution mints.
 *
 * PERF: a run that writes hundreds of frames would otherwise issue hundreds of
 * presign round trips on the response path, all of them wasted — the host
 * inlines only a handful of images per tool message, and the model cannot use
 * more than that in one turn.
 */
const MAX_VIEW_URLS_PER_RESULT = 12;

/** How long to wait on the file server before giving up on a single URL. */
const PRESIGN_TIMEOUT_MS = 3000;

/**
 * Ask the file server for a short-lived fetch URL, or `undefined` if it cannot
 * produce one.
 *
 * Never throws: a missing URL costs a vision block, not the execution.
 */
async function mintViewUrl(sessionId: string, fileId: string): Promise<string | undefined> {
  const url = `${env.FILE_SERVER_URL}/sessions/${encodeURIComponent(sessionId)}/objects/${encodeURIComponent(fileId)}/view-url`;
  try {
    const response = await fetch(url, {
      /* The file server gates /sessions on the shared internal-service token. */
      headers: internalServiceHeaders(),
      signal: AbortSignal.timeout(PRESIGN_TIMEOUT_MS),
    });
    if (!response.ok) {
      return undefined;
    }
    const body = (await response.json()) as { view_url?: unknown };
    return typeof body.view_url === 'string' && body.view_url.length > 0
      ? body.view_url
      : undefined;
  } catch (error) {
    logger.debug('Could not mint a view URL', {
      sessionId,
      fileId,
      error: String(error),
    });
    return undefined;
  }
}

/**
 * Return `files` with image entries annotated for vision inlining.
 *
 * Non-image entries and entries whose URL could not be minted are passed
 * through unchanged, so this can never make a result worse than upstream's.
 *
 * @param files - Harvested file refs from the sandbox response.
 * @param fallbackSessionId - Storage session to use when a ref omits its own.
 */
export async function annotateImageRefs(
  files: FileRef[],
  fallbackSessionId: string | undefined,
): Promise<FileRef[]> {
  const targets: number[] = [];
  for (let i = 0; i < files.length && targets.length < MAX_VIEW_URLS_PER_RESULT; i++) {
    const file = files[i];
    /* Inherited entries are inputs the caller already has; re-presenting them
     * as vision blocks would re-send the same image every turn. */
    if (file.inherited === true) {
      continue;
    }
    if (detectImageMediaType(file.name) !== undefined) {
      targets.push(i);
    }
  }

  if (targets.length === 0) {
    return files;
  }

  const annotated = [...files];
  await Promise.all(
    targets.map(async (index) => {
      const file = files[index];
      const sessionId = file.storage_session_id ?? fallbackSessionId;
      if (sessionId === undefined) {
        return;
      }
      const viewUrl = await mintViewUrl(sessionId, file.id);
      if (viewUrl === undefined) {
        return;
      }
      annotated[index] = {
        ...file,
        media_type: detectImageMediaType(file.name),
        view_url: viewUrl,
      };
    }),
  );

  return annotated;
}
