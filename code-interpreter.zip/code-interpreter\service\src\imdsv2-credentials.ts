/**
 * UPSTREAM DELTA — IMDSv2 credentials provider for the S3 client.
 *
 * ## Why this file exists
 *
 * The S3 client's bundled `IamAwsProvider` speaks **IMDSv1**: it GETs
 * `http://169.254.169.254/latest/meta-data/iam/security-credentials/` with no
 * session token. EC2 instances configured with `HttpTokens=required` — the
 * hardened default, and what the dev host uses — answer that with **401
 * Unauthorized**. The provider then yields no credentials, and the S3 client
 * fails its own constructor validation with the (very misleading) message
 * `accessKey should be of type "string"`, retrying forever.
 *
 * IMDSv1 is the SSRF-prone variant: any request forged from inside a workload
 * can read the instance's role credentials. On a host whose entire purpose is
 * running other people's code, relaxing to `HttpTokens=optional` to satisfy an
 * old client would be the wrong trade. The alternative — a long-lived access
 * key on disk — is the thing the IAM-role setup exists to avoid.
 *
 * So this provider implements the IMDSv2 handshake instead: PUT a token, then
 * send it as `X-aws-ec2-metadata-token` on every metadata read. That keeps both
 * properties we want: **IMDSv2 stays enforced** and **no static credential is
 * ever written to the host**.
 *
 * ## Removing this
 *
 * This is a workaround for an upstream gap, not a feature. If the S3 client
 * gains IMDSv2 support, delete this file and restore the plain
 * `IamAwsProvider` branch in `file-server.ts`.
 *
 * @see file-server.ts `createMinioClient()` for the selection logic.
 */
import logger from './fileServerLogger';

/**
 * The S3 client reaches a provider's result through accessor methods only
 * (`getCredentials()` then `getAccessKey()` / `getSecretKey()` /
 * `getSessionToken()`), and the constructor path assigns the provider without
 * an `instanceof` check. Satisfying that shape structurally avoids importing
 * `minio/dist/main/*`, whose deep paths the package's export map does not
 * expose to the bundler — the same reason the sibling IRSA branch has to reach
 * for them through a dynamic import.
 */
interface ResolvedCredentials {
  getAccessKey(): string;
  getSecretKey(): string;
  getSessionToken(): string | undefined;
}

/** Link-local metadata address; identical on every EC2 instance. */
const IMDS_BASE = 'http://169.254.169.254';
/** Metadata reads are single-digit-ms on the link-local address. */
const REQUEST_TIMEOUT_MS = 2_000;
/** Max TTL IMDS accepts for a session token (6h). */
const TOKEN_TTL_SECONDS = 21_600;
/**
 * Renew this long before expiry. IMDS rotates role credentials well ahead of
 * `Expiration`, so a wide margin costs nothing and avoids a request racing a
 * rotation mid-flight.
 */
const REFRESH_MARGIN_MS = 5 * 60 * 1000;

interface ImdsCredentialDocument {
  Code?: string;
  AccessKeyId?: string;
  SecretAccessKey?: string;
  Token?: string;
  Expiration?: string;
}

async function fetchWithTimeout(url: string, init: RequestInit = {}): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    return await fetch(url, { ...init, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Resolves EC2 instance-role credentials over IMDSv2.
 *
 * Cached until shortly before expiry: the S3 client calls `getCredentials()`
 * on every request, and metadata is rate-limited.
 */
export class Imdsv2CredentialProvider {
  private cached: ResolvedCredentials | null = null;
  private expiresAtMs = 0;
  private inflight: Promise<ResolvedCredentials> | null = null;

  /** PUT a session token — the step IMDSv1 clients omit and get 401 for. */
  private async fetchToken(): Promise<string> {
    const res = await fetchWithTimeout(`${IMDS_BASE}/latest/api/token`, {
      method: 'PUT',
      headers: { 'x-aws-ec2-metadata-token-ttl-seconds': String(TOKEN_TTL_SECONDS) },
    });
    if (!res.ok) {
      throw new Error(`IMDSv2 token request failed with HTTP ${res.status}`);
    }
    return res.text();
  }

  private async fetchRoleName(token: string): Promise<string> {
    const res = await fetchWithTimeout(
      `${IMDS_BASE}/latest/meta-data/iam/security-credentials/`,
      { headers: { 'x-aws-ec2-metadata-token': token } },
    );
    if (!res.ok) {
      throw new Error(`IMDS role lookup failed with HTTP ${res.status}`);
    }
    /* The listing is newline-delimited; an instance carries at most one role. */
    const role = (await res.text()).split('\n')[0]?.trim();
    if (!role) {
      throw new Error('No IAM role is attached to this instance');
    }
    return role;
  }

  private async resolve(): Promise<ResolvedCredentials> {
    const token = await this.fetchToken();
    const role = await this.fetchRoleName(token);

    const res = await fetchWithTimeout(
      `${IMDS_BASE}/latest/meta-data/iam/security-credentials/${encodeURIComponent(role)}`,
      { headers: { 'x-aws-ec2-metadata-token': token } },
    );
    if (!res.ok) {
      throw new Error(`IMDS credential fetch failed with HTTP ${res.status}`);
    }

    const doc = (await res.json()) as ImdsCredentialDocument;
    if (doc.Code && doc.Code !== 'Success') {
      throw new Error(`IMDS returned Code=${doc.Code}`);
    }
    if (!doc.AccessKeyId || !doc.SecretAccessKey) {
      throw new Error('IMDS credential document is missing required fields');
    }

    const expiresAt = doc.Expiration ? Date.parse(doc.Expiration) : Number.NaN;
    this.expiresAtMs = Number.isFinite(expiresAt)
      ? expiresAt - REFRESH_MARGIN_MS
      : Date.now() + REFRESH_MARGIN_MS;

    const accessKey = doc.AccessKeyId;
    const secretKey = doc.SecretAccessKey;
    const sessionToken = doc.Token;
    this.cached = {
      getAccessKey: () => accessKey,
      getSecretKey: () => secretKey,
      getSessionToken: () => sessionToken,
    };

    logger.info('Resolved S3 credentials from the instance role over IMDSv2', {
      role,
      expiresAt: doc.Expiration,
    });
    return this.cached;
  }

  async getCredentials(): Promise<ResolvedCredentials> {
    if (this.cached && Date.now() < this.expiresAtMs) {
      return this.cached;
    }
    /* Collapse concurrent refreshes: the client calls this per request. */
    if (!this.inflight) {
      this.inflight = this.resolve().finally(() => {
        this.inflight = null;
      });
    }
    return this.inflight;
  }
}
