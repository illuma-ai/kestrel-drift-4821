#!/usr/bin/env node
import { createHash, createHmac, randomBytes } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { readdir, realpath, stat } from 'node:fs/promises';
import { basename, dirname, join, resolve, relative, isAbsolute, sep } from 'node:path';

import { pairBridgeWorker } from './pairing.js';
import { discoverProjects } from './projects.js';
import { loadProjectRoots, projectRootArguments } from './project-roots.js';
import {
    loadCodeEnvironment,
    assertEnvironmentDefinitionsOutsideRoots,
    EnvironmentWorkspaceTools,
} from './environment.js';
import { prepareCodeEnvironment } from './environment-preparation.js';
import { assertEnvironmentResourceIsolation } from './environment-resources.js';
import { pruneDependencySnapshots } from './snapshot-lifecycle.js';
import { startFileRelay } from './relay.js';
import { DockerFileRelaySupervisor } from './relay-runtime.js';
import {
  assertIdentityPathIsPrivate,
  assertWorkspaceMutationQuarantineOwner,
  clearWorkspaceMutationQuarantine,
  defaultBridgeIdentityPath,
  defaultWorkspaceQuarantinePath,
  defaultWorkspacePath,
  ensurePrivateWorkspaceDirectory,
  loadBridgeIdentity,
  loadWorkspaceMutationQuarantine,
  saveBridgeIdentity,
  saveWorkspaceMutationQuarantine,
  prepareEnvironmentPreparationDirectory,
} from './storage.js';
import { BridgeWorker } from './worker.js';
import { LocalWorkspaceTools, SandboxWorkspaceTools } from './workspace.js';
import {
  DockerRuntimeSupervisor,
  EndpointRuntimeSupervisor,
} from './runtime.js';
import { RuntimeWorkspaceCommandSandbox } from './workspace-runtime.js';
import { NativeProcessWorkspaceCommandSandbox } from './native-process.js';
import { NativeWorkspaceCommandPool } from './native-pool.js';
import { GitWorktreeWorkspaceTools, internalWorkspaceId } from './workspace-instances.js';
import { LINKED_WORKTREE_DIRECTORY, LinkedWorktreeWorkspaceTools } from './linked-worktrees.js';
import { GitWorktreeManager } from './worktrees.js';
import {
  WorktreeRetirementScheduler,
  worktreeRetirementSettings,
} from './worktree-retirement.js';
import { captureWorkspaceRootIdentity } from './root-identity.js';
import {
  resolveNativeSrtCommandPolicy,
  serializeNativeSrtCommandPolicy,
} from './native-policy.js';
import { workspaceMutationGuard } from './workspace-guards.js';
import type { NativeProcessSandboxOptions } from './native-process.js';
import type { LocalWorkspaceConfig } from './workspace.js';
import {
  GITHUB_ALLOWED_DOMAINS,
  GitHubAppCredentialProvider,
  gitHubRepositoryForCommand,
  gitHubRepositoryForDirectory,
  gitHubCommandCredentialEnvironment,
  gitHubMaskedCredentialVariables,
  StaticGitHubCredentialProvider,
  gitHubAuthenticationPolicyIdentity,
  normalizeGitHubHost,
  wrapGitHubCredentialCommand,
} from './github.js';
import type { RuntimeSupervisor } from './runtime.js';
import type { GitHubCredentialProvider } from './github.js';
import type { WorkspaceToolExecutor } from './workspace.js';
import {
  BRIDGE_WORKSPACE_NAME_MAX_LENGTH,
  BridgeProtocolError,
    isValidBridgeWorkerCapabilities,
    isValidBridgeWorkerId,
    isValidLinkedWorktreeName,
    workspaceIsolationKey,
} from './protocol.js';

function workspaceSecurityIdentity(
  pairedPublicKey: string | undefined,
  configuredToken: string | undefined,
): string {
  return (
        pairedPublicKey ??
        required('LIBRECHAT_CODE_WORKER_TOKEN', configuredToken)
  );
}

function workspaceQuarantinePath(options: {
  codeApiUrl: string;
  workerId: string;
  workspaceRoot?: string;
}): string {
    const override =
        process.env.LIBRECHAT_CODE_WORKSPACE_QUARANTINE_FILE?.trim();
  if (override) return override;
  return defaultWorkspaceQuarantinePath({
    ...options,
    workspaceRoot: required('workspace directory', options.workspaceRoot),
  });
}

function required(name: string, value = process.env[name]): string {
  const normalized = value?.trim();
  if (!normalized) throw new Error(`${name} is required`);
  return normalized;
}

function list(value: string | undefined): string[] {
  return (
    value
      ?.split(',')
            .map(item => item.trim())
      .filter(Boolean) ?? []
  );
}

function positiveInteger(
  name: string,
  value: string | undefined,
  fallback: number,
): number {
  if (value == null || value.trim().length === 0) return fallback;
  const parsed = Number(value);
  if (!Number.isSafeInteger(parsed) || parsed <= 0) {
    throw new Error(`${name} must be a positive integer`);
  }
  return parsed;
}

const MACOS_NSJAIL_CAPABILITIES = [
  'SYS_ADMIN',
  'SYS_CHROOT',
  'SYS_PTRACE',
  'SETUID',
  'SETGID',
  'NET_ADMIN',
  'DAC_OVERRIDE',
  'DAC_READ_SEARCH',
  'CHOWN',
  'FOWNER',
  'FSETID',
  'KILL',
  'SETFCAP',
  'MKNOD',
];

function option(args: string[], name: string): string | undefined {
  const index = args.indexOf(name);
  if (index >= 0) return args[index + 1];
  return args
        .find(value => value.startsWith(`${name}=`))
    ?.slice(name.length + 1);
}

function nonEmpty(value: string | undefined): string | undefined {
  return value?.trim().length ? value : undefined;
}

function githubCredentials(args: string[]): {
  provider?: GitHubCredentialProvider;
  host: string;
  privateKeyPath?: string;
  mode?: 'app' | 'token';
  repositoryRouting?: boolean;
  checkoutRouting?: boolean;
  installationTokenScope?: boolean;
  policyIdentity: string;
} {
  const token = nonEmpty(process.env.LIBRECHAT_CODE_GITHUB_TOKEN);
  const appId = nonEmpty(process.env.LIBRECHAT_CODE_GITHUB_APP_ID);
  const installationId = nonEmpty(
    process.env.LIBRECHAT_CODE_GITHUB_INSTALLATION_ID,
  );
  const routing =
    option(args, '--github-repository-routing')?.trim().toLowerCase() ??
    process.env.LIBRECHAT_CODE_GITHUB_REPOSITORY_ROUTING?.trim().toLowerCase() ??
    'admitted';
  if (routing !== 'admitted' && routing !== 'checkout') {
    throw new Error('GitHub repository routing must be admitted or checkout');
  }
  const privateKeyPath = nonEmpty(
    process.env.LIBRECHAT_CODE_GITHUB_PRIVATE_KEY_FILE,
  );
  const appValues = [appId, installationId, privateKeyPath];
  const hasApp = appValues.some(Boolean);
  if (hasApp && (!appId || !privateKeyPath)) {
    throw new Error(
      'GitHub App authentication requires LIBRECHAT_CODE_GITHUB_APP_ID and LIBRECHAT_CODE_GITHUB_PRIVATE_KEY_FILE; LIBRECHAT_CODE_GITHUB_INSTALLATION_ID is an optional legacy fallback',
    );
  }
  if (hasApp && token) {
    throw new Error(
      'Configure either GitHub App authentication or a GitHub token, not both',
    );
  }
  if (routing === 'checkout' && (!hasApp || installationId)) {
    throw new Error(
      'Checkout GitHub repository routing requires a GitHub App without a fixed installation ID',
    );
  }
  const tokenScope =
    option(args, '--github-token-scope')?.trim().toLowerCase() ??
    process.env.LIBRECHAT_CODE_GITHUB_TOKEN_SCOPE?.trim().toLowerCase() ??
    'repository';
  if (tokenScope !== 'repository' && tokenScope !== 'installation') {
    throw new Error('GitHub token scope must be repository or installation');
  }
  if (tokenScope === 'installation' && (!hasApp || installationId)) {
    throw new Error(
      'Installation-scoped GitHub tokens require a GitHub App without a fixed installation ID',
    );
  }
  const configuredHostValue = nonEmpty(
    process.env.LIBRECHAT_CODE_GITHUB_HOST,
  );
  const configuredHost = configuredHostValue
    ? normalizeGitHubHost(configuredHostValue)
    : undefined;
  const apiUrl = nonEmpty(process.env.LIBRECHAT_CODE_GITHUB_API_URL);
  let apiHost: string | undefined;
  if (apiUrl) {
    let parsedApiUrl: URL;
    try {
      parsedApiUrl = new URL(apiUrl);
    } catch {
            throw new Error(
                'LIBRECHAT_CODE_GITHUB_API_URL must be a valid URL',
            );
    }
    apiHost =
      parsedApiUrl.hostname.toLowerCase() === 'api.github.com'
        ? 'github.com'
        : parsedApiUrl.hostname.toLowerCase();
  }
  if (configuredHost && apiHost && configuredHost.toLowerCase() !== apiHost) {
    throw new Error(
      'LIBRECHAT_CODE_GITHUB_HOST must match the GitHub App API hostname',
    );
  }
  const host = normalizeGitHubHost(configuredHost ?? apiHost ?? 'github.com');
  if (hasApp) {
    return {
      host,
      mode: 'app',
      repositoryRouting: !installationId,
      checkoutRouting: routing === 'checkout',
      installationTokenScope: tokenScope === 'installation',
      policyIdentity: gitHubAuthenticationPolicyIdentity({
        mode: 'app',
        host,
        appId,
        installationId,
      }) + (routing === 'checkout' ? ':routing:checkout' : '') +
        (tokenScope === 'installation' ? ':scope:installation' : ''),
      privateKeyPath,
      provider: new GitHubAppCredentialProvider({
        appId: appId!,
        installationId,
        tokenScope,
        privateKeyPath: privateKeyPath!,
        host,
        apiUrl,
      }),
    };
  }
  return {
    host,
    policyIdentity: gitHubAuthenticationPolicyIdentity({
      mode: token ? 'token' : undefined,
      host,
      token,
    }),
    ...(token
      ? {
          provider: new StaticGitHubCredentialProvider(token),
          mode: 'token' as const,
        }
      : {}),
  };
}

function defaultWorkspaceName(
  workerDirectory: string,
  workspaceId: string,
): string {
  const directoryName = basename(resolve(workerDirectory));
  return directoryName.trim().length > 0 &&
    directoryName.length <= BRIDGE_WORKSPACE_NAME_MAX_LENGTH
    ? directoryName
    : workspaceId;
}

async function pair(args: string[]): Promise<void> {
  const codeApiUrl = required('instance URL', args[1]);
  const code = required('one-time pairing code', args[2]);
  const workerId = required(
    '--worker-id or LIBRECHAT_CODE_WORKER_ID',
    option(args, '--worker-id') ?? process.env.LIBRECHAT_CODE_WORKER_ID,
  );
  const identityPath =
    option(args, '--identity') ??
    process.env.LIBRECHAT_CODE_IDENTITY_FILE ??
    defaultBridgeIdentityPath(workerId);
  const reservation = await assertIdentityPathIsPrivate(identityPath);
  try {
    const identity = await pairBridgeWorker({ codeApiUrl, workerId, code });
    await saveBridgeIdentity(identityPath, identity);
  } catch (error) {
    await reservation.release();
    throw error;
  }
  process.stdout.write(
    `Paired worker ${workerId}. Identity saved to ${identityPath}\n`,
  );
}

async function relay(): Promise<void> {
  const handle = await startFileRelay({
    host: process.env.LIBRECHAT_CODE_FILE_RELAY_HOST?.trim() || '0.0.0.0',
    port: positiveInteger(
      'LIBRECHAT_CODE_FILE_RELAY_PORT',
      process.env.LIBRECHAT_CODE_FILE_RELAY_PORT,
      3000,
    ),
    upstreamUrl: required('LIBRECHAT_CODE_FILE_RELAY_UPSTREAM'),
    token: required('LIBRECHAT_CODE_FILE_RELAY_TOKEN'),
    maxBytes: positiveInteger(
      'LIBRECHAT_CODE_FILE_RELAY_MAX_BYTES',
      process.env.LIBRECHAT_CODE_FILE_RELAY_MAX_BYTES,
      16 * 1024 * 1024,
    ),
    timeoutMs: positiveInteger(
      'LIBRECHAT_CODE_FILE_RELAY_TIMEOUT_MS',
      process.env.LIBRECHAT_CODE_FILE_RELAY_TIMEOUT_MS,
      30_000,
    ),
    maxConcurrentRequests: positiveInteger(
      'LIBRECHAT_CODE_FILE_RELAY_MAX_CONCURRENT_REQUESTS',
      process.env.LIBRECHAT_CODE_FILE_RELAY_MAX_CONCURRENT_REQUESTS,
      8,
    ),
  });
  process.stdout.write(
    `librechat-code: file relay listening at ${handle.url}\n`,
  );
    await new Promise<void>(resolve => {
    process.once('SIGINT', resolve);
    process.once('SIGTERM', resolve);
  });
  await handle.close();
}

async function run(
  runtimeSessionId?: string,
  args: string[] = [],
): Promise<void> {
    const projectArgs = projectRootArguments(args);
    if (
        projectArgs &&
        (runtimeSessionId != null ||
            args.some(arg =>
                ['--environment', '--worker-dir', '--default-workspace',
                    '--workspace', '--workspace-id', '--workspace-name'].some(
                    flag => arg === flag || arg.startsWith(`${flag}=`),
                ),
            ) ||
            [process.env.LIBRECHAT_CODE_WORKER_DIR,
                process.env.LIBRECHAT_CODE_WORKSPACE_ID,
                process.env.LIBRECHAT_CODE_WORKSPACE_NAME].some(value => value?.trim()) ||
            process.env.LIBRECHAT_CODE_DEFAULT_WORKSPACE?.trim().toLowerCase() === 'true')
    ) {
        throw new Error('Project selection cannot be combined with other workspace registration settings');
    }
    const projectRoots = projectArgs
        ? await loadProjectRoots(projectArgs.root, projectArgs.projects)
        : [];
    const environmentPaths: string[] = [];
    for (let i = 0; i < args.length; i++) {
        if (args[i] === '--environment') {
            const path = args[++i];
            if (!path || path.startsWith('--'))
                throw new Error('--environment requires a YAML file');
            environmentPaths.push(path);
        } else if (args[i].startsWith('--environment=')) {
            const path = args[i].slice('--environment='.length);
            if (!path) throw new Error('--environment requires a YAML file');
            environmentPaths.push(path);
        }
    }
    if (environmentPaths.length > 32)
        throw new Error('At most 32 environments may be registered');
    const environments = await Promise.all(
        environmentPaths.map(loadCodeEnvironment),
    );
    if (
        environments.length &&
        (runtimeSessionId != null ||
            args.some(arg =>
                [
                    '--worker-dir',
                    '--default-workspace',
                    '--workspace',
                    '--workspace-id',
                    '--workspace-name',
                ].some(flag => arg === flag || arg.startsWith(`${flag}=`)),
            ) ||
            [
                process.env.LIBRECHAT_CODE_WORKER_DIR,
                process.env.LIBRECHAT_CODE_WORKSPACE_ID,
                process.env.LIBRECHAT_CODE_WORKSPACE_NAME,
            ].some(value => value?.trim()) ||
            process.env.LIBRECHAT_CODE_DEFAULT_WORKSPACE?.trim().toLowerCase() === 'true')
    ) {
        throw new Error(
            '--environment cannot be combined with workspace directory, ID, or name settings',
        );
    }
  const configuredWorkerId = process.env.LIBRECHAT_CODE_WORKER_ID?.trim();
  const configuredIdentityPath =
    process.env.LIBRECHAT_CODE_IDENTITY_FILE?.trim();
  const configuredToken = process.env.LIBRECHAT_CODE_WORKER_TOKEN?.trim();
  const identityPath =
    configuredIdentityPath ??
    (configuredWorkerId && !configuredToken
      ? defaultBridgeIdentityPath(configuredWorkerId)
      : undefined);
  const pairedIdentity = identityPath
    ? await loadBridgeIdentity(identityPath)
    : undefined;
  const workerId = required(
    'LIBRECHAT_CODE_WORKER_ID',
    configuredWorkerId ?? pairedIdentity?.workerId,
  );
  if (!isValidBridgeWorkerId(workerId)) {
    throw new Error(
      'LIBRECHAT_CODE_WORKER_ID must match the bridge worker ID format',
    );
  }
  if (pairedIdentity && pairedIdentity.workerId !== workerId) {
    throw new Error(
      `Identity belongs to ${pairedIdentity.workerId}, not configured worker ${workerId}`,
    );
  }
  const codeApiUrl = required(
    'LIBRECHAT_CODE_URL',
    process.env.LIBRECHAT_CODE_URL ?? pairedIdentity?.codeApiUrl,
  );
  const policy = process.env.LIBRECHAT_CODE_POLICY ?? 'default-deny';
  const statefulWorkspace =
    process.env.LIBRECHAT_CODE_STATEFUL_WORKSPACE?.trim().toLowerCase() ===
    'true';
  const runtimeMode =
    process.env.LIBRECHAT_CODE_RUNTIME_SUPERVISOR?.trim().toLowerCase() ??
    'endpoint';
  if (
    runtimeMode !== 'endpoint' &&
    runtimeMode !== 'docker' &&
    runtimeMode !== 'docker-nsjail' &&
    runtimeMode !== 'docker-macos-nsjail'
  ) {
    throw new Error(
      'LIBRECHAT_CODE_RUNTIME_SUPERVISOR must be endpoint, docker, docker-nsjail, or docker-macos-nsjail',
    );
  }
  const nsjailDockerMode =
        runtimeMode === 'docker-nsjail' ||
        runtimeMode === 'docker-macos-nsjail';
  const sandboxEndpoint =
    process.env.LIBRECHAT_CODE_SANDBOX_ENDPOINT ??
    'http://127.0.0.1:2000/api/v2';
  if (
    runtimeMode === 'endpoint' &&
    statefulWorkspace &&
    !sandboxEndpoint.includes('{runtimeSessionId}')
  ) {
    throw new Error(
      'LIBRECHAT_CODE_STATEFUL_WORKSPACE requires LIBRECHAT_CODE_SANDBOX_ENDPOINT to contain {runtimeSessionId}',
    );
  }
  const workerIdentity = pairedIdentity
    ? {
        privateKey: pairedIdentity.privateKey,
        credential: pairedIdentity.credential,
        expiresAt: pairedIdentity.expiresAt,
      }
    : undefined;
  const fileRelayUpstream =
    process.env.LIBRECHAT_CODE_FILE_RELAY_UPSTREAM?.trim();
  const fileRelayEnabled =
    nsjailDockerMode &&
    runtimeSessionId == null &&
    (fileRelayUpstream?.length ?? 0) > 0;
  const workspaceId =
        projectRoots[0]?.id ??
        environments[0]?.definition.name ??
    option(args, '--workspace-id') ??
    process.env.LIBRECHAT_CODE_WORKSPACE_ID?.trim() ??
    'primary';
  const explicitWorkerDirectory =
        projectRoots[0]?.root ??
        environments[0]?.definition.root ??
        (runtimeSessionId == null
      ? nonEmpty(
          option(args, '--worker-dir') ??
            process.env.LIBRECHAT_CODE_WORKER_DIR?.trim(),
        )
            : undefined);
  const useDefaultWorkspace =
    runtimeSessionId == null &&
    (args.includes('--default-workspace') ||
      process.env.LIBRECHAT_CODE_DEFAULT_WORKSPACE?.trim().toLowerCase() ===
        'true');
  const allowWorkspaceWrites =
    runtimeSessionId == null &&
    (args.includes('--allow-workspace-writes') ||
      process.env.LIBRECHAT_CODE_ALLOW_WORKSPACE_WRITES?.trim().toLowerCase() ===
        'true');
  const allowWorkspaceCommands =
    runtimeSessionId == null &&
    (args.includes('--allow-workspace-commands') ||
      process.env.LIBRECHAT_CODE_ALLOW_WORKSPACE_COMMANDS?.trim().toLowerCase() ===
        'true');
  const linkedWorktreeLanes =
    runtimeSessionId == null &&
    (args.includes('--linked-worktree-lanes') ||
      process.env.LIBRECHAT_CODE_LINKED_WORKTREE_LANES?.trim().toLowerCase() ===
        'true');
  const commandSandboxMode =
    option(args, '--command-sandbox') ??
    process.env.LIBRECHAT_CODE_COMMAND_SANDBOX?.trim().toLowerCase() ??
    (nsjailDockerMode ? 'runtime' : 'native-srt');
    if (
        commandSandboxMode !== 'native-srt' &&
        commandSandboxMode !== 'runtime'
    ) {
    throw new Error(
      'LIBRECHAT_CODE_COMMAND_SANDBOX must be native-srt or runtime',
    );
  }
    if (environments.length && commandSandboxMode !== 'native-srt') {
        throw new Error('Environment definitions require native-srt');
    }
    if (projectRoots.length && commandSandboxMode !== 'native-srt') {
        throw new Error('Project selections require native-srt');
    }
    if (
        environments.some(environment => environment.definition.setup) &&
        !allowWorkspaceCommands
    ) {
        throw new Error(
            'Environment setup requires --allow-workspace-commands',
        );
    }
  const nativeProgrammaticEnabled =
    allowWorkspaceCommands &&
    commandSandboxMode === 'native-srt' &&
    process.platform !== 'win32' &&
    (fileRelayUpstream?.length ?? 0) > 0;
  const commandPolicy = resolveNativeSrtCommandPolicy(
    option(args, '--command-policy-preset') ??
      process.env.LIBRECHAT_CODE_COMMAND_POLICY_PRESET?.trim().toLowerCase() ??
      'restricted',
  );
  if (
    commandPolicy.preset !== 'restricted' &&
    (!allowWorkspaceCommands || commandSandboxMode !== 'native-srt')
  ) {
    throw new Error(
      'A permissive command policy preset requires native-srt workspace commands',
    );
  }
  const github =
    runtimeSessionId == null
      ? githubCredentials(args)
      : {
          host: 'github.com',
          repositoryRouting: false,
          checkoutRouting: false,
          policyIdentity: gitHubAuthenticationPolicyIdentity({
            host: 'github.com',
          }),
        };
  if (github.provider && !allowWorkspaceCommands) {
    throw new Error(
      'GitHub authentication requires workspace commands to be enabled',
    );
  }
  if (github.provider && commandSandboxMode !== 'native-srt') {
    throw new Error(
      'GitHub authentication currently requires the native-srt command sandbox',
    );
  }
  if (github.checkoutRouting && commandPolicy.preset !== 'trusted-vm') {
    throw new Error(
      'Checkout GitHub repository routing requires the trusted-vm command policy',
    );
  }
  if (github.installationTokenScope && commandPolicy.preset !== 'trusted-vm') {
    throw new Error(
      'Installation-scoped GitHub tokens require the trusted-vm command policy',
    );
  }
  const githubDomains = github.provider
    ? github.host === 'github.com'
      ? [...GITHUB_ALLOWED_DOMAINS]
      : [github.host]
    : [];
  const commandAllowedDomains = [
    ...new Set([
      ...list(process.env.LIBRECHAT_CODE_COMMAND_ALLOWED_DOMAINS),
      ...githubDomains,
    ]),
  ].sort();
  if (explicitWorkerDirectory && useDefaultWorkspace) {
    throw new Error(
      '--worker-dir and --default-workspace cannot be used together',
    );
  }
  const workerDirectory =
    explicitWorkerDirectory ??
    (useDefaultWorkspace
      ? defaultWorkspacePath({
          codeApiUrl,
          securityIdentity: workspaceSecurityIdentity(
            pairedIdentity?.publicKey,
            configuredToken,
          ),
          workerId,
          workspaceId,
        })
      : undefined);
  if (useDefaultWorkspace && workerDirectory) {
    await ensurePrivateWorkspaceDirectory(workerDirectory);
  }
  let canonicalWorkerDirectory: string | undefined;
  if (workerDirectory) {
    try {
      canonicalWorkerDirectory = await realpath(workerDirectory);
    } catch {
      throw new Error('Invalid workspace registration');
    }
  }
  const mutationQuarantinePath =
        (allowWorkspaceWrites || allowWorkspaceCommands) &&
        canonicalWorkerDirectory
      ? workspaceQuarantinePath({
          codeApiUrl,
          workerId,
          workspaceRoot: canonicalWorkerDirectory,
        })
      : undefined;
  const workspaceLeaseSlots = positiveInteger(
    'LIBRECHAT_CODE_WORKSPACE_LEASE_SLOTS',
    option(args, '--workspace-lease-slots') ??
      process.env.LIBRECHAT_CODE_WORKSPACE_LEASE_SLOTS,
    1,
  );
  if (workspaceLeaseSlots > 8)
    throw new Error('Workspace lease slots cannot exceed 8');
  const conversationWorktreeRoot =
    option(args, '--conversation-worktree-root') ??
    process.env.LIBRECHAT_CODE_CONVERSATION_WORKTREE_ROOT?.trim();
  const conversationWorktreeMax = positiveInteger(
    'LIBRECHAT_CODE_CONVERSATION_WORKTREE_MAX',
    option(args, '--conversation-worktree-max') ??
      process.env.LIBRECHAT_CODE_CONVERSATION_WORKTREE_MAX,
    64,
  );
  if (conversationWorktreeMax > 1024) {
    throw new Error('Conversation worktree capacity cannot exceed 1024');
  }
  const conversationWorktreeCloneTimeoutMs = positiveInteger(
    'LIBRECHAT_CODE_CONVERSATION_WORKTREE_CLONE_TIMEOUT_MS',
    option(args, '--conversation-worktree-clone-timeout-ms') ??
      process.env.LIBRECHAT_CODE_CONVERSATION_WORKTREE_CLONE_TIMEOUT_MS,
    5 * 60_000,
  );
  if (
    conversationWorktreeCloneTimeoutMs < 30_000 ||
    conversationWorktreeCloneTimeoutMs > 30 * 60_000
  ) {
    throw new Error(
      'Conversation worktree clone timeout must be between 30000 and 1800000 milliseconds',
    );
  }
  const roots: LocalWorkspaceConfig[] = canonicalWorkerDirectory
    ? [
        {
          id: workspaceId,
          root: canonicalWorkerDirectory,
          identity: projectRoots[0]?.identity,
          writable: allowWorkspaceWrites,
          name:
                      projectRoots[0]?.name ??
                      environments[0]?.definition.name ??
            option(args, '--workspace-name') ??
            process.env.LIBRECHAT_CODE_WORKSPACE_NAME?.trim() ??
            (useDefaultWorkspace
              ? workspaceId
                          : defaultWorkspaceName(
                                workerDirectory!,
                                workspaceId,
                            )),
        },
      ]
    : [];
    for (const environment of environments.slice(1)) {
        roots.push({
            id: environment.definition.name,
            name: environment.definition.name,
            root: environment.definition.root,
            writable: allowWorkspaceWrites,
        });
    }
    for (const project of projectRoots.slice(1)) {
        roots.push({ ...project, writable: allowWorkspaceWrites });
    }
    await assertEnvironmentDefinitionsOutsideRoots(environments, roots);
  for (let i = 0; i < args.length; i++) {
    if (
      args[i] === '--workspace' &&
      (!args[i + 1] || args[i + 1].startsWith('--'))
    ) {
      throw new Error('--workspace requires id=path');
    }
    const value =
      args[i] === '--workspace'
        ? args[++i]
        : args[i].startsWith('--workspace=')
          ? args[i].slice('--workspace='.length)
          : undefined;
    if (value === undefined) continue;
    const separator = value.indexOf('=');
    if (
      separator < 1 ||
      separator === value.length - 1 ||
      !canonicalWorkerDirectory ||
      commandSandboxMode !== 'native-srt'
    ) {
      throw new Error(
        'Additional --workspace id=path roots require a primary workspace and native-srt',
      );
    }
    roots.push({
      id: value.slice(0, separator),
      root: await realpath(value.slice(separator + 1)),
      writable: allowWorkspaceWrites,
    });
  }
  // Aliases and nested grants are not independent execution domains.
  if (roots.length > 32)
    throw new Error('At most 32 workspace roots may be registered');
  const rootIdentities = await Promise.all(
        roots.map(root => stat(root.root)),
  );
    const normalized = roots.map(root => root.root);
  for (let i = 0; i < roots.length; i++)
    for (let j = 0; j < i; j++) {
      const inside = (a: string, b: string): boolean => {
        const path = relative(a, b);
        return (
          path === '' ||
                    (path !== '..' &&
                        !path.startsWith(`..${sep}`) &&
                        !isAbsolute(path))
        );
      };
      if (
        (rootIdentities[i].dev === rootIdentities[j].dev &&
          rootIdentities[i].ino === rootIdentities[j].ino) ||
        inside(normalized[i], normalized[j]) ||
        inside(normalized[j], normalized[i])
      ) {
        throw new Error(
          'Workspace roots must not overlap or alias one another',
        );
      }
    }
  if (
    workspaceLeaseSlots > 1 &&
    (!allowWorkspaceCommands || commandSandboxMode !== 'native-srt')
  ) {
        throw new Error(
            'Concurrent workspace leases require native-srt commands',
        );
  }
  if (
    conversationWorktreeRoot &&
    (!allowWorkspaceCommands ||
      commandSandboxMode !== 'native-srt' ||
      workspaceLeaseSlots < 2)
  ) {
    throw new Error(
      'Conversation worktrees require native-srt commands and at least two workspace lease slots',
    );
  }
  if (
    linkedWorktreeLanes &&
    (!allowWorkspaceCommands ||
      commandSandboxMode !== 'native-srt' ||
      workspaceLeaseSlots < 2)
  ) {
    throw new Error(
      'Linked worktree lanes require native-srt commands and at least two workspace lease slots',
    );
  }
  if (linkedWorktreeLanes && conversationWorktreeRoot) {
    throw new Error(
      'Linked worktree lanes cannot be combined with conversation worktrees',
    );
  }
  if (linkedWorktreeLanes && process.platform === 'win32') {
    throw new Error('Linked worktree Git guard requires a POSIX host');
  }
  const worktreeRetirement = worktreeRetirementSettings({
    optOut: args.includes('--no-worktree-retirement'),
    enabled: process.env.LIBRECHAT_CODE_WORKTREE_RETIREMENT,
    idleDays:
      option(args, '--worktree-idle-days') ??
      process.env.LIBRECHAT_CODE_WORKTREE_IDLE_DAYS,
  });
  if (
    roots.length > 1 &&
    process.env.LIBRECHAT_CODE_WORKSPACE_QUARANTINE_FILE?.trim()
  ) {
    throw new Error(
      'LIBRECHAT_CODE_WORKSPACE_QUARANTINE_FILE is a single-root override; unset it for multiple workspace roots',
    );
  }
  const rootQuarantinePaths = new Map(
        roots.map(root => [
      root.id,
      workspaceQuarantinePath({
        codeApiUrl,
        workerId,
        workspaceRoot: root.root,
      }),
    ]),
  );
  const preparationDirectory = join(dirname(identityPath ?? defaultBridgeIdentityPath(workerId)), 'environment-preparation');
  if (environments.some(environment => environment.definition.setup?.reuse)) {
    const sourceParents = await prepareEnvironmentPreparationDirectory(preparationDirectory);
    // Reuse the mount/ancestor isolation checks for this worker-owned state directory.
    await assertEnvironmentDefinitionsOutsideRoots([{
      path: preparationDirectory, sourceParents,
      definition: { name: 'preparation-state', root: preparationDirectory }, fingerprint: '',
    }], roots);
  }
  // Cache contents may be shared explicitly; their grants must never authorize source or control state.
  const resourceRoots = environments.flatMap(environment => (environment.resources ?? []).map(resource => ({
    path: resource.path, sourceParents: resource.controlPaths,
    definition: { name: 'shared-resource', root: resource.path }, fingerprint: '',
  })));
  await assertEnvironmentResourceIsolation(environments.flatMap(environment => environment.resources ?? []), roots.map(root => root.root), [
    identityPath, preparationDirectory, github.privateKeyPath,
    ...environments.map(environment => environment.path), ...rootQuarantinePaths.values(),
  ].filter((path): path is string => path != null));
  await assertEnvironmentDefinitionsOutsideRoots(resourceRoots, roots);
  const snapshotStores = environments.flatMap(environment => environment.snapshotStore ? [environment.snapshotStore] : []);
  await assertEnvironmentResourceIsolation(snapshotStores.map(store => ({ kind: 'npm-cache' as const, path: store.store, access: 'read-only' as const })), roots.map(root => root.root), [
    identityPath, preparationDirectory, github.privateKeyPath, ...environments.map(environment => environment.path),
    ...rootQuarantinePaths.values(), ...environments.flatMap(environment => (environment.resources ?? []).map(resource => resource.path)),
  ].filter((path): path is string => path != null));
  await assertEnvironmentDefinitionsOutsideRoots(snapshotStores.map(store => ({ path: store.store, sourceParents: store.controlPaths,
    definition: { name: 'dependency-store', root: store.store }, fingerprint: '' })), roots);
  const preparationReceipt = (root: string) => join(preparationDirectory,
    `${createHash('sha256').update(JSON.stringify([codeApiUrl, workerId, root])).digest('hex')}.json`);
  // Keep an admission boundary even when trusted-VM checkout routing uses a
  // nested repository's remote for the current command.
  const admittedGitHubRepositories = github.provider && github.repositoryRouting
    ? new Map(
        await Promise.all(
          roots.map(async root => [
            root.root,
            await gitHubRepositoryForDirectory(root.root, github.host),
          ] as const),
        ),
      )
    : undefined;
  const repositoriesByWorkspace = admittedGitHubRepositories
    ? new Map(
        roots.map((root) => [
          root.id,
          admittedGitHubRepositories.get(root.root),
        ]),
      )
    : undefined;
  const localWorkspaceTools = workerDirectory
    ? await LocalWorkspaceTools.create({
        workspaces: roots,
        repositoryInstructions: args.includes('--repository-instructions'),
      })
    : undefined;
  let workspaceTools: WorkspaceToolExecutor | undefined = localWorkspaceTools;
  if (allowWorkspaceCommands && !canonicalWorkerDirectory) {
    throw new Error('Workspace commands require a registered directory');
  }
  if (
    allowWorkspaceCommands &&
    commandSandboxMode === 'runtime' &&
    !nsjailDockerMode
  ) {
    throw new Error(
      'The runtime command sandbox requires the docker-nsjail runtime supervisor',
    );
  }
  const controller = new AbortController();
  process.once('SIGINT', () => controller.abort());
  process.once('SIGTERM', () => controller.abort());
  const incarnationId = randomBytes(18).toString('base64url');
  const runtimeImage =
    runtimeMode !== 'endpoint'
      ? runtimeSessionId == null
        ? required('LIBRECHAT_CODE_RUNTIME_IMAGE')
        : process.env.LIBRECHAT_CODE_RUNTIME_IMAGE?.trim()
      : undefined;
  const nsjailLaunchProfile =
    nsjailDockerMode && runtimeSessionId == null
      ? (() => {
          const seccompProfile = resolve(
            required('LIBRECHAT_CODE_DOCKER_SECCOMP_PROFILE'),
          );
          const packagesPath = resolve(
            required('LIBRECHAT_CODE_DOCKER_PACKAGES_PATH'),
          );
          return {
            seccompProfile,
            packagesPath,
            profileRevision: createHash('sha256')
              .update(readFileSync(seccompProfile))
              .digest('hex'),
          };
        })()
      : undefined;
  const executionManifestPublicKey = fileRelayEnabled
    ? required('LIBRECHAT_CODE_EXECUTION_MANIFEST_PUBLIC_KEY')
    : undefined;
  const fileRelayLimits = fileRelayEnabled
    ? {
        maxBytes: positiveInteger(
          'LIBRECHAT_CODE_FILE_RELAY_MAX_BYTES',
          process.env.LIBRECHAT_CODE_FILE_RELAY_MAX_BYTES,
          16 * 1024 * 1024,
        ),
        timeoutMs: positiveInteger(
          'LIBRECHAT_CODE_FILE_RELAY_TIMEOUT_MS',
          process.env.LIBRECHAT_CODE_FILE_RELAY_TIMEOUT_MS,
          30_000,
        ),
        maxConcurrentRequests: positiveInteger(
          'LIBRECHAT_CODE_FILE_RELAY_MAX_CONCURRENT_REQUESTS',
          process.env.LIBRECHAT_CODE_FILE_RELAY_MAX_CONCURRENT_REQUESTS,
          8,
        ),
      }
    : undefined;
  const fileRelaySupervisor =
    fileRelayEnabled && fileRelayUpstream
      ? new DockerFileRelaySupervisor({
          workerId,
          incarnationId,
          image: required('LIBRECHAT_CODE_FILE_RELAY_IMAGE'),
          upstreamUrl: fileRelayUpstream,
          ...fileRelayLimits,
          token: createHmac(
            'sha256',
            pairedIdentity?.privateKey ??
                          required(
                              'LIBRECHAT_CODE_WORKER_TOKEN',
                              configuredToken,
                          ),
          )
            .update('librechat-code-file-relay-v1')
            .digest('hex'),
        })
      : undefined;
  const fileRelayProfile = await fileRelaySupervisor?.prepare(
    controller.signal,
  );
  const workspaceMount =
    allowWorkspaceCommands &&
    commandSandboxMode === 'runtime' &&
    canonicalWorkerDirectory
      ? {
          source: canonicalWorkerDirectory,
          target: '/mnt/workspace',
        }
      : undefined;
  const workspaceCommandToken =
    allowWorkspaceCommands && commandSandboxMode === 'runtime'
      ? createHmac(
          'sha256',
          pairedIdentity?.privateKey ??
            required('LIBRECHAT_CODE_WORKER_TOKEN', configuredToken),
        )
          .update(
            `librechat-code-workspace-command-v1\0${canonicalWorkerDirectory}`,
          )
          .digest('base64url')
      : undefined;
  const runtimeSupervisor: RuntimeSupervisor =
    runtimeMode !== 'endpoint'
      ? new DockerRuntimeSupervisor({
          image: runtimeImage,
          ...(nsjailDockerMode && runtimeSessionId == null
            ? (() => {
                            const {
                                seccompProfile,
                                packagesPath,
                                profileRevision,
                            } = nsjailLaunchProfile!;
                return {
                  capabilities: MACOS_NSJAIL_CAPABILITIES,
                  securityOptions: [`seccomp=${seccompProfile}`],
                  profileRevision,
                  restartStoppedContainers: false,
                  ...(fileRelayProfile
                    ? { network: fileRelayProfile.network }
                    : {}),
                  bindMounts: [
                    {
                      source: packagesPath,
                      target: '/pkgs',
                      readOnly: true,
                    },
                    ...(workspaceMount ? [workspaceMount] : []),
                  ],
                  httpClient: 'bun' as const,
                  environment: {
                    SANDBOX_USE_CGROUPV2: 'false',
                                    SANDBOX_REMOVE_UMOUNT_AFTER_STARTUP:
                                        'false',
                    ...(workspaceMount
                      ? {
                                              SANDBOX_EXTERNAL_WORKSPACE_ENABLED:
                                                  'true',
                          SANDBOX_EXTERNAL_WORKSPACE_ROOT:
                            workspaceMount.target,
                          SANDBOX_EXTERNAL_WORKSPACE_TOKEN:
                            workspaceCommandToken!,
                        }
                      : {}),
                    ...(fileRelayProfile
                      ? {
                                              EGRESS_GATEWAY_URL:
                                                  fileRelayProfile.url,
                          SANDBOX_PRIME_CONCURRENCY: String(
                                                  fileRelayLimits!
                                                      .maxConcurrentRequests,
                          ),
                                              SANDBOX_UPLOAD_CONCURRENCY:
                                                  String(
                                                      fileRelayLimits!
                                                          .maxConcurrentRequests,
                          ),
                                              SANDBOX_FILE_RELAY_TOKEN:
                                                  fileRelayProfile.token,
                                              SANDBOX_REQUIRE_EGRESS_MANIFEST:
                                                  'true',
                          SANDBOX_EXECUTION_MANIFEST_PUBLIC_KEY:
                            executionManifestPublicKey!,
                        }
                      : {}),
                  },
                };
              })()
            : workspaceMount
              ? {
                  bindMounts: [workspaceMount],
                  environment: {
                    SANDBOX_EXTERNAL_WORKSPACE_ENABLED: 'true',
                                  SANDBOX_EXTERNAL_WORKSPACE_ROOT:
                                      workspaceMount.target,
                                  SANDBOX_EXTERNAL_WORKSPACE_TOKEN:
                                      workspaceCommandToken!,
                  },
                }
              : {}),
        })
      : new EndpointRuntimeSupervisor({
          endpoint: sandboxEndpoint,
          statefulWorkspace,
        });
  const nativeOptions: NativeProcessSandboxOptions = {
    workspaceRoot: canonicalWorkerDirectory!,
    workspaceIdentity: roots[0]?.identity,
    commandPolicy,
    protectedPaths: [
      identityPath,
      ...(environments.some(environment => environment.definition.setup?.reuse) ? [preparationDirectory] : []),
      ...snapshotStores.map(store => store.store),
            ...environments.map(environment => environment.path),
      ...rootQuarantinePaths.values(),
      github.privateKeyPath,
    ].filter((path): path is string => path != null),
    allowedDomains: commandAllowedDomains,
    ...(nativeProgrammaticEnabled
      ? { programmaticFileUpstream: fileRelayUpstream }
      : {}),
    ...(github.provider
      ? {
          maskedEnvironment: {
            variables: gitHubMaskedCredentialVariables(
              github.host,
            ),
            async resolve(signal?: AbortSignal, cwd?: string) {
              const repository = cwd && admittedGitHubRepositories
                ? await gitHubRepositoryForCommand(
                    cwd,
                    admittedGitHubRepositories,
                    github.checkoutRouting ? 'checkout' : 'admitted',
                    github.host,
                    signal,
                  )
                : undefined;
              if (!repository && github.repositoryRouting) {
                return {};
              }
              return gitHubCommandCredentialEnvironment(
                await github.provider!.getCredential(signal, repository),
                github.host,
              );
            },
            wrapCommand(
              command: string,
              platform: NodeJS.Platform,
              environment: Readonly<Record<string, string>>,
            ) {
              return wrapGitHubCredentialCommand(
                command,
                github.host,
                platform,
                environment,
              );
            },
          },
        }
      : {}),
  };
  const nativeOptionsForWorkspace = (workspaceId: string): NativeProcessSandboxOptions => ({
    ...nativeOptions,
    resources: environments.find(environment => environment.definition.name === workspaceId)?.resources,
  });
  const nativeCommandSandbox =
    allowWorkspaceCommands && commandSandboxMode === 'native-srt'
      ? roots.length > 1 || workspaceLeaseSlots > 1 || conversationWorktreeRoot || linkedWorktreeLanes
        ? new NativeWorkspaceCommandPool(
            new Map(
                          roots.map(root => [
                root.id,
                { ...nativeOptionsForWorkspace(root.id), workspaceRoot: root.root, workspaceIdentity: root.identity },
              ]),
            ),
            workspaceLeaseSlots,
          )
        : new NativeProcessWorkspaceCommandSandbox(nativeOptionsForWorkspace(roots[0].id))
      : undefined;
  if (allowWorkspaceCommands && workspaceTools) {
    workspaceTools = new SandboxWorkspaceTools({
      workspaceTools,
            commandWorkspaces: roots.map(root => root.id),
      ...(nativeProgrammaticEnabled
        ? { programmaticLanguages: ['bash'] }
        : {}),
      commandSandbox:
        nativeCommandSandbox ??
        new RuntimeWorkspaceCommandSandbox({
          runtimeSupervisor,
          workerId,
          incarnationId,
        }),
    });
  }
  const conversationWorktrees = conversationWorktreeRoot
    ? new GitWorktreeManager({
        cloneTimeoutMs: conversationWorktreeCloneTimeoutMs,
        maxCount: conversationWorktreeMax,
        root: conversationWorktreeRoot,
        ...(nativeCommandSandbox instanceof NativeWorkspaceCommandPool
          ? {
              prepareInstance: async (instance, signal) => {
                const environment = environments.find(
                  (environment) =>
                    environment.definition.name === instance.sourceWorkspaceId,
                );
                const setup = environment?.definition.setup;
                if (!setup) return;
                if (admittedGitHubRepositories) {
                  admittedGitHubRepositories.set(
                    instance.root,
                    repositoriesByWorkspace?.get(instance.sourceWorkspaceId),
                  );
                }
                const id = internalWorkspaceId(instance.sourceWorkspaceId, instance.id);
                await nativeCommandSandbox.registerRoot(id, {
                  ...nativeOptionsForWorkspace(instance.sourceWorkspaceId),
                  workspaceIdentity: instance.identity,
                  workspaceRoot: instance.root,
                });
                await prepareCodeEnvironment({
                  snapshotStore: environment!.snapshotStore,
                  storage: environment!.definition.storage,
                  snapshotScope: environment!.definition.repo ?? environment!.definition.name,
                  root: instance.root, identity: instance.identity, setup,
                  receiptPath: preparationReceipt(instance.root),
                  context: JSON.stringify([serializeNativeSrtCommandPolicy(commandPolicy), commandAllowedDomains, github.policyIdentity,
                    nativeOptionsForWorkspace(instance.sourceWorkspaceId).resources]),
                  signal,
                  execute: (command, timeoutMs) => nativeCommandSandbox.execute({
                    protocolVersion: 1,
                    operation: 'execute_command',
                    workspaceId: id,
                    command,
                    timeoutMs,
                    maxOutputBytes: 8192,
                  }, signal),
                });
              },
              discardInstance: async (instance) => {
                await nativeCommandSandbox.unregisterRoot(
                  internalWorkspaceId(instance.sourceWorkspaceId, instance.id),
                );
                admittedGitHubRepositories?.delete(instance.root);
              },
            }
          : {}),
        sources: new Map(
          await Promise.all(
            roots.map(async (root) => [
              root.id,
              {
                root: root.root,
                identity:
                  root.identity ??
                  (await captureWorkspaceRootIdentity(root.root)),
              },
            ] as const),
          ),
        ),
      })
    : undefined;
  let conversationWorkspaceTools: GitWorktreeWorkspaceTools | undefined;
  if (conversationWorktrees && workspaceTools) {
    if (!(nativeCommandSandbox instanceof NativeWorkspaceCommandPool)) {
      throw new Error('Conversation worktrees require a native command pool');
    }
    conversationWorkspaceTools = new GitWorktreeWorkspaceTools({
      commandPool: nativeCommandSandbox,
      delegate: workspaceTools,
      manager: conversationWorktrees,
      onResolve(workspaceId, root) {
        if (admittedGitHubRepositories) {
          admittedGitHubRepositories.set(
            root,
            repositoriesByWorkspace?.get(workspaceId),
          );
        }
      },
      sources: new Map(
        roots.map((root) => [
          root.id,
          {
            command: {
              ...nativeOptionsForWorkspace(root.id),
              workspaceIdentity: root.identity,
              workspaceRoot: root.root,
            },
            repositoryInstructions: args.includes('--repository-instructions'),
            writable: root.writable ?? false,
          },
        ]),
      ),
    });
    workspaceTools = conversationWorkspaceTools;
  }
  let linkedWorktreeTools: LinkedWorktreeWorkspaceTools | undefined;
  if (linkedWorktreeLanes && workspaceTools) {
    if (!(nativeCommandSandbox instanceof NativeWorkspaceCommandPool)) {
      throw new Error('Linked worktree lanes require a native command pool');
    }
    linkedWorktreeTools = new LinkedWorktreeWorkspaceTools({
      commandPool: nativeCommandSandbox,
      delegate: workspaceTools,
      programmaticDelegate: conversationWorkspaceTools ?? nativeCommandSandbox,
      onResolve(workspaceId, root) {
        if (admittedGitHubRepositories) {
          admittedGitHubRepositories.set(
            root,
            repositoriesByWorkspace?.get(workspaceId),
          );
        }
      },
      onRelease(root) {
        admittedGitHubRepositories?.delete(root);
      },
      sources: new Map(
        roots.map((root) => [
          root.id,
          {
            root: root.root,
            identity: root.identity,
            command: nativeOptionsForWorkspace(root.id),
            repositoryInstructions: args.includes('--repository-instructions'),
            writable: root.writable ?? false,
          },
        ]),
      ),
    });
    workspaceTools = linkedWorktreeTools;
  }
  const retirementSources = roots.filter((root) => root.writable);
  const debugLogs =
    process.env.LIBRECHAT_CODE_LOG_LEVEL?.trim().toLowerCase() === 'debug';
  const worktreeRetirementScheduler =
    linkedWorktreeTools &&
    worktreeRetirement.enabled &&
    retirementSources.length > 0 &&
    option(args, '--reset-workspace-quarantine') == null
      ? new WorktreeRetirementScheduler({
          activity: linkedWorktreeTools,
          idleMs: worktreeRetirement.idleMs,
          sources: retirementSources.map((root) => ({
            workspaceId: root.id,
            root: root.root,
            identity: root.identity,
          })),
          async isQuarantined(selectedWorkspaceId, worktree) {
            const source = roots.find((root) => root.id === selectedWorkspaceId);
            if (!source) return true;
            const path =
              worktree == null
                ? rootQuarantinePaths.get(selectedWorkspaceId)!
                : defaultWorkspaceQuarantinePath({
                    codeApiUrl,
                    workerId,
                    workspaceRoot: join(source.root, LINKED_WORKTREE_DIRECTORY, worktree),
                  });
            return (await loadWorkspaceMutationQuarantine(path)) != null;
          },
          log(level, message) {
            if (level === 'debug' && !debugLogs) return;
            process.stdout.write(`librechat-code: ${message}\n`);
          },
        })
      : undefined;
    if (workspaceTools && environments.length) {
        workspaceTools = new EnvironmentWorkspaceTools(
            workspaceTools,
            environments,
        );
    }
  const capabilities = {
    statefulWorkspace,
    sandboxProfile:
      process.env.LIBRECHAT_CODE_SANDBOX_PROFILE ??
      (allowWorkspaceCommands && commandSandboxMode === 'native-srt'
        ? commandPolicy.preset === 'restricted'
          ? 'anthropic-srt'
          : `anthropic-srt:${commandPolicy.preset}`
        : runtimeMode.startsWith('docker')
          ? 'oci-docker'
          : 'nsjail'),
    runtimes: list(process.env.LIBRECHAT_CODE_RUNTIMES),
    policyDigest: createHash('sha256')
      .update(policy)
      .update(
                environments.length
                    ? `\0environments\0${environments.map(environment => environment.fingerprint).join('\0')}`
                    : '',
            )
            .update(
        allowWorkspaceCommands && commandSandboxMode === 'native-srt'
          ? `\0native-srt\0${serializeNativeSrtCommandPolicy(commandPolicy)}\0${commandAllowedDomains.join('\0')}\0${github.policyIdentity}`
          : '',
      )
      .digest('hex'),
    ...(fileRelayEnabled ? { requiresReadyConfirmation: true } : {}),
    ...(workspaceLeaseSlots > 1
      ? { workspaceLeaseSlots, requiresReadyConfirmation: true }
      : {}),
        ...(workspaceTools
            ? { workspaceTools: workspaceTools.capabilities }
            : {}),
  };
  if (!isValidBridgeWorkerCapabilities(capabilities)) {
    await fileRelaySupervisor?.stop().catch(() => undefined);
    throw new Error(
      'LIBRECHAT_CODE_SANDBOX_PROFILE or LIBRECHAT_CODE_RUNTIMES is invalid',
    );
  }
  try {
    await github.provider?.validate?.(controller.signal);
    if (github.provider && !github.provider.validate) {
      await github.provider.getCredential(controller.signal);
    }
    await conversationWorktrees?.prepare();
    await nativeCommandSandbox?.prepare();
        for (const environment of option(args, '--reset-workspace-quarantine') == null ? environments : []) {
            const setup = environment.definition.setup;
            if (!setup || !nativeCommandSandbox) continue;
            const id = environment.definition.name;
            const guard = workspaceMutationGuard(
                rootQuarantinePaths.get(id)!,
                workerId,
                id,
                incarnationId,
            );
            await guard.assertAvailable();
            let armed = false;
            const preparation = await prepareCodeEnvironment({
                snapshotStore: environment.snapshotStore,
                storage: environment.definition.storage,
                snapshotScope: environment.definition.repo ?? environment.definition.name,
                beforeMutation: async () => {
                  if (!armed) { await guard.arm('Dependency restoration did not settle', 'setup'); armed = true; }
                },
                root: environment.definition.root,
                identity: roots.find(root => root.id === id)!.identity!,
                setup, receiptPath: preparationReceipt(environment.definition.root),
                reclaimSpace: worktreeRetirementScheduler
                  ? () => worktreeRetirementScheduler.runNow()
                  : undefined,
                context: JSON.stringify([serializeNativeSrtCommandPolicy(commandPolicy), commandAllowedDomains, github.policyIdentity,
                  nativeOptionsForWorkspace(id).resources]),
                signal: controller.signal,
                execute: async (command, timeoutMs) => {
                  if (!armed) {
                    await guard.arm('Environment preparation did not settle', 'setup');
                    armed = true;
                  }
                  return nativeCommandSandbox.execute({
                    protocolVersion: 1,
                    operation: 'execute_command',
                    workspaceId: id,
                    command,
                    timeoutMs,
                    maxOutputBytes: 8192,
                  }, controller.signal);
                },
            }).catch(error => {
                throw new Error(
                    `Environment ${id} setup failed; inspect the workspace and use clear-workspace-quarantine with its root and workspace ID before restarting`,
                    { cause: error },
                );
            });
            await guard.clear('setup');
            process.stdout.write(
                `librechat-code: environment ${id} ${preparation}\n`,
            );
        }
  } catch (error) {
    await worktreeRetirementScheduler?.stop().catch(() => undefined);
    await nativeCommandSandbox?.close().catch(() => undefined);
    await fileRelaySupervisor?.stop().catch(() => undefined);
    throw error;
  }
  worktreeRetirementScheduler?.start();
  try {
    const worker = new BridgeWorker({
      instructionDescriptors: () => localWorkspaceTools?.instructionDescriptors() ?? Promise.resolve(undefined),
      codeApiUrl,
      token: configuredToken,
      identity: workerIdentity,
      workerId,
      incarnationId,
      runtimeSupervisor,
      capabilities,
      workspaceTools,
      ...(nativeProgrammaticEnabled && nativeCommandSandbox
        ? {
            workspaceProgrammatic:
              linkedWorktreeTools ?? conversationWorkspaceTools ?? nativeCommandSandbox,
          }
        : {}),
      ...(conversationWorktrees
        ? {
            workspaceQuarantineResolver: async (
              selectedWorkspaceId: string,
              workspaceInstanceId: string,
            ) =>
              workspaceMutationGuard(
                defaultWorkspaceQuarantinePath({
                  codeApiUrl,
                  workerId,
                  workspaceRoot: await conversationWorktrees.plannedRoot(
                    selectedWorkspaceId,
                    workspaceInstanceId,
                  ),
                }),
                workerId,
                workspaceIsolationKey(
                  selectedWorkspaceId,
                  workspaceInstanceId,
                ),
                incarnationId,
              ),
          }
        : {}),
      ...(linkedWorktreeTools
        ? {
            linkedWorktreeQuarantineResolver: (
              selectedWorkspaceId: string,
              worktree: string,
            ) => {
              const source = roots.find((root) => root.id === selectedWorkspaceId);
              if (!source) {
                throw new BridgeProtocolError('Linked worktree source is not registered');
              }
              return workspaceMutationGuard(
                defaultWorkspaceQuarantinePath({
                  codeApiUrl,
                  workerId,
                  workspaceRoot: join(source.root, LINKED_WORKTREE_DIRECTORY, worktree),
                }),
                workerId,
                workspaceIsolationKey(selectedWorkspaceId, undefined, worktree),
                incarnationId,
              );
            },
            linkedWorktreeNames: async (selectedWorkspaceId: string) => {
              const source = roots.find((root) => root.id === selectedWorkspaceId);
              if (!source) return [];
              try {
                const entries = await readdir(join(source.root, LINKED_WORKTREE_DIRECTORY));
                return entries.filter(isValidLinkedWorktreeName);
              } catch (error) {
                if ((error as NodeJS.ErrnoException).code === 'ENOENT') return [];
                throw error;
              }
            },
          }
        : {}),
      ...(workspaceLeaseSlots > 1 || roots.length > 1
        ? {
            workspaceQuarantines: new Map(
                          roots.map(root => [
                root.id,
                workspaceMutationGuard(
                  rootQuarantinePaths.get(root.id)!,
                  workerId,
                  root.id,
                  incarnationId,
                ),
              ]),
            ),
          }
        : {}),
      workspaceMutationQuarantine:
        mutationQuarantinePath &&
        workspaceLeaseSlots === 1 &&
        roots.length === 1
          ? {
              async assertAvailable() {
                              const record =
                                  await loadWorkspaceMutationQuarantine(
                  mutationQuarantinePath,
                );
                if (record != null) {
                  throw new BridgeProtocolError(
                    `Workspace mutations are quarantined since ${record.quarantinedAt}: ${record.reason}. Inspect or restore the workspace, then run librechat-code clear-workspace-quarantine`,
                    undefined,
                    'WORKER_QUARANTINED',
                  );
                }
              },
              async arm(reason) {
                              await saveWorkspaceMutationQuarantine(
                                  mutationQuarantinePath,
                                  {
                  version: 1,
                  workerId,
                  workspaceId,
                  ownerId: incarnationId,
                  quarantinedAt: new Date().toISOString(),
                  reason,
              },
                              );
                          },
              async clear() {
                await clearWorkspaceMutationQuarantine(
                  mutationQuarantinePath,
                  incarnationId,
                );
              },
              async quarantine() {
                await assertWorkspaceMutationQuarantineOwner(
                  mutationQuarantinePath,
                  incarnationId,
                );
              },
            }
          : undefined,
      onIdentityChange:
        pairedIdentity && identityPath
                    ? async identity => {
              await saveBridgeIdentity(identityPath, {
                ...pairedIdentity,
                credential: identity.credential,
                expiresAt: identity.expiresAt,
              });
            }
          : undefined,
      onRegistered: fileRelaySupervisor
                ? async registration => {
            if (
              registration.registrationGeneration == null ||
                          !Number.isSafeInteger(
                              registration.registrationGeneration,
                          ) ||
              registration.registrationGeneration < 1
            ) {
              throw new Error(
                'Code API does not support registration-ordered file relay activation',
              );
            }
            await fileRelaySupervisor.activate(
              registration.registrationGeneration,
              controller.signal,
            );
          }
        : undefined,
            onError: error => {
        const message =
                    error instanceof Error
                        ? error.message
                        : 'unknown bridge error';
                process.stderr.write(
                    `librechat-code: reconnecting after ${message}\n`,
                );
      },
    });
    if (runtimeSessionId !== undefined) {
      await worker.refreshCredential(controller.signal);
      await worker.register(controller.signal);
      await worker.resetWorkspace(runtimeSessionId, controller.signal);
      process.stdout.write(
        `librechat-code: reset acknowledged for ${runtimeSessionId}\n`,
      );
      return;
    }
    const resetNativeRoot = option(args, '--reset-workspace-quarantine');
    if (resetNativeRoot != null) {
      const resetWorkspaceInstance = option(
        args,
        '--reset-workspace-instance',
      );
      const resetWorkspaceWorktree = option(
        args,
        '--reset-workspace-worktree',
      );
      await worker.refreshCredential(controller.signal);
      await worker.registerForMaintenance(controller.signal);
            await worker.resetNativeWorkspace(
                resetNativeRoot,
                controller.signal,
                resetWorkspaceInstance,
                resetWorkspaceWorktree,
            );
      process.stdout.write(
        `librechat-code: reset acknowledged for native workspace ${resetNativeRoot}${resetWorkspaceInstance ? ` instance ${resetWorkspaceInstance}` : ''}${resetWorkspaceWorktree ? ` worktree ${resetWorkspaceWorktree}` : ''}\n`,
      );
      return;
    }
    await worker.run(controller.signal);
  } finally {
    try {
      await worktreeRetirementScheduler?.stop();
      await nativeCommandSandbox?.close();
    } finally {
      await fileRelaySupervisor?.stop();
    }
  }
}

async function clearMutationQuarantine(args: string[]): Promise<void> {
  const configuredWorkerId = process.env.LIBRECHAT_CODE_WORKER_ID?.trim();
  const configuredIdentityPath =
    process.env.LIBRECHAT_CODE_IDENTITY_FILE?.trim();
  const configuredToken = process.env.LIBRECHAT_CODE_WORKER_TOKEN?.trim();
  const identityPath =
    configuredIdentityPath ??
    (configuredWorkerId && !configuredToken
      ? defaultBridgeIdentityPath(configuredWorkerId)
      : undefined);
  const pairedIdentity = identityPath
    ? await loadBridgeIdentity(identityPath)
    : undefined;
  const workerId = required(
    'LIBRECHAT_CODE_WORKER_ID',
    configuredWorkerId ?? pairedIdentity?.workerId,
  );
  const codeApiUrl = required(
    'LIBRECHAT_CODE_URL',
    process.env.LIBRECHAT_CODE_URL ?? pairedIdentity?.codeApiUrl,
  );
  const workspaceId =
    option(args, '--workspace-id') ??
    process.env.LIBRECHAT_CODE_WORKSPACE_ID?.trim() ??
    'primary';
  const explicitWorkerDirectory = nonEmpty(
    option(args, '--worker-dir') ??
      process.env.LIBRECHAT_CODE_WORKER_DIR?.trim(),
  );
  const useDefaultWorkspace =
    args.includes('--default-workspace') ||
    process.env.LIBRECHAT_CODE_DEFAULT_WORKSPACE?.trim().toLowerCase() ===
      'true';
  if (explicitWorkerDirectory && useDefaultWorkspace) {
    throw new Error(
      '--worker-dir and --default-workspace cannot be used together',
    );
  }
  const workerDirectory =
    explicitWorkerDirectory ??
    (useDefaultWorkspace
      ? defaultWorkspacePath({
          codeApiUrl,
          securityIdentity: workspaceSecurityIdentity(
            pairedIdentity?.publicKey,
            configuredToken,
          ),
          workerId,
          workspaceId,
        })
      : undefined);
  const path = workspaceQuarantinePath({
    codeApiUrl,
    workerId,
    workspaceRoot: workerDirectory
      ? await realpath(workerDirectory)
      : undefined,
  });
  await clearWorkspaceMutationQuarantine(path);
  process.stdout.write(
    `librechat-code: cleared workspace mutation quarantine for ${workspaceId}\n`,
  );
}

async function main(): Promise<void> {
  const args = process.argv.slice(2);
  if (args[0] === 'prune-environment-storage') {
    const paths: string[] = [];
    for (let i = 1; i < args.length; i++) {
      if (args[i] === '--apply') continue;
      if (args[i] !== '--environment' || !args[i + 1] || args[i + 1].startsWith('--'))
        throw new Error('Usage: librechat-code prune-environment-storage --environment <file> [--environment <file> ...] [--apply]');
      paths.push(args[++i]);
    }
    if (!paths.length || paths.length > 32) throw new Error('Supply between one and 32 environment definitions');
    const loaded = await Promise.all(paths.map(loadCodeEnvironment));
    const roots = loaded.map(environment => ({ id: environment.definition.name, root: environment.definition.root }));
    const stores = loaded.flatMap(environment => environment.snapshotStore ? [environment.snapshotStore] : []);
    if (!stores.length) throw new Error('No dependency snapshot stores configured');
    await assertEnvironmentDefinitionsOutsideRoots(loaded, roots);
    await assertEnvironmentDefinitionsOutsideRoots(stores.map(store => ({ path: store.store, sourceParents: store.controlPaths,
      definition: { name: 'dependency-store', root: store.store }, fingerprint: '' })), roots);
    await assertEnvironmentResourceIsolation(stores.map(store => ({ kind: 'npm-cache' as const, path: store.store, access: 'read-only' as const })),
      roots.map(root => root.root), [...loaded.map(environment => environment.path),
        ...loaded.flatMap(environment => (environment.resources ?? []).map(resource => resource.path))]);
    for (const store of stores) process.stdout.write(`${JSON.stringify(await pruneDependencySnapshots(store, { dryRun: !args.includes('--apply') }))}\n`);
    return;
  }
  if (args[0] === 'projects') {
    const root = option(args, '--root');
    if (!root || args.slice(1).some((arg, index, rest) =>
        arg !== '--root' && rest[index - 1] !== '--root' && !arg.startsWith('--root='))) {
      throw new Error('Usage: librechat-code projects --root <directory>');
    }
    const inventory = await discoverProjects({ root });
    process.stdout.write(`${JSON.stringify(inventory, null, 2)}\n`);
    return;
  }
  if (args[0] === 'relay') {
    await relay();
    return;
  }
  if (args[0] === 'pair') {
    await pair(args);
    return;
  }
  if (args[0] === 'reset-workspace') {
    const runtimeSessionId = args[1]?.trim();
    if (!runtimeSessionId) {
      throw new Error(
        'Usage: librechat-code reset-workspace <runtime-session-id>',
      );
    }
    await run(runtimeSessionId);
    return;
  }
  if (args[0] === 'clear-workspace-quarantine') {
    await clearMutationQuarantine(args.slice(1));
    return;
  }
  if (args[0] && args[0] !== 'run') {
    throw new Error(`Unknown command: ${args[0]}`);
  }
  await run(undefined, args.slice(1));
}
main().catch((error: Error) => {
  process.stderr.write(`librechat-code: ${error.message}\n`);
  process.exitCode = 1;
});
