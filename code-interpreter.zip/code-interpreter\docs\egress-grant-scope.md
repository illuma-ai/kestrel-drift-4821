# Egress grant scope: ledger-resident instead of header-resident

## Problem

Every sandbox-originated download/list/upload request to the egress gateway
carries the sealed egress grant token verbatim as the `X-CodeAPI-Egress-Grant`
HTTP header. The token enumerates the job's entire file scope — one
`input_files` entry per readable file, plus `read_sessions` — because that is
what `assertGrantSession()` and `isAllowedReadObject()` authorize against.

That is fine for a handful of user-uploaded files. It stops being fine once a
job primes a skill bundle: a real trigger observed in production was a job
carrying 30+ files from a single skill session (paths like
`skills/pptx/reference/deep/path/file-<n>.md`, one shared `read_sessions`
entry per skill version). The serialized, encrypted, base64'd token for a job
like that exceeds the HTTP server's ~16KB header limit. The server answers
**431 Request Header Fields Too Large** before any route handler runs — there
is no application-level error to catch, log a reason for, or retry. The
sandbox logs a bare `HTTP error: 431` and the user sees only "Code execution
is temporarily unavailable," with nothing in the chain naming a header size
limit as the cause.

## Verified architecture (why this fix is safe)

The gateway's internal `POST /internal/egress-grants` route already receives
the full scope in the **request body**, not the header — upstream moved grant
minting off the header for exactly this reason (see the header-size comment
in `sandbox-dispatch.ts`). And it already writes that identical scope into the
Redis-backed egress ledger via `createEgressLedger` (`egress-ledger.ts`),
keyed by `grant_id`, with a TTL of the grant's `exp` plus a grace window
(`ttlSeconds`). Every download the sandbox makes already round-trips to that
same ledger record via `assertEgressGrantActive()` for its budget/revocation
check. `EGRESS_LEDGER_REQUIRED` is forced `true` under hardened mode
(`config.ts`), so the ledger is guaranteed to exist for every grant hardened
mode issues.

In other words: the full scope already lives in two places (the sealed token
and the ledger) for every hardened-mode job. The header only needs to carry
one of them.

## Design

A **compact** grant token is a sealed `EgressGrantClaims` with `input_files`
and `read_sessions` stripped to empty arrays, plus a new marker field,
`scope_ref: 'ledger'`. Compact tokens are the same size regardless of file
count — measured at 575 bytes for both 60 and 600 primed skill files — because
the file list itself never enters the token.

- **`prepareSandboxEgress({ ..., compactScope: true })`** (`egress-grant.ts`)
  seals the compact token and separately returns `egressGrantClaims`: the
  full, unstripped claims. The `/internal/egress-grants` route builds the
  ledger record from `egressGrantClaims`, not by re-opening the sealed token —
  re-opening a compact token only round-trips back to an empty scope, so
  building the ledger that way would silently ledger an unusable grant.
- **`hydrateGrantScope()`** (`egress-gateway.ts`) fills `input_files`/
  `read_sessions` back onto an opened grant from its `EgressLedgerRecord` when
  `scope_ref === 'ledger'`. It is a no-op for fat (legacy) tokens. Every
  gateway call site that opens a sandbox-presented token and then reads file
  scope calls it: `getGrant()` (all `/sessions/*` download/list/upload
  routes) and `restoreInternalSandboxResult()` (`/restore-result`). The
  `/revoke` route opens a token too but never reads `input_files`/
  `read_sessions` — revocation only needs `grant_id`/`exec_id` — so it is
  correctly left unhydrated.
- **Authorization is unchanged.** `hydrateGrantScope()` runs before
  `assertGrantSession()` or `isAllowedReadObject()` ever see the grant, so
  both functions keep operating on a claims object carrying the real
  per-file scope. Nothing about *what* is authorized changes — only *where
  the list is fetched from* changes.
- **Missing ledger record is a distinct failure.** If a compact grant's
  ledger record is gone (evicted, TTL misconfigured, cross-region Redis
  failover), `loadRecord()` throws `EgressGrantError('compact_scope_missing',
  ...)` instead of reusing the generic `scope_mismatch` reason every other
  ledger-miss path already uses, and logs a line naming the grant hash and
  the ledger. For a compact grant, a missing record means the *entire* scope
  is unrecoverable — an operational/TTL problem, not an authorization
  decision — and that distinction needs to be visible in logs and alerts
  without correlating against the fact that the token happened to be
  compact.
- **Back-compat is unconditional.** A fat token simply never sets
  `scope_ref`; `validateGrant()` treats it as absent (a no-op check), and
  `hydrateGrantScope()` returns immediately for it. Fat tokens flow through
  every code path exactly as before the fix — including tokens minted by an
  old caller and tokens sealed while the kill switch (below) is off.

## Rollout / operations

**Kill switch:** `CODEAPI_EGRESS_COMPACT_GRANTS` (`config.ts`,
`env.EGRESS_COMPACT_GRANTS`). Defaults to `true` whenever
`EGRESS_LEDGER_REQUIRED` is true (compact tokens are useless without a
guaranteed ledger, so the default can never be true when the ledger isn't
required). An explicit `CODEAPI_EGRESS_COMPACT_GRANTS=false` forces fat
sealing without a rebuild. **The flag only governs sealing** — the gateway
accepts and hydrates a compact token regardless of the flag's state on the
replica that receives the download.

**EKS mixed-version rollout note:** during a rolling deploy, old
egress-gateway replicas (predating `hydrateGrantScope()`) cannot hydrate a
compact grant's scope — they will read `input_files`/`read_sessions` as empty
and reject every download from a job whose grant was minted compact by a new
replica. Deploy the gateway (and its ledger-hydration code) to 100% **before**
any replica starts sealing compact tokens, or set
`CODEAPI_EGRESS_COMPACT_GRANTS=false` for the duration of the rollout and flip
it back once every replica is on the new code.

**Symptom of the distinct error in practice:** a spike in
`compact_scope_missing` (as opposed to `scope_mismatch`) rejections points at
the ledger, not at authorization — check Redis TTL configuration, eviction
policy, or a failover window, not the grant-minting logic.

## Upstream-merge guidance

**Files carrying this delta:**

| File | What changed |
|---|---|
| `service/src/egress-grant.ts` | `EgressGrantClaims.scope_ref`; `prepareSandboxEgress`'s `compactScope` option; `PreparedSandboxEgress.egressGrantClaims`; `restoreSandboxExecuteResult`'s `preOpenedGrant` param |
| `service/src/egress-gateway.ts` | `hydrateGrantScope()`; hydration call sites in `getGrant()` and `restoreInternalSandboxResult()`; explicit response-field allowlist on `POST /internal/egress-grants` (so `egressGrantClaims` never leaks into the JSON response) |
| `service/src/egress-ledger.ts` | `loadRecord()` takes the grant (not a bare id) to branch on `scope_ref`; `compact_scope_missing` error path; `readEgressLedgerRecord()` export |
| `service/src/config.ts` | `EGRESS_COMPACT_GRANTS` kill switch |

**How to tell a conflicting upstream change from a superseding one:**

- *Conflicts* — upstream touches the same functions for an unrelated reason
  (e.g. changes what `assertGrantSession()` checks, or restructures
  `EgressGrantClaims`). Merge normally; re-apply the `scope_ref` branch and
  the hydration call sites against the new shape. This delta's job is
  narrow — filling in two array fields before authorization runs — so it
  should rebase cleanly onto most upstream changes to the surrounding logic.
- *Supersedes* — upstream ships its **own** bounded-grant mechanism: a
  grant-by-reference scheme, its own ledger-resident scope, or per-file
  handles that replace the enumerated `input_files` list entirely. In that
  case, **prefer upstream's version and delete this entire delta**
  (`scope_ref`, `compactScope`, `hydrateGrantScope`, the ledger's
  grant-aware `loadRecord`, and the kill switch). Do not run both
  mechanisms side by side.

**Deletion criterion — upstream's replacement must pass all three before this
delta is removed:**

1. **Size proof holds.** A sealed grant token for a 100+ file skill-heavy job
   stays under the HTTP header limit regardless of file count (this fork's
   test asserts a 150-file grant's compact-equivalent token stays under 4KB
   while the fat token exceeds 16KB — reproduce the equivalent bound against
   upstream's mechanism).
2. **Per-file authorization is still enforced.** A file outside the granted
   scope is still denied — upstream's mechanism must not trade precision for
   size by widening what a grant authorizes (e.g. session-level instead of
   file-level access).
3. **A back-compat window exists.** Old tokens (or old replicas) keep working
   during a rolling deploy — either upstream's tokens are self-describing the
   same way (a marker byte/field), or there is an operator-controlled rollout
   switch equivalent to `CODEAPI_EGRESS_COMPACT_GRANTS`.

If upstream's mechanism does not clear all three, keep this delta rather than
adopting a regression.
