# Upstream deltas

Everything this fork changes relative to `upstream/main`
(ClickHouse/code-interpreter), and why. Keep this file current — it is what the
next upstream merge is triaged against.

`git diff main develop` is always the authoritative diff; this document explains
the intent behind it.

## Guiding rule

Deltas are **additive wherever possible** — a new file or a compose overlay
rather than an edit to an upstream file — so upstream merges stay conflict-free
and the fork stays cleanly pullable. Every fork-owned file or hunk carries an
`UPSTREAM DELTA` comment stating why it exists.

---

## 1. Document preview rendering (functional delta)

**Why:** the host platform previews uploaded Word/Excel/PowerPoint/ODF files
page-perfectly — the document is converted to PDF once and the client paints
that PDF. Upstream has no such capability, correctly: rendering a document is
not code execution. This is a host-platform feature that happens to need the
same file/storage plumbing, so it lives here rather than in the chat app.

**Files (all new):**

| File | Role |
|---|---|
| `service/src/document-renderer.ts` | Stateless LibreOffice/poppler sidecar |
| `service/Dockerfile.document-renderer` | Renderer image (LibreOffice, poppler, fonts) |
| `service/src/service/documents-router.ts` | `/v1/documents/*` routes |

**Touched upstream files** (one import + one mount line each — deliberately the
smallest possible footprint):

- `service/src/local-api.ts`
- `service/src/api-server.ts`

**Endpoints:**

| Path | Produces |
|---|---|
| `POST /v1/documents/preview` | A PDF rendition of an office document |
| `POST /v1/documents/pages` | Per-page images + text of a PDF |

Both accept either a stored-object reference (`{ session_id, file_id }`) or a
multipart upload, and both persist their output as a normal stored object
retrievable via `GET /v1/download/:session_id/:file_id`.

These replace the retired in-house executor's `POST /render/pdf` and
`POST /render/pages`. They were renamed on adoption: "render" alone named
neither the domain nor the produced artifact, and the routes sat at the API root
beside code-execution routes.

**Why a sidecar rather than adding LibreOffice to the sandbox image:**

1. The upstream sandbox rootfs stays byte-identical — a ~1 GB toolchain in an
   image whose purpose is a minimal attack surface would be a permanent,
   conflict-prone delta.
2. Rendering is bursty and CPU-heavy; it scales independently of execution.
3. Single responsibility — the sidecar only transcodes bytes.

**Security posture:** the sidecar is pure compute. It holds no credentials, has
no storage access, and never reaches S3 or Redis — the API router owns all
persistence and passes bytes in and out. It is internal-network only and gated
by the shared internal-service token. Because LibreOffice parsing untrusted
documents is a large attack surface, the container runs non-root with a
read-only rootfs, tmpfs scratch, `no-new-privileges`, and a per-request timeout.

---

### Sandbox toolchain: what the skills need, and what cannot be there

The host platform's document skills run **inside the sandbox** and shell out to
external binaries. Two additions to `api/Dockerfile`'s sandbox rootfs, plus two
to the Python package set (`docker/package-init.sh`):

| Added | Why |
|---|---|
| `tesseract-ocr` + `-eng` | `pytesseract` shipped but was inert without its binary — verified working in-sandbox |
| `fonts-noto-core` | wider glyph coverage for generated documents |
| `pypdf` | the skills import the modern package; only legacy `pypdf2` shipped |
| `pdfplumber` | text/table extraction in the PDF skill |

Also added to `api/config/sandbox.cfg` (NsJail mounts), because their absence
breaks ordinary workloads and the symptoms are opaque:

| Mount | Absent symptom |
|---|---|
| `/dev/shm` (tmpfs, noexec) | `shm_open` fails; joblib logs `[Errno 2]` and drops to serial mode |
| `/etc/passwd`, `/etc/group` (ro) | `getpwuid()` raises for the sandbox uid |
| `/etc/fonts` (ro) | fontconfig cannot initialize; glyphs substitute silently |
| `/dev/random` (ro) | crypto paths that open it directly fail |

### Seccomp: graceful denial instead of fatal denial

`memfd_create` and `personality` moved from `KILL` to `ERRNO(ENOSYS)`, joining
`clone3`. Userspace *probes* these and has fallbacks keyed on `-ENOSYS`; a
`KILL` delivers SIGSYS before any fallback can run, turning a recoverable
"this kernel is older than I hoped" branch into an abort. Both syscalls remain
denied — an anonymous memfd still cannot be created, and `personality` still
cannot disable ASLR — only the failure *mode* changes. This is the pattern
Docker's default profile uses for `clone3`.

`execveat` is now `KILL`ed, which it previously was not (it fell through to
`DEFAULT ALLOW`). The threat that motivates denying `memfd_create` is
`memfd + execveat` — write code to an anonymous file, then execute it without
it ever touching a filesystem. Blocking the *execution* half is the tighter
control: `memfd_create` only creates a file object, while `execveat` is what
turns any fd into a running program. **This is a net security improvement**
independent of anything below.

### LibreOffice in the sandbox: one missing bind mount

`soffice` aborted during UNO bootstrap — even `soffice --version` — with a bare
`terminate called after throwing an instance of
'com::sun::star::uno::RuntimeException'` and nothing else. No stack, no
`SAL_LOG` output, no indication a file was involved.

**Cause:** Debian's `libreoffice-common` ships the core configuration registry as
a symlink *out of* `/usr`:

```
/usr/lib/libreoffice/share/registry/main.xcd -> /etc/libreoffice/registry/main.xcd
```

The sandbox binds all of `/usr` read-only but only individual `/etc` **files**, so
that symlink dangled. `configmgr` could not open the one registry it cannot
start without, and threw. Found by `strace`-ing a passing (bare container) run
against a failing (jailed) run and diffing: the sole meaningful divergence was
`openat(".../main.xcd") = 11` versus `= -1 ENOENT`, immediately followed by the
abort.

**Fix:** bind-mount `/etc/libreoffice` read-only (the directory, not just
`registry/` — `psprint.conf` lives there too). `/etc/localtime` is mounted
alongside so document timestamps are not forced to UTC.

Nothing else was required. Everything below was tried first and **none of it was
the cause** — all reverted so the sandbox keeps its original posture:

| Tried and reverted | Verified irrelevant |
|---|---|
| Raising the 64-task ceiling (`cgroup_pids_max` + `--rlimit_nproc`) to 1024 | 300 threads created, still aborted |
| Mounting `/sys` | present, still aborted |
| `memfd_create`/`personality` as ENOSYS, then fully permitted | verified applied, still aborted |
| Removing the seccomp policy entirely | still aborted |
| `--rlimit_as` unlimited | still aborted (16 GiB was never the constraint) |

The lesson worth keeping: an opaque C++ abort with no diagnostic is far more
often a missing *file* than a blocked *syscall*. Differential `strace` against a
working environment found in one pass what syscall-policy reasoning missed
across several.

#### Constraint on any fix: the document skills are NOT ours to patch

The skills that call `soffice` are third-party artifacts that get updated
upstream. Editing them to call a different endpoint would fork them, and every
future skill update would either break or silently revert the change — the same
trap that maintaining a whole in-house executor was.

So whatever makes document operations work must make **`soffice` itself behave
correctly from inside the sandbox**, with the skills untouched. The shape that
satisfies this is a shim on the sandbox PATH that speaks the LibreOffice command
line and forwards the work to the renderer service, which is where real
LibreOffice lives. The delta then sits in this repo (sandbox image + a renderer
endpoint), which is where a fork delta belongs.

Consequence: skill code must not shell out to `soffice`. Anything needing a
rendition should call the preview endpoint, which is what the
`document_renderer` sidecar exists for.

---

## Sandbox network policy: hermetic, and why

The sandbox has **no egress at all** — `AF_INET` is denied by seccomp, there is
no resolver, and no proxy is configured. Verified: DNS returns `gaierror` for
every external name and a TCP connect returns `PermissionError`.

Consequence: **runtime `pip install` / `npm install` cannot work.** Packages must
be baked into `docker/package-init.sh` / `javascript-packages.txt`. `npm` is set
to `offline` mode so a missing package errors in about a second rather than
retrying a registry it cannot reach until the job timeout — a five-minute stall
that also consumes a worker slot. `pip` already failed fast.

### The alternative, and why we have not taken it

A hosted comparison (Anthropic's own code interpreter, probed directly) runs a
**transparent TLS-intercepting egress gateway** instead:

| | Behaviour |
|---|---|
| Allowed | `registry.npmjs.org`, `pypi.org`, `files.pythonhosted.org`, `raw.githubusercontent.com`, `archive.ubuntu.com` |
| Denied host | HTTP **403** with `x-deny-reason: host_not_allowed` and a body naming the host |
| Raw IPs | denied unconditionally — including the registry's own IP |
| Ports | 80/443 only; TCP/53 blocked |
| Mechanism | private CA injected into the trust store (`SSL_CERT_FILE`, `REQUESTS_CA_BUNDLE`, `NODE_EXTRA_CA_CERTS`) — **not** `http_proxy`, which half the ecosystem ignores |

Worth copying if we ever open egress: allowlist by **hostname** (never IP),
restrict to 80/443, and make denials an in-band 403 with a machine-readable
reason — a stall or a TCP reset costs far more debugging time than a 403 does.

**Why we stay hermetic for now:** a permitted registry is still an exfiltration
channel (package names, versions and timing leak; both registries accept
uploads), and TLS inspection means the gateway sees plaintext credentials. The
skill package set is small and stable, so baking it costs little.

**If arbitrary packages become a requirement,** go to a **pull-through cache**
(Verdaccio / devpi / Artifactory) rather than direct allowlisted egress. Same
ergonomics — no image churn — plus request logging, version pinning, and a
chokepoint against typosquatting that an open allowlist does not provide.

---

## 1b. Image outputs as vision blocks (functional delta)

**Why:** the host builds the code-tool message from the returned file refs and
inlines a file as a vision content block only when the ref carries **both** a
`media_type` and a fetchable `view_url`. Upstream returns neither, so every
image the sandbox produced reached the model as a text mention —
`Image: /mnt/data/slide-1.jpg (83559 bytes, image/jpeg)`. The model was told an
image existed and never shown it, which defeats the point of rendering one: it
cannot QA a slide, read a chart, or spot a layout defect it cannot see.

**Files:**

| File | Role |
|---|---|
| `service/src/image-media-type.ts` (new) | Extension → vision-supported MIME |
| `service/src/vision-files.ts` (new) | Annotates image refs; mints the URL |
| `service/src/vision-files.test.ts` (new) | Regression coverage |
| `service/src/file-server.ts` | + `GET /sessions/:id/objects/:id/view-url` |
| `service/src/service/router.ts` | + one annotation call on the exec response |
| `service/src/types/service.ts` | + `media_type` / `view_url` on `FileRef` |

**Design notes:**

- **Annotated in the API tier, not the worker.** Only the API is wired to the
  file server; the worker has no `FILE_SERVER_URL` and giving it one would add a
  dependency edge for a presentation concern.
- **Presigned by the file server** because it is the only component holding
  object-storage credentials. The route is behind the shared internal-service
  token, like every other `/sessions` route.
- **Never fails an execution.** A 404, a timeout, or a file-server outage
  degrades the ref to exactly the upstream shape.
- **Capped per result** (`MAX_VIEW_URLS_PER_RESULT`) — a run emitting hundreds
  of frames would otherwise issue hundreds of presign round trips on the
  response path, and the model cannot consume more than a handful per turn.
- **Inherited refs are skipped** so an input image is not re-sent as a fresh
  vision block on every subsequent turn.
- **SVG is excluded**: it is XML, does not go through the vision encoder, and
  providers reject it.

Verified end to end: a deck generated in the UI, rendered via `soffice` →
`pdftoppm`, produced a tool message carrying an `image_url` block, and the model
described the actual pixels (clipped decorative circles, the empty upper 45% of
the slide) rather than restating its own intent.

---

## 2. Storage: real S3 instead of bundled MinIO (config delta)

**File:** `docker-compose.fork.yml` (new).

The platform rule is that file storage is S3 everywhere — including local dev,
which writes to the same dev bucket the deployed service uses. Upstream's
`MINIO_*` variables are simply its S3-client env contract (MinIO is an
S3-compatible target), so this needs **no code change**: the endpoint, region,
SSL flag, and credentials are retargeted at AWS and the bundled MinIO service is
scaled to zero.

The same overlay carries the `document_renderer` service definition.

---

## 2b. IMDSv2 credentials for the S3 client (upstreamable fix)

**File:** `service/src/imdsv2-credentials.ts` (new), selected from
`service/src/minio-client.ts`.

> **Moved 2026-09-19.** The selecting branch - and the empty `accessKey`/`secretKey`
> placeholders every provider-backed client needs - were written inside
> `createMinioClient` in `file-server.ts`. Upstream then extracted that factory into
> `minio-client.ts`. An extraction is a deletion in the old file plus a brand-new file, so
> the fork's branch conflicted only in `file-server.ts` (where "take theirs, it moved" is
> the obvious resolution) and `minio-client.ts` arrived with no conflict and neither delta.
> Accepting both sides as offered would have broken S3 on every instance-role host, and
> only at the next deploy. Both are re-homed in `minio-client.ts` and pinned by two tests
> in `minio-client.test.ts` that construct the client with no network. **When upstream
> moves a function the fork has edited, diff the fork's version against the merge base
> first - that diff is the list that must reappear in the new module.**

Setting `MINIO_USE_IRSA=true` picks the IAM branch, which is correct on
Kubernetes: IRSA supplies `AWS_WEB_IDENTITY_TOKEN_FILE` + `AWS_ROLE_ARN` and the
bundled `IamAwsProvider` exchanges them for credentials. On EC2 there is no
web-identity token file — the role is reachable only through the instance
metadata service, and that provider speaks **IMDSv1**.

An instance with `HttpTokens=required` answers IMDSv1 with **401**, so the
provider resolves nothing and the S3 client fails its own constructor
validation. The symptom is badly misleading:

```
Using IRSA (IamAwsProvider) for S3 authentication
MinIO not ready, retrying in 1000ms   error: accessKey should be of type "string"
```

Nothing in that points at metadata versions, and the retry backoff climbs to
several minutes, so the file server sits "Up" while every dependent request
fails `ECONNREFUSED`.

Neither obvious escape is acceptable on this host:

| Option | Why not |
|---|---|
| `HttpTokens=optional` | Re-enables the SSRF-prone IMDSv1 on a box whose job is running other people's code |
| Static access key in `.env` | Reintroduces the long-lived credential the instance role exists to remove |

So the fork implements the IMDSv2 handshake instead — PUT a token, then send
`X-aws-ec2-metadata-token` on every metadata read — and routes the EC2 case
through it. IMDSv2 stays enforced **and** no static credential is written to the
host. Credentials are cached until shortly before `Expiration`, with concurrent
refreshes collapsed, because the client asks per request.

The provider is structurally typed against what the client actually calls
(`getCredentials()`, then `getAccessKey()`/`getSecretKey()`/`getSessionToken()`)
rather than extending `CredentialProvider`: the package's export map does not
expose `minio/dist/main/*` to the bundler, which is why the sibling IRSA branch
has to reach for it through a dynamic import.

**Delete this** if the S3 client gains IMDSv2 support; the IRSA branch alone
would then cover both topologies.

---

## 2c. Egress grant scope moved to the ledger (bugfix delta)

**Files:** `service/src/egress-grant.ts`, `service/src/egress-gateway.ts`,
`service/src/egress-ledger.ts`, `service/src/config.ts`.

The sealed egress grant token rides the `X-CodeAPI-Egress-Grant` header on
every sandbox download and enumerates one `input_files` entry per readable
file. A skill-heavy job (30+ primed files) can seal a token past the HTTP
server's ~16KB header limit, which is answered with a pre-handler **431** —
the sandbox logs a bare `HTTP error: 431` and the user sees only "Code
execution is temporarily unavailable." The fix seals a **compact** token
(`scope_ref: 'ledger'`, empty file arrays) whenever the egress ledger is
guaranteed to exist, and has the gateway hydrate the real scope from the
ledger record — which every download already reads for its budget/revocation
check — before running the unchanged per-file authorization checks. Full
design, the `CODEAPI_EGRESS_COMPACT_GRANTS` kill switch, the EKS
mixed-version rollout note, and the upstream-merge/deletion criteria live in
[`docs/egress-grant-scope.md`](./egress-grant-scope.md).

**After the 2026-09-16 merge.** Upstream rewrote the ledger around a single-key
Lua script and added its own compact representation. The two "compact" ideas are
independent and both are live:

| Flag | Owner | What it makes compact |
|---|---|---|
| `CODEAPI_EGRESS_COMPACT_GRANTS` | fork | the sealed TOKEN the sandbox replays in a header |
| `CODEAPI_EGRESS_LEDGER_COMPACT` | upstream | the RECORD stored in Redis (hash instead of JSON) |

Upstream's header-size problem is still unsolved upstream: its token continues to
enumerate `input_files`, so the deletion criteria above have NOT been met. What
changed in the fork's half:

- the ~200-line WATCH/MULTI implementation is gone, replaced by upstream's script;
  only `readEgressLedgerRecord` and the `compact_scope_missing` reason remain, both
  grafted onto upstream's `snapshot` operation;
- hydration reads the ledger only for a token that IS compact, so an ordinary grant
  keeps upstream's check-only authorization path;
- hydrating while the ledger is disabled now throws `compact_scope_missing` rather
  than authorizing against the token's empty arrays.

---

## 3. LF line endings for container-executed files (upstreamable fix)

**File:** `.gitattributes`.

Added `eol=lf` for `*.sh`, `Dockerfile*`, `*.rs`, `*.py`, `*.toml`, `*.conf`,
and `pre-commit`. Upstream covers js/ts/yml/json/md only, so a Windows checkout
with `core.autocrlf=true` rewrites every shell script to CRLF; the container
shebang then parses as `#!/bin/bash\r` and Docker fails with the misleading
`exec /usr/local/bin/entrypoint.sh: no such file or directory`.

Not fork-specific — this affects any Windows contributor and should be offered
upstream.

---

## Deliberately NOT forked

Things we considered ours and found already supported upstream — do not
re-implement:

- **JWT per-user/tenant isolation** — native (`CODEAPI_AUTH_PROVIDER`,
  `CODEAPI_JWT_*`, plan limits keyed on the `plan_id` claim). Configuration,
  not code.
- **Programmatic Tool Calling** — native (`/v1/exec/programmatic` +
  `tool_call_server`).
- **Warm/stateful sandbox sessions, egress control, execution manifests** — all
  native.
- **NsJail mode without KVM** — native (`KVM_ENABLED=false`, and the
  `docker-compose.mac.yml` overlay already covers Docker Desktop hosts). Use
  upstream's overlay rather than writing our own.

  Read that literally: the overlay is not just a Mac convenience, it is the
  **reference NsJail configuration**, and a deployment that sets
  `KVM_ENABLED=false` without also copying its `security_opt` and `/dev/kvm`
  stub will not start. NsJail builds its jail with
  `clone(CLONE_NEWNS|CLONE_NEWCGROUP|CLONE_NEWUTS|CLONE_NEWIPC|CLONE_NEWUSER|
  CLONE_NEWPID|CLONE_NEWNET)`, which Docker's **default** seccomp profile
  filters — the runner fails with `EINVAL` and never becomes healthy. The
  shipped `seccomp/nsjail.json` whitelist exists for exactly this and is
  strictly tighter than `seccomp:unconfined`.

  gVisor (`runtime: runsc`) is **not** a substitute: it sandboxes a process, so
  it cannot host a process that itself creates namespaces, and the same clone
  fails inside it. The retired executor ran gVisor one container *per sandbox* —
  a different layer entirely, not NsJail nested inside gVisor.
