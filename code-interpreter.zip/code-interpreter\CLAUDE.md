# code-interpreter (fork)

Fork of the official LibreChat Code API execution engine. This is the sandboxed
code-execution service the chat app calls for `execute_code` / `bash`, for
Programmatic Tool Calling, and — via this fork's one functional delta — for
document preview rendering.

**This repo replaces the retired in-house `code-executor-v2`.** That service
existed because the official engine was not public; it now is, so we run the
reference implementation and carry a thin delta instead of maintaining a whole
executor. See `docs/upstream-deltas.md`.

## Branch model (two branches only)

- **`develop`** — the **fork-owned default branch**. All fork work lands here;
  it is `main` + the fork deltas. Branch feature work off `develop` and PR back
  into it. This is the branch to check out and build against.
- **`main`** — a **pristine mirror of `upstream/main`**. **Never commit fork
  code to `main`.** It exists so upstream lands cleanly and so
  `git diff main develop` is always the exact fork delta.

Remotes: `origin` = the fork remote, `upstream` =
ClickHouse/code-interpreter.

Update flow (integrate upstream):

```bash
git fetch upstream --prune
git checkout main && git reset --hard upstream/main && git push --force-with-lease origin main
git checkout develop && git merge main        # resolve, keeping fork deltas
```

Do not open PRs into `main`. Delete transient `merge/upstream-*` branches once
merged into `develop`.

## Architecture

Five independently scalable components communicating over a Redis queue and
S3-compatible storage — this split is why it scales horizontally, and is the
reason we adopted it:

| Component | Role |
|---|---|
| **api** | HTTP gateway — accepts `/v1/exec`, enqueues the job, returns the result |
| **service-worker** | Pulls jobs off Redis and drives execution |
| **sandbox-runner** | Runs the code under NsJail (or a libkrun microVM) |
| **file_server** | File upload/download backed by S3 |
| **tool_call_server** | Routes Programmatic Tool Calls made from inside a sandbox |
| **egress_gateway** | Mediates all sandbox-originated network traffic |
| **document_renderer** | **UPSTREAM DELTA** — office→PDF and PDF→page images |

## Local development

The dev workstation is Docker Desktop, which exposes no `/dev/kvm`, so the
sandbox runs in NsJail mode via the upstream `docker-compose.mac.yml` overlay.
Storage is real S3 (never MinIO) per the platform rule that file storage is S3
everywhere.

```bash
export AWS_ACCESS_KEY_ID=... AWS_SECRET_ACCESS_KEY=...

# One-time: populate the language runtimes volume (~3 GB, several minutes).
docker build -f docker/Dockerfile.package-init -t codeapi-package-init:local .
docker run --rm -v "$(pwd -W)/data/pkgs:/pkgs" codeapi-package-init:local

docker compose -f docker-compose.yaml \
               -f docker-compose.mac.yml \
               -f docker-compose.fork.yml up -d --build
```

Smoke tests:

```bash
curl -s localhost:3112/v1/health
curl -s -X POST localhost:3112/v1/exec -H 'content-type: application/json' \
     -H 'x-api-key: localdev' -d '{"lang":"py","code":"print(6*7)"}'
```

**Windows note:** everything executed inside a container must stay LF. The
`.gitattributes` `eol=lf` rules cover `*.sh`/Dockerfiles — without them a
`core.autocrlf=true` checkout yields `#!/bin/bash\r` and the container dies with
the misleading `exec /usr/local/bin/entrypoint.sh: no such file or directory`.

## The sandbox and the document skills

The host platform's document skills (docx/pptx/pdf) run **inside the sandbox**
and shell out to `soffice`, `pdftoppm`, `tesseract` and `git`. All four are in
the sandbox image and all four work — including the tracked-changes LibreOffice
Basic macro, verified against a document carrying a real `<w:del>`.

**Never patch a skill to work around the sandbox.** Skills are third-party
artifacts that get updated upstream; editing them forks them, and the next
update either breaks or silently reverts the change. If a skill cannot do
something, fix the sandbox — that delta belongs in this repo.

Two facts worth knowing before debugging anything in there:

- **Runtime `pip install` / `npm install` cannot work** — sandbox egress is
  closed by design. Packages go in `docker/package-init.sh` or
  `javascript-packages.txt`, then the `/pkgs` volume is repopulated. Installed
  JS packages are also linked into npm's global root so `npm ls -g <pkg>`
  resolves; without that a caller probing for a package concludes it is absent
  and falls back to an install that hangs against closed egress.
- **Each `/v1/exec` call gets a fresh sandbox.** Files do not persist between
  calls unless passed as file refs, so a repro script has to do all of its work
  in one call.

### Debugging an opaque failure in the sandbox

LibreOffice cost several rounds of wrong guesses (seccomp, `rlimit_as`, the task
ceiling — each disproved by measurement) before the real cause turned out to be
one missing bind mount. The lesson, generalized:

> An opaque abort with no diagnostic is far more often a **missing file** than a
> blocked syscall.

So: **diff a working environment against the broken one before theorizing.**
`strace -f` the same command inside the sandbox and in the plain container, then
diff the normalized traces — the divergence is usually a single `ENOENT`. That
found in one pass what syscall-policy reasoning missed across several. The
reusable pattern is a small image carrying `nsjail` plus the target binary, which
reproduces in seconds instead of a ten-minute stack rebuild.

Also: the sandbox binds all of `/usr` but only individual `/etc` files, so any
package whose `/usr` content symlinks into `/etc` needs its `/etc` directory
bind-mounted too. That is exactly how LibreOffice failed.

## Host contract

The chat app reaches this service through `LIBRECHAT_CODE_BASEURL`, which points
at the **versioned API root** (`.../v1`) so every call — `/exec`, `/download`,
`/documents/*` — resolves against one base.

Auth is upstream's, not ours: API-key mode (`x-api-key`, credential carried in
the base URL's userinfo) or managed JWT (`CODEAPI_AUTH_PROVIDER=librechat-jwt`
+ `CODEAPI_JWT_*`), which is what gives per-user/tenant isolation. A JWT-mode
host against a JWT-disabled deployment 401s on every request.

## Code quality

Follow the upstream conventions in `CONTRIBUTING.md` and `AGENTS.md`. Fork
additions additionally:

- Mark every fork-owned file or hunk with an `UPSTREAM DELTA` comment explaining
  **why** it diverges, so the next upstream merge can classify it instantly.
- Keep deltas **additive** wherever possible (a new file, a compose overlay) so
  upstream files stay conflict-free and the fork stays pullable.
- Document the "why", not the "what". Note `// PERF:` and `// SCALE:` paths.
- Every behavior change adds a `CHANGELOG.md` `[Unreleased]` entry, and updates
  or deletes any doc it makes stale.
- Ship a regression test with every fix; run the gate before calling it done.

Gate: `bun test` (service), `npm run lint`, plus a real `/v1/exec` round-trip
against the local stack for anything touching the execution or document path.

CI and publish workflows are **manual only** (`workflow_dispatch`) — the local
gate is the enforced source of truth.
