# Deployment

How this fork reaches the dev host, and what has to be true for a deploy to be
safe. Local development is covered in the root `CLAUDE.md`.

## Topology

One EC2 host runs the full seven-service stack from ECR images:

| Container | Image | Exposed |
|---|---|---|
| `ci-api` | `illuma-ai-code-interpreter-dev` | **8190** → 3112 |
| `ci-service-worker` | same | — |
| `ci-sandbox-runner` | `illuma-ai-code-interpreter-sandbox-dev` | — |
| `ci-file-server` | same as api | — |
| `ci-tool-call-server` | same as api | — |
| `ci-egress-gateway` | same as api | — |
| `ci-document-renderer` | `illuma-ai-code-interpreter-renderer-dev` | — |
| `ci-redis` | `redis:7-alpine` | — |

Port **8190** is deliberate: it is the port the host platform already points at,
so the cutover is an env change (`LIBRECHAT_CODE_BASEURL`) rather than a
firewall change. The URL must target the **versioned root** — `…:8190/v1` — so
`/exec`, `/download` and `/documents/*` all resolve against one base.

File storage is S3 (`illuma-ai-code-executor-dev`). MinIO is never deployed.

## Deploying

`.github/workflows/deploy-dev.yml`, **manual only** (`workflow_dispatch`) per the
platform CI rule. It builds the images, pushes to ECR, ships the compose file and
seccomp profile over SSM, restarts the stack, and then verifies the result rather
than trusting `docker compose up -d`.

Set **`run_package_init: true`** on a first deploy and whenever
`docker/package-init.sh` or `javascript-packages.txt` changed. It builds the
`package-init` image and populates the runtime volume; until it has run once,
`/v1/exec` answers `runtime is unknown`.

What the post-deploy check asserts, and why it stops there: auth is JWT-only
(there is no api-key mode), and minting a token needs the private half, which
lives on the host platform and not in CI. So the job asserts `/v1/health` = 200,
every container running, and an unauthenticated `/v1/exec` correctly **rejected
with 401**. The 401 is the success signal — it proves the api is up, routing and
enforcing auth. To prove execution end to end, run the harness from a machine
holding the signing key.

Required repository secrets:

| Secret | Purpose |
|---|---|
| `AWS_ACCESS_KEY_ID` / `AWS_SECRET_ACCESS_KEY` | ECR push + SSM |
| `DEPLOY_ARTIFACT_BUCKET` | where the compose file and seccomp profile are staged |

> Long-lived keys in CI are the weak link here. `permissions: id-token: write` is
> already declared, so switching to an OIDC role (`role-to-assume`) and deleting
> both key secrets is a drop-in improvement whenever someone has 20 minutes.

### Runtime configuration lives in Secrets Manager

`/opt/code-interpreter/.env` is **rendered at deploy time**, not maintained by
hand. The workflow ships `deploy/render-env.py` to the host, which reads the
JSON secret `illuma-ai/dev/code-interpreter` using the **instance role** and
writes the env file (mode `600`), pinning `IMAGE_TAG` to the tag just built.

This is the same pattern the host platform already uses for its own settings,
and it buys the property that matters operationally: **a configuration change is
a secret update plus a re-run of this workflow — no image rebuild.** No value
passes through CI, appears in a workflow log, or is baked into a layer.

The renderer exists as a script rather than a shell one-liner because two values
break naive rendering, each of which cost a debugging cycle while the file was
hand-maintained:

- the JWT public key is a **PEM**, and `docker compose` rejects a multi-line
  value — it must be one line with literal `\n` escapes, which the verifier
  un-escapes before parsing;
- values contain `/`, `+` and `=` (base64, PEM bodies), which a shell would
  word-split or expand.

Update a setting:

```bash
aws secretsmanager get-secret-value --secret-id illuma-ai/dev/code-interpreter \
  --query SecretString --output text > /tmp/cfg.json     # edit it
aws secretsmanager put-secret-value  --secret-id illuma-ai/dev/code-interpreter \
  --secret-string file:///tmp/cfg.json
# then re-run Deploy (dev) with the tag already in ECR
```

### Host prerequisites the workflow does NOT create

The deploy fails its preflight — legibly, before touching the running stack — if
any of these is missing.

**0. Secrets Manager access for the instance role.** The role was provisioned
before this secret existed, so the render step fails with `AccessDeniedException`
until granted:

```bash
aws iam put-role-policy --role-name <instance-role> \
  --policy-name CodeInterpreterSecretsAccess --policy-document '{
  "Version":"2012-10-17","Statement":[{
    "Effect":"Allow",
    "Action":["secretsmanager:GetSecretValue","secretsmanager:DescribeSecret"],
    "Resource":"arn:aws:secretsmanager:us-east-1:423159469683:secret:illuma-ai/dev/code-interpreter*"}]}'
```

Deploys only need read; add `CreateSecret`/`PutSecretValue` temporarily if you
want to seed the secret **from the host**, which keeps generated values off any
laptop.

**1. The secret's contents.** Keys the stack requires:

| Key | How to produce it |
|---|---|
| `ECR_REGISTRY`, `AWS_REGION`, `CODEAPI_S3_BUCKET`, `CODEAPI_PUBLIC_PORT` | plain config (`IMAGE_TAG` is pinned by the workflow, not stored here) |
| `REDIS_PASSWORD`, `CODEAPI_INTERNAL_SERVICE_TOKEN`, `CODEAPI_EGRESS_GRANT_SECRET` | `openssl rand -hex 32` **on the host** |
| `EXECUTION_MANIFEST_PRIVATE_KEY` / `_PUBLIC_KEY` | `openssl genpkey -algorithm ed25519`, base64-DER each half |
| `CODEAPI_JWT_PUBLIC_KEY` | PEM of the host platform's signing key, single line with literal `\n` escapes |
| `CODEAPI_AUTH_PROVIDER`, `CODEAPI_JWT_ISSUER`, `CODEAPI_JWT_AUDIENCE`, `CODEAPI_JWT_KID` | must match the platform (`librechat-jwt` / `librechat` / `codeapi` / `lc-codeapi-2026-05`) |

Generate the random values **on the host** so they never transit a laptop or a
terminal transcript. `render-env.py` handles the newline escaping for the PEM,
but the stored value must still be **PEM** rather than base64-DER, which the
verifier rejects.

**No AWS access keys live on the host.** S3 is authenticated by the instance's
IAM role via `MINIO_USE_IRSA=true`; on EC2 that routes through the IMDSv2
provider (`service/src/imdsv2-credentials.ts`), so IMDSv2 stays enforced and
there is no credential to rotate or leak.

**2. ECR pull rights for the instance role.** The role attached to the dev host
was provisioned for the retired executor's repository, so pulls from the
code-interpreter repositories are denied (`ecr:BatchGetImage`) until granted:

```bash
POL='{"Version":"2008-10-17","Statement":[{"Sid":"AllowDevHostPull","Effect":"Allow",
  "Principal":{"AWS":"arn:aws:iam::423159469683:role/<instance-role>"},
  "Action":["ecr:GetDownloadUrlForLayer","ecr:BatchGetImage","ecr:BatchCheckLayerAvailability"]}]}'
for r in illuma-ai-code-interpreter-dev illuma-ai-code-interpreter-sandbox-dev \
         illuma-ai-code-interpreter-renderer-dev; do
  aws ecr set-repository-policy --repository-name "$r" --region us-east-1 --policy-text "$POL"
done
```

## One-time host preparation

The language runtimes (Python/Node/Bun + the package set) live on a host volume,
not in the sandbox image — the sandbox mounts `/opt/code-interpreter/pkgs`
read-only. Populate it once, and again whenever a package manifest changes
(`docker/package-init.sh`, `javascript-packages.txt`):

```bash
docker run --rm -v /opt/code-interpreter/pkgs:/pkgs \
  <registry>/illuma-ai-code-interpreter-dev:package-init
```

This takes several minutes and rebuilds Python from source. Until it finishes,
`/v1/exec` returns `runtime is unknown`.

Running it by hand is the fallback; `run_package_init: true` does exactly this
(and builds the image first), which is why a **first** deploy must set it.

## Before cutting over — read this

The host currently serving `:8190` is **shared**: the deployed chat app points at
it too. Replacing that service affects every user of it, not just local dev.

1. Deploy and verify on the box **before** repointing anything.
2. Cut over by changing `LIBRECHAT_CODE_BASEURL` to `…:8190/v1`.
3. Keep the previous stack's compose file until the new one has run a full day —
   rollback is redeploying the old compose, not rebuilding.

Auth must be switched on **both** sides together — and note the asymmetry: this
service has **no api-key mode at all**. `getAuthProviderMode()` accepts only
`librechat-jwt` or `none`, defaults to the former, and refuses `none` outside
`LOCAL_MODE`. So the platform must send a JWT; there is no key-only fallback to
land on. Anything else gets a flat 401.

Concretely, on the platform side:

| Setting | Value |
|---|---|
| `LIBRECHAT_CODE_BASEURL` | `http://<host>:8190/v1` — no `key@` userinfo; it is unused and its presence hides the real auth path |
| `CODEAPI_AUTH_PROVIDER` | `librechat-jwt` |
| `CODEAPI_JWT_ALGORITHM` | `EdDSA` |
| `CODEAPI_JWT_ISSUER` / `_AUDIENCE` | `librechat` / `codeapi` — must equal the host's |
| `CODEAPI_JWT_PRIVATE_KEY_BASE64` | signing key; its **public** half goes in the host's `.env` |

Two traps worth knowing before you debug a 401:

- **Token lifetime is capped at 300s** by the verifier; a longer `exp` is
  rejected as `ttl_too_long`.
- The verifier requires `jti`, `principal_source` and `auth_context_hash`
  alongside the usual claims. A token missing any of them fails as
  `malformed_claims` — which looks identical to a bad signature from the outside.
  The api logs the precise `reason`, so read those rather than guessing.

## Scaling beyond one host

This single-host topology is a development convenience, not the scale target.
Each sandbox is a container on one Docker daemon, so sandbox churn is bounded by
that daemon (the predecessor service was taken down by exhausting its bridge
network's IP pool). Upstream ships `docker-compose.scalable.yml` and a Helm
chart for the real shape: stateless API replicas, worker pods scaled on queue
depth, and sandbox networking disabled entirely. Move to it when concurrent load
— not feature work — demands it.
