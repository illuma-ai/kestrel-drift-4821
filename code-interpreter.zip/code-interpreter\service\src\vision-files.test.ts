/**
 * UPSTREAM DELTA — regression coverage for vision annotation.
 *
 * The bug being locked down: image outputs came back with neither `media_type`
 * nor `view_url`, so the host rendered them as a text mention and the model
 * never saw the image it had just generated.
 */

import { describe, test, expect, mock, afterEach } from 'bun:test';
import { detectImageMediaType, isViewableImage } from './image-media-type';
import { annotateImageRefs } from './vision-files';
import type { FileRef } from './types/service';

const originalFetch = globalThis.fetch;

afterEach(() => {
  globalThis.fetch = originalFetch;
});

/** Stub the file server's view-url route; records the URLs requested. */
function stubFileServer(viewUrl: string | null): { calls: string[] } {
  const calls: string[] = [];
  globalThis.fetch = mock(async (input: RequestInfo | URL) => {
    calls.push(String(input));
    if (viewUrl === null) {
      return new Response('nope', { status: 404 });
    }
    return new Response(JSON.stringify({ view_url: viewUrl, expires_in: 900 }), {
      status: 200,
      headers: { 'content-type': 'application/json' },
    });
  }) as unknown as typeof fetch;
  return { calls };
}

describe('detectImageMediaType', () => {
  test('maps the vision-supported extensions, case-insensitively', () => {
    expect(detectImageMediaType('chart.png')).toBe('image/png');
    expect(detectImageMediaType('/mnt/data/slide-1.JPG')).toBe('image/jpeg');
    expect(detectImageMediaType('a.jpeg')).toBe('image/jpeg');
    expect(detectImageMediaType('anim.gif')).toBe('image/gif');
    expect(detectImageMediaType('x.webp')).toBe('image/webp');
  });

  test('rejects SVG — it is XML and providers reject it as a vision block', () => {
    expect(detectImageMediaType('plot.svg')).toBeUndefined();
    expect(isViewableImage('plot.svg')).toBe(false);
  });

  test('rejects non-images and extensionless names', () => {
    expect(detectImageMediaType('deck.pptx')).toBeUndefined();
    expect(detectImageMediaType('report.pdf')).toBeUndefined();
    expect(detectImageMediaType('README')).toBeUndefined();
  });
});

describe('annotateImageRefs', () => {
  test('annotates an image ref with BOTH fields the host requires', async () => {
    stubFileServer('https://s3.example/signed?sig=abc');
    const [file] = await annotateImageRefs(
      [{ id: 'obj1', name: 'slide-1.jpg', storage_session_id: 'sess-a' }],
      'fallback',
    );

    expect(file.media_type).toBe('image/jpeg');
    expect(file.view_url).toBe('https://s3.example/signed?sig=abc');
  });

  test("uses the ref's own storage session, not the execution session", async () => {
    const { calls } = stubFileServer('https://s3.example/signed');
    await annotateImageRefs(
      [{ id: 'obj1', name: 'a.png', storage_session_id: 'sess-a' }],
      'exec-session',
    );

    expect(calls[0]).toContain('/sessions/sess-a/objects/obj1/view-url');
  });

  test('falls back to the execution session when the ref omits one', async () => {
    const { calls } = stubFileServer('https://s3.example/signed');
    await annotateImageRefs([{ id: 'obj1', name: 'a.png' }], 'exec-session');

    expect(calls[0]).toContain('/sessions/exec-session/objects/obj1/view-url');
  });

  test('leaves non-images untouched and does not call the file server', async () => {
    const { calls } = stubFileServer('https://s3.example/signed');
    const input: FileRef[] = [
      { id: 'o1', name: 'deck.pptx', storage_session_id: 's' },
      { id: 'o2', name: 'notes.txt', storage_session_id: 's' },
    ];
    const out = await annotateImageRefs(input, 's');

    expect(out).toEqual(input);
    expect(calls).toHaveLength(0);
  });

  test('skips inherited inputs so the same image is not re-sent each turn', async () => {
    const { calls } = stubFileServer('https://s3.example/signed');
    const out = await annotateImageRefs(
      [{ id: 'o1', name: 'input.png', storage_session_id: 's', inherited: true }],
      's',
    );

    expect(out[0].view_url).toBeUndefined();
    expect(calls).toHaveLength(0);
  });

  test('degrades to the upstream shape when the URL cannot be minted', async () => {
    stubFileServer(null);
    const input: FileRef[] = [{ id: 'o1', name: 'a.png', storage_session_id: 's' }];
    const out = await annotateImageRefs(input, 's');

    expect(out[0].view_url).toBeUndefined();
    expect(out[0].media_type).toBeUndefined();
  });

  test('a file-server outage never fails the execution', async () => {
    globalThis.fetch = mock(async () => {
      throw new Error('ECONNREFUSED');
    }) as unknown as typeof fetch;

    const out = await annotateImageRefs([{ id: 'o1', name: 'a.png', storage_session_id: 's' }], 's');
    expect(out).toHaveLength(1);
    expect(out[0].view_url).toBeUndefined();
  });

  test('caps how many URLs one result mints', async () => {
    const { calls } = stubFileServer('https://s3.example/signed');
    const many: FileRef[] = Array.from({ length: 40 }, (_, i) => ({
      id: `o${i}`,
      name: `frame-${i}.png`,
      storage_session_id: 's',
    }));

    const out = await annotateImageRefs(many, 's');

    expect(calls.length).toBeLessThanOrEqual(12);
    expect(out).toHaveLength(40);
    expect(out.filter((f) => f.view_url !== undefined)).toHaveLength(calls.length);
  });

  test('presents the internal-service token — the file server gates /sessions', async () => {
    const saved = process.env.CODEAPI_INTERNAL_SERVICE_TOKEN;
    process.env.CODEAPI_INTERNAL_SERVICE_TOKEN = 'tok-123';
    const seen: (Headers | undefined)[] = [];
    globalThis.fetch = mock(async (_input: RequestInfo | URL, init?: RequestInit) => {
      seen.push(new Headers(init?.headers));
      return new Response(JSON.stringify({ view_url: 'https://s3.example/x' }), {
        status: 200,
        headers: { 'content-type': 'application/json' },
      });
    }) as unknown as typeof fetch;

    try {
      await annotateImageRefs([{ id: 'o1', name: 'a.png', storage_session_id: 's' }], 's');
      expect(seen[0]?.get('X-CodeAPI-Internal-Token')).toBe('tok-123');
    } finally {
      if (saved === undefined) {
        delete process.env.CODEAPI_INTERNAL_SERVICE_TOKEN;
      } else {
        process.env.CODEAPI_INTERNAL_SERVICE_TOKEN = saved;
      }
    }
  });

  test('an empty harvest is a no-op', async () => {
    const { calls } = stubFileServer('https://s3.example/signed');
    expect(await annotateImageRefs([], 's')).toEqual([]);
    expect(calls).toHaveLength(0);
  });
});
